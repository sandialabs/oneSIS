# LaTeX2HTML 2008 (1.71)
# Associate labels original text with physical files.


$key = q/boot-ib/;
$external_labels{$key} = "$URL/" . q|node19.html|; 
$noresave{$key} = "$nosave";

$key = q/progs-consl/;
$external_labels{$key} = "$URL/" . q|node81.html|; 
$noresave{$key} = "$nosave";

$key = q/progs-copyrootfs/;
$external_labels{$key} = "$URL/" . q|node76.html|; 
$noresave{$key} = "$nosave";

$key = q/progs-myclass/;
$external_labels{$key} = "$URL/" . q|node83.html|; 
$noresave{$key} = "$nosave";

$key = q/inst-mksysimage/;
$external_labels{$key} = "$URL/" . q|node9.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-properties/;
$external_labels{$key} = "$URL/" . q|node38.html|; 
$noresave{$key} = "$nosave";

$key = q/proc-ipappend/;
$external_labels{$key} = "$URL/" . q|node18.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-excludedeploysyntax/;
$external_labels{$key} = "$URL/" . q|node59.html|; 
$noresave{$key} = "$nosave";

$key = q/boot-advanced/;
$external_labels{$key} = "$URL/" . q|node16.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-specformat/;
$external_labels{$key} = "$URL/" . q|node70.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-manualhostname/;
$external_labels{$key} = "$URL/" . q|node62.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-localdisks/;
$external_labels{$key} = "$URL/" . q|node55.html|; 
$noresave{$key} = "$nosave";

$key = q/boot-pxe/;
$external_labels{$key} = "$URL/" . q|node18.html|; 
$noresave{$key} = "$nosave";

$key = q/boot-popramroot/;
$external_labels{$key} = "$URL/" . q|node21.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-localboot/;
$external_labels{$key} = "$URL/" . q|node60.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-lb-subclasses/;
$external_labels{$key} = "$URL/" . q|node48.html|; 
$noresave{$key} = "$nosave";

$key = q/progs/;
$external_labels{$key} = "$URL/" . q|node73.html|; 
$noresave{$key} = "$nosave";

$key = q/intro-nfsroot/;
$external_labels{$key} = "$URL/" . q|node3.html|; 
$noresave{$key} = "$nosave";

$key = q/boot/;
$external_labels{$key} = "$URL/" . q|node11.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-services/;
$external_labels{$key} = "$URL/" . q|node44.html|; 
$noresave{$key} = "$nosave";

$key = q/inst/;
$external_labels{$key} = "$URL/" . q|node6.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-pwrsyntax/;
$external_labels{$key} = "$URL/" . q|node69.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-manualclass/;
$external_labels{$key} = "$URL/" . q|node65.html|; 
$noresave{$key} = "$nosave";

$key = q/boot-root/;
$external_labels{$key} = "$URL/" . q|node14.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-excludesyncsyntax/;
$external_labels{$key} = "$URL/" . q|node58.html|; 
$noresave{$key} = "$nosave";

$key = q/boot-otherfs/;
$external_labels{$key} = "$URL/" . q|node22.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-macaddrsyntax/;
$external_labels{$key} = "$URL/" . q|node63.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-diskcaution/;
$external_labels{$key} = "$URL/" . q|node54.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-ramelems/;
$external_labels{$key} = "$URL/" . q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/impl-devs/;
$external_labels{$key} = "$URL/" . q|node27.html|; 
$noresave{$key} = "$nosave";

$key = q/boot-traditional/;
$external_labels{$key} = "$URL/" . q|node12.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-lb-forcing/;
$external_labels{$key} = "$URL/" . q|node47.html|; 
$noresave{$key} = "$nosave";

$key = q/progs-mksysimage/;
$external_labels{$key} = "$URL/" . q|node74.html|; 
$noresave{$key} = "$nosave";

$key = q/inst-git/;
$external_labels{$key} = "$URL/" . q|node10.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-ram-dupe/;
$external_labels{$key} = "$URL/" . q|node41.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-tempdisks/;
$external_labels{$key} = "$URL/" . q|node52.html|; 
$noresave{$key} = "$nosave";

$key = q/progs-pxeconfig/;
$external_labels{$key} = "$URL/" . q|node82.html|; 
$noresave{$key} = "$nosave";

$key = q/conf/;
$external_labels{$key} = "$URL/" . q|node32.html|; 
$noresave{$key} = "$nosave";

$key = q/boot-custom/;
$external_labels{$key} = "$URL/" . q|node24.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-matchdnshosts/;
$external_labels{$key} = "$URL/" . q|node66.html|; 
$noresave{$key} = "$nosave";

$key = q/progs-updatenode/;
$external_labels{$key} = "$URL/" . q|node75.html|; 
$noresave{$key} = "$nosave";

$key = q/intro-central/;
$external_labels{$key} = "$URL/" . q|node5.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-readonly/;
$external_labels{$key} = "$URL/" . q|node43.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-servicesyntax/;
$external_labels{$key} = "$URL/" . q|node45.html|; 
$noresave{$key} = "$nosave";

$key = q/boot-bonding/;
$external_labels{$key} = "$URL/" . q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-distrosyntax/;
$external_labels{$key} = "$URL/" . q|node34.html|; 
$noresave{$key} = "$nosave";

$key = q/config-initramfs/;
$external_labels{$key} = "$URL/" . q|node86.html|; 
$noresave{$key} = "$nosave";

$key = q/impl-subclasses/;
$external_labels{$key} = "$URL/" . q|node29.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-syncdirsyntax/;
$external_labels{$key} = "$URL/" . q|node57.html|; 
$noresave{$key} = "$nosave";

$key = q/progs-mkinitramfs/;
$external_labels{$key} = "$URL/" . q|node77.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-disks/;
$external_labels{$key} = "$URL/" . q|node51.html|; 
$noresave{$key} = "$nosave";

$key = q/fig-ramfile/;
$external_labels{$key} = "$URL/" . q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-includesyntax/;
$external_labels{$key} = "$URL/" . q|node72.html|; 
$noresave{$key} = "$nosave";

$key = q/boot-initramfs/;
$external_labels{$key} = "$URL/" . q|node13.html|; 
$noresave{$key} = "$nosave";

$key = q/fig-linkfile/;
$external_labels{$key} = "$URL/" . q|node40.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-distro/;
$external_labels{$key} = "$URL/" . q|node33.html|; 
$noresave{$key} = "$nosave";

$key = q/boot-template/;
$external_labels{$key} = "$URL/" . q|node15.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-specsyntax/;
$external_labels{$key} = "$URL/" . q|node71.html|; 
$noresave{$key} = "$nosave";

$key = q/inst-depend/;
$external_labels{$key} = "$URL/" . q|node7.html|; 
$noresave{$key} = "$nosave";

$key = q/intro/;
$external_labels{$key} = "$URL/" . q|node2.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-linkback/;
$external_labels{$key} = "$URL/" . q|node46.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-deploysyntax/;
$external_labels{$key} = "$URL/" . q|node56.html|; 
$noresave{$key} = "$nosave";

$key = q/impl/;
$external_labels{$key} = "$URL/" . q|node25.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-disksyntax/;
$external_labels{$key} = "$URL/" . q|node53.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-ramsize/;
$external_labels{$key} = "$URL/" . q|node39.html|; 
$noresave{$key} = "$nosave";

$key = q/inst-image/;
$external_labels{$key} = "$URL/" . q|node8.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-subclass/;
$external_labels{$key} = "$URL/" . q|node37.html|; 
$noresave{$key} = "$nosave";

$key = q/intro-rootfs/;
$external_labels{$key} = "$URL/" . q|node4.html|; 
$noresave{$key} = "$nosave";

$key = q/progs-mkdiskful/;
$external_labels{$key} = "$URL/" . q|node78.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-linkbacksyntax/;
$external_labels{$key} = "$URL/" . q|node50.html|; 
$noresave{$key} = "$nosave";

$key = q/progs-pwr/;
$external_labels{$key} = "$URL/" . q|node80.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-lb-hidden/;
$external_labels{$key} = "$URL/" . q|node49.html|; 
$noresave{$key} = "$nosave";

$key = q/boot-ramroot/;
$external_labels{$key} = "$URL/" . q|node20.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-nodeclass/;
$external_labels{$key} = "$URL/" . q|node35.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-pwr-consl/;
$external_labels{$key} = "$URL/" . q|node67.html|; 
$noresave{$key} = "$nosave";

$key = q/impl-roles/;
$external_labels{$key} = "$URL/" . q|node28.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-bootloadersyntax/;
$external_labels{$key} = "$URL/" . q|node61.html|; 
$noresave{$key} = "$nosave";

$key = q/progs-myprops/;
$external_labels{$key} = "$URL/" . q|node84.html|; 
$noresave{$key} = "$nosave";

$key = q/git-howto/;
$external_labels{$key} = "$URL/" . q|node87.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-ramlinksyntax/;
$external_labels{$key} = "$URL/" . q|node42.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-ethpreload/;
$external_labels{$key} = "$URL/" . q|node64.html|; 
$noresave{$key} = "$nosave";

$key = q/proc-bonding/;
$external_labels{$key} = "$URL/" . q|node17.html|; 
$noresave{$key} = "$nosave";

$key = q/impl-porting/;
$external_labels{$key} = "$URL/" . q|node31.html|; 
$noresave{$key} = "$nosave";

$key = q/impl-boot/;
$external_labels{$key} = "$URL/" . q|node30.html|; 
$noresave{$key} = "$nosave";

$key = q/progs-syncnode/;
$external_labels{$key} = "$URL/" . q|node79.html|; 
$noresave{$key} = "$nosave";

$key = q/config-sysimage/;
$external_labels{$key} = "$URL/" . q|node85.html|; 
$noresave{$key} = "$nosave";

$key = q/conf-nodeclasssyntax/;
$external_labels{$key} = "$URL/" . q|node36.html|; 
$noresave{$key} = "$nosave";

$key = q/boot-config/;
$external_labels{$key} = "$URL/" . q|node23.html|; 
$noresave{$key} = "$nosave";

$key = q/fig-linkback/;
$external_labels{$key} = "$URL/" . q|node28.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2008 (1.71)
# labels from external_latex_labels array.


$key = q/boot-ib/;
$external_latex_labels{$key} = q|3.3.3|; 
$noresave{$key} = "$nosave";

$key = q/progs-consl/;
$external_latex_labels{$key} = q|6.8|; 
$noresave{$key} = "$nosave";

$key = q/progs-copyrootfs/;
$external_latex_labels{$key} = q|6.3|; 
$noresave{$key} = "$nosave";

$key = q/progs-myclass/;
$external_latex_labels{$key} = q|6.10|; 
$noresave{$key} = "$nosave";

$key = q/inst-mksysimage/;
$external_latex_labels{$key} = q|2.2.1|; 
$noresave{$key} = "$nosave";

$key = q/conf-properties/;
$external_latex_labels{$key} = q|5.4|; 
$noresave{$key} = "$nosave";

$key = q/proc-ipappend/;
$external_latex_labels{$key} = q|5|; 
$noresave{$key} = "$nosave";

$key = q/conf-excludedeploysyntax/;
$external_latex_labels{$key} = q|5.10.8|; 
$noresave{$key} = "$nosave";

$key = q/boot-advanced/;
$external_latex_labels{$key} = q|3.3|; 
$noresave{$key} = "$nosave";

$key = q/conf-specformat/;
$external_latex_labels{$key} = q|5.15|; 
$noresave{$key} = "$nosave";

$key = q/conf-manualhostname/;
$external_latex_labels{$key} = q|5.11|; 
$noresave{$key} = "$nosave";

$key = q/conf-localdisks/;
$external_latex_labels{$key} = q|5.10.4|; 
$noresave{$key} = "$nosave";

$key = q/boot-pxe/;
$external_latex_labels{$key} = q|3.3.2|; 
$noresave{$key} = "$nosave";

$key = q/boot-popramroot/;
$external_latex_labels{$key} = q|3.3.5|; 
$noresave{$key} = "$nosave";

$key = q/conf-localboot/;
$external_latex_labels{$key} = q|5.10.9|; 
$noresave{$key} = "$nosave";

$key = q/conf-lb-subclasses/;
$external_latex_labels{$key} = q|5.9.2|; 
$noresave{$key} = "$nosave";

$key = q/progs/;
$external_latex_labels{$key} = q|6|; 
$noresave{$key} = "$nosave";

$key = q/intro-nfsroot/;
$external_latex_labels{$key} = q|1.1|; 
$noresave{$key} = "$nosave";

$key = q/boot/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

$key = q/conf-services/;
$external_latex_labels{$key} = q|5.8|; 
$noresave{$key} = "$nosave";

$key = q/inst/;
$external_latex_labels{$key} = q|2|; 
$noresave{$key} = "$nosave";

$key = q/conf-pwrsyntax/;
$external_latex_labels{$key} = q|5.14.2|; 
$noresave{$key} = "$nosave";

$key = q/conf-manualclass/;
$external_latex_labels{$key} = q|5.12|; 
$noresave{$key} = "$nosave";

$key = q/boot-root/;
$external_latex_labels{$key} = q|3.2.1|; 
$noresave{$key} = "$nosave";

$key = q/conf-excludesyncsyntax/;
$external_latex_labels{$key} = q|5.10.7|; 
$noresave{$key} = "$nosave";

$key = q/boot-otherfs/;
$external_latex_labels{$key} = q|3.3.6|; 
$noresave{$key} = "$nosave";

$key = q/conf-macaddrsyntax/;
$external_latex_labels{$key} = q|5.11.1|; 
$noresave{$key} = "$nosave";

$key = q/conf-diskcaution/;
$external_latex_labels{$key} = q|5.10.3|; 
$noresave{$key} = "$nosave";

$key = q/conf-ramelems/;
$external_latex_labels{$key} = q|5.6|; 
$noresave{$key} = "$nosave";

$key = q/impl-devs/;
$external_latex_labels{$key} = q|4.2|; 
$noresave{$key} = "$nosave";

$key = q/boot-traditional/;
$external_latex_labels{$key} = q|3.1|; 
$noresave{$key} = "$nosave";

$key = q/conf-lb-forcing/;
$external_latex_labels{$key} = q|5.9.1|; 
$noresave{$key} = "$nosave";

$key = q/progs-mksysimage/;
$external_latex_labels{$key} = q|6.1|; 
$noresave{$key} = "$nosave";

$key = q/inst-git/;
$external_latex_labels{$key} = q|2.2.2|; 
$noresave{$key} = "$nosave";

$key = q/conf-ram-dupe/;
$external_latex_labels{$key} = q|5.6.1|; 
$noresave{$key} = "$nosave";

$key = q/conf-tempdisks/;
$external_latex_labels{$key} = q|5.10.1|; 
$noresave{$key} = "$nosave";

$key = q/progs-pxeconfig/;
$external_latex_labels{$key} = q|6.9|; 
$noresave{$key} = "$nosave";

$key = q/conf/;
$external_latex_labels{$key} = q|5|; 
$noresave{$key} = "$nosave";

$key = q/boot-custom/;
$external_latex_labels{$key} = q|3.3.8|; 
$noresave{$key} = "$nosave";

$key = q/conf-matchdnshosts/;
$external_latex_labels{$key} = q|5.13|; 
$noresave{$key} = "$nosave";

$key = q/progs-updatenode/;
$external_latex_labels{$key} = q|6.2|; 
$noresave{$key} = "$nosave";

$key = q/intro-central/;
$external_latex_labels{$key} = q|1.3|; 
$noresave{$key} = "$nosave";

$key = q/conf-readonly/;
$external_latex_labels{$key} = q|5.7|; 
$noresave{$key} = "$nosave";

$key = q/conf-servicesyntax/;
$external_latex_labels{$key} = q|5.8.1|; 
$noresave{$key} = "$nosave";

$key = q/boot-bonding/;
$external_latex_labels{$key} = q|3.3.1|; 
$noresave{$key} = "$nosave";

$key = q/conf-distrosyntax/;
$external_latex_labels{$key} = q|5.1.1|; 
$noresave{$key} = "$nosave";

$key = q/config-initramfs/;
$external_latex_labels{$key} = q|B|; 
$noresave{$key} = "$nosave";

$key = q/impl-subclasses/;
$external_latex_labels{$key} = q|4.4|; 
$noresave{$key} = "$nosave";

$key = q/conf-syncdirsyntax/;
$external_latex_labels{$key} = q|5.10.6|; 
$noresave{$key} = "$nosave";

$key = q/progs-mkinitramfs/;
$external_latex_labels{$key} = q|6.4|; 
$noresave{$key} = "$nosave";

$key = q/conf-disks/;
$external_latex_labels{$key} = q|5.10|; 
$noresave{$key} = "$nosave";

$key = q/fig-ramfile/;
$external_latex_labels{$key} = q|2|; 
$noresave{$key} = "$nosave";

$key = q/conf-includesyntax/;
$external_latex_labels{$key} = q|5.16|; 
$noresave{$key} = "$nosave";

$key = q/boot-initramfs/;
$external_latex_labels{$key} = q|3.2|; 
$noresave{$key} = "$nosave";

$key = q/fig-linkfile/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

$key = q/conf-distro/;
$external_latex_labels{$key} = q|5.1|; 
$noresave{$key} = "$nosave";

$key = q/boot-template/;
$external_latex_labels{$key} = q|3.2.2|; 
$noresave{$key} = "$nosave";

$key = q/conf-specsyntax/;
$external_latex_labels{$key} = q|5.15.1|; 
$noresave{$key} = "$nosave";

$key = q/inst-depend/;
$external_latex_labels{$key} = q|2.1|; 
$noresave{$key} = "$nosave";

$key = q/intro/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/conf-linkback/;
$external_latex_labels{$key} = q|5.9|; 
$noresave{$key} = "$nosave";

$key = q/conf-deploysyntax/;
$external_latex_labels{$key} = q|5.10.5|; 
$noresave{$key} = "$nosave";

$key = q/impl/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

$key = q/conf-disksyntax/;
$external_latex_labels{$key} = q|5.10.2|; 
$noresave{$key} = "$nosave";

$key = q/conf-ramsize/;
$external_latex_labels{$key} = q|5.5|; 
$noresave{$key} = "$nosave";

$key = q/inst-image/;
$external_latex_labels{$key} = q|2.2|; 
$noresave{$key} = "$nosave";

$key = q/conf-subclass/;
$external_latex_labels{$key} = q|5.3|; 
$noresave{$key} = "$nosave";

$key = q/intro-rootfs/;
$external_latex_labels{$key} = q|1.2|; 
$noresave{$key} = "$nosave";

$key = q/progs-mkdiskful/;
$external_latex_labels{$key} = q|6.5|; 
$noresave{$key} = "$nosave";

$key = q/conf-linkbacksyntax/;
$external_latex_labels{$key} = q|5.9.4|; 
$noresave{$key} = "$nosave";

$key = q/progs-pwr/;
$external_latex_labels{$key} = q|6.7|; 
$noresave{$key} = "$nosave";

$key = q/conf-lb-hidden/;
$external_latex_labels{$key} = q|5.9.3|; 
$noresave{$key} = "$nosave";

$key = q/boot-ramroot/;
$external_latex_labels{$key} = q|3.3.4|; 
$noresave{$key} = "$nosave";

$key = q/conf-nodeclass/;
$external_latex_labels{$key} = q|5.2|; 
$noresave{$key} = "$nosave";

$key = q/conf-pwr-consl/;
$external_latex_labels{$key} = q|5.14|; 
$noresave{$key} = "$nosave";

$key = q/impl-roles/;
$external_latex_labels{$key} = q|4.3|; 
$noresave{$key} = "$nosave";

$key = q/conf-bootloadersyntax/;
$external_latex_labels{$key} = q|5.10.10|; 
$noresave{$key} = "$nosave";

$key = q/progs-myprops/;
$external_latex_labels{$key} = q|6.11|; 
$noresave{$key} = "$nosave";

$key = q/git-howto/;
$external_latex_labels{$key} = q|C|; 
$noresave{$key} = "$nosave";

$key = q/conf-ramlinksyntax/;
$external_latex_labels{$key} = q|5.6.2|; 
$noresave{$key} = "$nosave";

$key = q/conf-ethpreload/;
$external_latex_labels{$key} = q|5.11.2|; 
$noresave{$key} = "$nosave";

$key = q/proc-bonding/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

$key = q/impl-porting/;
$external_latex_labels{$key} = q|4.6|; 
$noresave{$key} = "$nosave";

$key = q/impl-boot/;
$external_latex_labels{$key} = q|4.5|; 
$noresave{$key} = "$nosave";

$key = q/progs-syncnode/;
$external_latex_labels{$key} = q|6.6|; 
$noresave{$key} = "$nosave";

$key = q/config-sysimage/;
$external_latex_labels{$key} = q|A|; 
$noresave{$key} = "$nosave";

$key = q/conf-nodeclasssyntax/;
$external_latex_labels{$key} = q|5.2.1|; 
$noresave{$key} = "$nosave";

$key = q/boot-config/;
$external_latex_labels{$key} = q|3.3.7|; 
$noresave{$key} = "$nosave";

$key = q/fig-linkback/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

1;

