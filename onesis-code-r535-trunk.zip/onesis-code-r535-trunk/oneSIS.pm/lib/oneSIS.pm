# oneSIS perl module             -*- cperl -*-
# Author: Josh England <jjengla@gmail.com>
# This file contains many functions and classes common to all oneSIS scripts.
# Much of the actual heavy stuff is done by these functions.
#
# Copyright (2004-2007) Josh England, Sandia Corporation.
# Copyright (2008-2017) Josh England
# Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
# the U.S. Government retains certain rights in this software
#
#    This file is part of oneSIS (http://onesis.sourceforge.net).
#
#    oneSIS is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    any later version.
#
#    oneSIS is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with oneSIS; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
###############################################################################
our (@ISA, @EXPORT);
our $VERSION = '2.0.5';

package oneSIS;
use strict;
use warnings;
use File::Find;
use File::Copy;
use File::Glob ':glob';

require Exporter;
@EXPORT = qw(&parse_config
             &parse_ramfs_config
             &get_config
	     &get_hostname
	     &get_node_class
             &get_host_ips
             &get_range
             &expand_range
             &match_range
             &match_nodespecs
             &fork_parallel
             &mount_dev
             &get_ramdisk_size
             &update_ramdisk_elems
	     &setup_localdisks
             &transform_path
             &file_globs
             &mk_path
             &differs
             &copy_file
             &copy_dir
             &mirror_props
             $debug
);

# Global debug flag
our $debug = 0;
our $dryrun = 0;
our $quiet = 0;
our $verbose = 0;
our $main_config = undef;

sub parse_config {
# Desc: Parses configuration from specified file (normally /etc/sysimage.conf).
#       If an existing config is given, parsed directives are appended to
#       the end, superceding directives in the existing config.
# Input: 1) $  I   config file full pathname
#        2) $  I?   Optional oneSIS::config object
# Returns: $ oneSIS::config object
#          undef: on error
  my ($configfile, $config) = @_;
  if (! defined $config) {
    # Create new configuration object
    $config = new oneSIS::config();
  }

  if (!defined $configfile) {
    return undef;
  }

  # Parse the configuration file into the configuration object
  local *CONFIG;
  open(CONFIG, "<$configfile") or die "oneSIS: Could not open $configfile: $!\n";
 LINE:  while (defined (my $line = <CONFIG>)) {
    # Trim off trailing whitespace and comments
    $line =~ s/[\s\t]*(\#.*)?$//;
    chomp $line;

    if ($line =~ /^[\s\t]*DISTRO:?[\s\t]+(\S+)([\s\t]+(\S+))??
            (
             ([\s\t]+-sp)?   # match optional SKIPPATCH flag
              |([\s\t]+-kn)?  # match optional KEEPNET glag
            )+
         $/x) {
      my ($distro_name, $distro_version) = ($1, $3);
      my $options = $line;
      $options =~ s/^[\s\t]*DISTRO:?[\s\t]+(\S+)([\s\t]+(\S+))??//;

      # Convert distro name and version to lowercase
      $distro_name =~ s/(.)/\l$1/g;
      $distro_version =~ s/(.)/\l$1/g if defined $distro_version;
      $config->distro_name($distro_name);
      $config->distro_version($distro_version);
      $config->add_directive($line);

      # Loop over supplied options
      if ($options =~ /-sp/) {
	$config->skippatch(1);
      }
      if ($options =~ /-kn/) {
	$config->keepnet(1);
      }
    }
    elsif ($line =~ /^[\s\t]*NODECLASS_(MAP|REGEXP|RANGE):?[\s\t]+(\S+)[\s\t]+(\S+)
            $/x) {
      my ($type, $desc, $classname) = ($1, $2, $3);
      my $class = $config->add_class($classname, $desc, $type);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*PROPERTY:?[\s\t]+(\S+)
            (
             ([\s\t]+-c\s\S+)?   # match optional CLASS
              |([\s\t]+-n\s\S+)?  # match optional NODE
              |([\s\t]+-r\s\S+)?  # match optional RANGE
              |([\s\t]+-re\s\S+)?  # match optional REGEXP
            )+
            $/x) {
      my $propname = $1;
      my $options = $line;
      $options =~ s/^[\s\t]*PROPERTY:?[\s\t]+(\S+)//;

      my $property = undef;
      if (! defined ($property = $config->get_property($propname))) {
	$property = $config->add_property($propname)
      }
      if (!defined $property) {
	warn "oneSIS: Warning! Error adding property to config: '$propname'\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      while ($options =~ /-([cnr]|re)[\s\t]+(\S+)/g) {
	my ($option, $value) = ($1, $2);
	if ($option eq 'c') {
	  foreach my $myclass (split ',', $value) {
	    if ($config->class_exists($myclass)) {
	      $property->modifier()->classes($myclass);
	    }
	    else {
	      warn "oneSIS: Config error(1): Undefined node class specified: '$myclass'\n";
	      warn "*  *  * $line\n";
	      $property->modifier()->classes('__oneSIS_Invalid__');
	    }
	  }
	}
	elsif ($option eq 'n') {
	  foreach my $mynode (split ',', $value) {
	    $property->modifier()->nodes($mynode);
	  }
	}
	elsif ($option eq 'r') {
	  $property->modifier()->ranges($value);
	}
	elsif ($option eq 're') {
	  $property->modifier()->regexps($value);
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*SERVICE:?[\s\t]+(\S+)
            (
             ([\s\t]+-c\s\S+)?   # match optional CLASS
              |([\s\t]+-n\s\S+)?  # match optional NODE
              |([\s\t]+-p\s\S+)?  # match optional PROPERTY
            )+
            $/x) {
      my $servicename = $1;
      my $options = $line;
      $options =~ s/^[\s\t]*SERVICE:?[\s\t]+(\S+)//;

      my $service = $config->add_service($servicename);
      if (!defined $service) {
	warn "oneSIS: Warning! Error adding service to config: '$service'\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      my $ramdisk_elem = $service->ramdisk_elem();
      # Loop over supplied options
      while ($options =~ /-([cnp])[\s\t]+(\S+)/g) {
	my ($option, $value) = ($1, $2);
	if ($option eq 'c') {
	  foreach my $myclass (split ',', $value) {
	    my $tmpclass = $myclass; $tmpclass =~ s/^!//;
	    if ($config->class_exists($tmpclass)) {
	      $ramdisk_elem->modifier()->classes($myclass);
	    }
	    else {
	      warn "oneSIS: Config error(1): Undefined node class specified: '$myclass'\n";
	      warn "*  *  * $line\n";
	      $ramdisk_elem->modifier()->classes('__oneSIS_Invalid__');
	    }
	  }
	}
	elsif ($option eq 'n') {
	  foreach my $mynode (split ',', $value) {
	    $ramdisk_elem->modifier()->nodes($mynode);
	  }
	}
	elsif ($option eq 'p') {
	  foreach my $prop (split ',', $value) {
	    my $tmpprop = $prop; $tmpprop =~ s/^!//;
	    if (defined $config->get_property($tmpprop)) {
	      $ramdisk_elem->modifier()->properties($prop);
	    }
	    else {
	      warn "oneSIS: Config error(1): Undefined property specified: '$tmpprop'\n";
	      warn "*  *  * $line\n";
	      $ramdisk_elem->modifier()->properties('__oneSIS_Invalid__');
	    }
	  }
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*((LINK|RAM)(FILE|DIR)):?[\s\t]+(\S+|"[^"]+")
            (
             (
              ([\s\t]+-c\s\S+)?   # match optional CLASS
              |([\s\t]+-n\s\S+)?  # match optional NODE
              |([\s\t]+-p\s\S+)?  # match optional PROPERTY
             )*
             |([\s\t]+-m\s\S+)?   # match optional mode
             |([\s\t]+-u\s\S+)?   # match optional user
             |([\s\t]+-g\s\S+)?   # match optional group
             |([\s\t]+-d)?        # match optional duplicate flag
             |([\s\t]+-cl)?       # match optional clean flag
            )*
            $/x) {
      my ($type, $path) = ($1, $4);
      $path =~ s/^"(.*)"$/$1/;
      my $options = $line;
      $options =~ s/^[\s\t]*((LINK|RAM)(FILE|DIR)):?[\s\t]+(\S+)//;

      my $ramdisk_elem = $config->add_ramdisk_elem($path, $type);
      if (!defined $ramdisk_elem) {
	warn "oneSIS: Warning! Error adding ramdisk element to config:\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      $ramdisk_elem->protected(1);

      # Loop over supplied options
      while ($options =~ /-([cnpmugd]|cl)(?:[\s\t]+([^-]\S*))?/g) {
	my ($option, $value) = ($1, $2);
	if ($option eq 'c') {
	  foreach my $myclass (split ',', $value) {
	    my $tmpclass = $myclass; $tmpclass =~ s/^!//;
	    if ($config->class_exists($tmpclass)) {
	      $ramdisk_elem->modifier()->classes($myclass);
	    }
	    else {
	      warn "oneSIS: Config error(2): Undefined node class specified: '$myclass'\n";
	      warn "*  *  * $line\n";
	      $ramdisk_elem->modifier()->classes('__oneSIS_Invalid__');
	    }
	  }
	}
	elsif ($option eq 'n') {
	  foreach my $mynode (split ',', $value) {
	    $ramdisk_elem->modifier()->nodes($mynode);
	  }
	}
	elsif ($option eq 'p') {
	  foreach my $prop (split ',', $value) {
	    my $tmpprop = $prop; $tmpprop =~ s/^!//;
	    if (defined $config->get_property($tmpprop)) {
	      $ramdisk_elem->modifier()->properties($prop);
	    }
	    else {
	      warn "oneSIS: Config error(2): Undefined property specified: '$tmpprop'\n";
	      warn "*  *  * $line\n";
	      $ramdisk_elem->modifier()->properties('__oneSIS_Invalid__');
	    }
	  }
	}
	elsif (($type =~ /LINK/) && ($option eq 'm' || $option eq 'u' ||
				     $option eq 'g')) {
	  warn "oneSIS: Config error: Directive does not support the '$option' option:\n";
	  warn "*  *  * $line\n";
	}
	elsif ($option eq 'd') {
	  $ramdisk_elem->duplicate(1);
	}
	elsif ($option eq 'cl') {
	  $ramdisk_elem->protected(0);
	}
	elsif ($option eq 'm') {
	  if (defined $ramdisk_elem->file_elem()->mode()) {
	    warn "oneSIS: Config error: Multiple modes specified in line:\n";
	    warn "*  *  * $line\n";
	  }
	  else {
	    $ramdisk_elem->file_elem()->mode($value);
	  }
	}
	elsif ($option eq 'u') {
	  if (defined $ramdisk_elem->file_elem()->user()) {
	    warn "oneSIS: Config error: Multiple users specified in line:\n";
	    warn "*  *  * $line\n";
	  }
	  else {
	    $ramdisk_elem->file_elem()->user($value);
	  }
	}
	elsif ($option eq 'g') {
	  if (defined $ramdisk_elem->file_elem()->group()) {
	    warn "oneSIS: Config error: Multiple groups specified in line:\n";
	    warn "*  *  * $line\n";
	  }
	  else {
	    $ramdisk_elem->file_elem()->group($value);
	  }
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*(LINKBACK):?[\s\t]+(\S+)[\s\t]+(\*[\s\t]+)?(\S+)
            (
             (
              ([\s\t]+-c\s\S+)?   # match optional CLASS
              |([\s\t]+-n\s\S+)?  # match optional NODE
              |([\s\t]+-p\s\S+)?  # match optional PROPERTY
             )*
             |([\s\t]+-h)?        # match optional hide flag
             |([\s\t]+-f)?        # match optional forced flag
            )*
            $/x) {
      my ($type, $path, $forced, $target) = ($1, $2, $3, $4);
      my $options = $line;
      $options =~ s/^[\s\t]*(LINKBACK):?[\s\t]+(\S+)[\s\t]+(\*[\s\t]+)?(\S+)//;

      if ($target eq 'PROPERTY' && $options =~ /-f/) {
	warn "oneSIS: Warning! Forcing a property-based linkback is not supported:\n";
	warn "*  *  * $line\n";
	next LINE;
      }

      my $ramdisk_elem = $config->add_ramdisk_elem($path, $type);
      if (!defined $ramdisk_elem) {
	warn "oneSIS: Warning! Error adding ramdisk element to config:\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      $ramdisk_elem->linkback($target);
      if (defined $forced) {
	$ramdisk_elem->forced(1);
      }
      # Loop over supplied options
      while ($options =~ /-([cnphf])(?:[\s\t]+([^-]\S*))?/g) {
	my ($option, $value) = ($1, $2);
	if ($option eq 'h') {
	  $ramdisk_elem->hidden(1);
	}
	elsif ($option eq 'f') {
	  $ramdisk_elem->forced(1);
	}
	elsif ($option eq 'c') {
	  foreach my $myclass (split ',', $value) {
	    my $tmpclass = $myclass; $tmpclass =~ s/^!//;
	    if ($config->class_exists($tmpclass)) {
	      $ramdisk_elem->modifier()->classes($myclass);
	    }
	    else {
	      warn "oneSIS: Config error(3): Undefined node class specified: '$myclass'\n";
	      warn "*  *  * $line\n";
	      $ramdisk_elem->modifier()->classes('__oneSIS_Invalid__');
	    }
	  }
	}
	elsif ($option eq 'n') {
	  foreach my $mynode (split ',', $value) {
	    $ramdisk_elem->modifier()->nodes($mynode);
	  }
	}
	elsif ($option eq 'p') {
	  foreach my $prop (split ',', $value) {
	    my $tmpprop = $prop; $tmpprop =~ s/^!//;
	    if (defined $config->get_property($tmpprop)) {
	      $ramdisk_elem->modifier()->properties($prop);
	    }
	    else {
	      warn "oneSIS: Config error(3): Undefined property specified: '$tmpprop'\n";
	      warn "*  *  * $line\n";
	      $ramdisk_elem->modifier()->properties('__oneSIS_Invalid__');
	    }
	  }
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*RAMSIZE:?[\s\t]+(\d+)[\s\t]*([kKmMgG])?
            (
             ([\s\t]+-c\s\S+)?   # match optional CLASS
             |([\s\t]+-n\s\S+)?  # match optional NODE
             |([\s\t]+-p\s\S+)?  # match optional PROPERTY
            )*
            $/x) {
      my ($size, $unit) = ($1, $2);
      my $options = $line;
      $options =~ s/^[\s\t]*RAMSIZE:?[\s\t]+(\d+)[\s\t]*([kKmMgG])?//;

      my $ramdisk = $config->add_ramdisk($size, $unit);
      if (!defined $ramdisk) {
	warn "oneSIS: Warning! Error adding ramdisk size to config:\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      # Loop over supplied options
      while ($options =~ /-([cnp])[\s\t]+(\S+)/g) {
	my ($option, $value) = ($1, $2);
	if ($option eq 'c') {
	  foreach my $myclass (split ',', $value) {
	    my $tmpclass = $myclass; $tmpclass =~ s/^!//;
	    if ($config->class_exists($tmpclass)) {
	      $ramdisk->modifier()->classes($myclass);
	    }
	    else {
	      warn "oneSIS: Config error(4): Undefined node class specified: '$myclass'\n";
	      warn "*  *  * $line\n";
	      $ramdisk->modifier()->classes('__oneSIS_Invalid__');
	    }
	  }
	}
	elsif ($option eq 'n') {
	  foreach my $mynode (split ',', $value) {
	    $ramdisk->modifier()->nodes($mynode);
	  }
	}
	elsif ($option eq 'p') {
	  foreach my $prop (split ',', $value) {
	    my $tmpprop = $prop; $tmpprop =~ s/^!//;
	    if (defined $config->get_property($tmpprop)) {
	      $ramdisk->modifier()->properties($prop);
	    }
	    else {
	      warn "oneSIS: Config error(4): Undefined property specified: '$tmpprop'\n";
	      warn "*  *  * $line\n";
	      $ramdisk->modifier()->properties('__oneSIS_Invalid__');
	    }
	  }
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*(DISK|DEPLOY)MOUNT:?[\s\t]+((?:[^-\s\t]+,?)+)[\s\t]+(\d+\%?)[\s\t]+(\S+)
            (
             (
              ([\s\t]+-c\s\S+)?   # match optional CLASS
              |([\s\t]+-n\s\S+)?  # match optional NODE
              |([\s\t]+-p\s\S+)?  # match optional PROPERTY
             )*
             |([\s\t]+-t\s\S+)?   # match optional filesystem type
             |([\s\t]+-r\s\d+)?   # match optional raid level
             |([\s\t]+-l\s\S+)?   # match optional filesystem label
             |([\s\t]+-f)?        # match optional fastmount flag
	     |([\s\t]+-nm)?       # match optional nomount flag (DISKMOUNT only)
            )*
            $/x) {
      my ($type, $disks, $size, $mountpoint) = ($1, $2, $3, $4);
      my @disks;
      map {push @disks, $_} split(',', $disks);
      my $options = $line;
      $options =~ s/^[\s\t]*(DISK|DEPLOY)MOUNT:?[\s\t]+((?:[^-\s\t]+,?)+)[\s\t]+(\d+\%?)[\s\t]+(\S+)//;

      my $localdisk_elem = undef;
      if ($type eq 'DISK') {
	$localdisk_elem = $config->add_localdisk_elem(\@disks, 'MOUNT', $size, $mountpoint);
      }
      else {
	$localdisk_elem = $config->add_deploydisk_elem(\@disks, 'MOUNT', $size, $mountpoint);
      }
      if (!defined $localdisk_elem) {
	warn "oneSIS: Warning! Error adding local disk element to config:\n";
	warn "*  *  * $line\n";
	next LINE;
      }

      # Set default label
      $localdisk_elem->label($mountpoint);

      # Loop over supplied options
      while ($options =~ /-([cnptrlf]|nm)(?:[\s\t]+([^-]\S*))?/g) {
	my ($option, $value) = ($1, $2);
	if ($option eq 't') {
	  if (! defined $localdisk_elem->fstype($value)) {
	    warn "oneSIS: Warning! Unsupported filesytem type: $value\n";
	    warn "*  *  * $line\n";
	  }
	}
	if ($option eq 'r') {
	  if (! defined $localdisk_elem->raidlevel($value)) {
	    warn "oneSIS: Warning! Unsupported raid level: $value\n";
	    warn "*  *  * $line\n";
	  }
	}
	elsif ($option eq 'l') {
	  $localdisk_elem->label($value);
	}
	elsif ($option eq 'f') {
	  $localdisk_elem->fastmount(1);
	}
	elsif ($option eq 'nm') {
	  $localdisk_elem->nomount(1);
	}
	elsif ($option eq 'c') {
	  foreach my $myclass (split ',', $value) {
	    my $tmpclass = $myclass; $tmpclass =~ s/^!//;
	    if ($config->class_exists($tmpclass)) {
	      $localdisk_elem->modifier()->classes($myclass);
	    }
	    else {
	      warn "oneSIS: Config error(5): Undefined node class specified: '$myclass'\n";
	      warn "*  *  * $line\n";
	      $localdisk_elem->modifier()->classes('__oneSIS_Invalid__');
	    }
	  }
	}
	elsif ($option eq 'n') {
	  foreach my $mynode (split ',', $value) {
	    $localdisk_elem->modifier()->nodes($mynode);
	  }
	}
	elsif ($option eq 'p') {
	  foreach my $prop (split ',', $value) {
	    my $tmpprop = $prop; $tmpprop =~ s/^!//;
	    if (defined $config->get_property($tmpprop)) {
	      $localdisk_elem->modifier()->properties($prop);
	    }
	    else {
	      warn "oneSIS: Config error(5): Undefined property specified: '$tmpprop'\n";
	      warn "*  *  * $line\n";
	      $localdisk_elem->modifier()->properties('__oneSIS_Invalid__');
	    }
	  }
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*(DISK|DEPLOY)SWAP:?[\s\t]+((?:[^-\s\t]+,?)+)[\s\t]+(\d+\%?)
            (
             (
              ([\s\t]+-c\s\S+)?   # match optional CLASS
              |([\s\t]+-n\s\S+)?  # match optional NODE
              |([\s\t]+-p\s\S+)?  # match optional PROPERTY
             )*
             |([\s\t]+-r\s\d+)?   # match optional raid level
            )*
            $/x) {
      my ($type, $disks, $size) = ($1, $2, $3);
      my @disks;
      map {push @disks, $_} split(',', $disks);
      my $options = $line;
      $options =~ s/^[\s\t]*(DISK|DEPLOY)SWAP:?[\s\t]+((?:[^-\s\t]+,?)+)[\s\t]+(\d+\%?)//;

      my $localdisk_elem = undef;
      if ($type eq 'DISK') {
	$localdisk_elem = $config->add_localdisk_elem(\@disks, 'SWAP', $size);
      }
      else {
	$localdisk_elem = $config->add_deploydisk_elem(\@disks, 'SWAP', $size);
      }
      if (!defined $localdisk_elem) {
	warn "oneSIS: Warning! Error adding local disk element to config.\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      # Loop over supplied options
      while ($options =~ /-([cnpr])(?:[\s\t]+([^-]\S*))?/g) {
	my ($option, $value) = ($1, $2);
	if ($option eq 'r') {
	  if (! defined $localdisk_elem->raidlevel($value)) {
	    warn "oneSIS: Warning! Unsupported raid level: $value\n";
	    warn "*  *  * $line\n";
	  }
	}
	elsif ($option eq 'c') {
	  foreach my $myclass (split ',', $value) {
	    my $tmpclass = $myclass; $tmpclass =~ s/^!//;
	    if ($config->class_exists($tmpclass)) {
	      $localdisk_elem->modifier()->classes($myclass);
	    }
	    else {
	      warn "oneSIS: Config error(6): Undefined node class specified: '$myclass'\n";
	      warn "*  *  * $line\n";
	      $localdisk_elem->modifier()->classes('__oneSIS_Invalid__');
	    }
	  }
	}
	elsif ($option eq 'n') {
	  foreach my $mynode (split ',', $value) {
	    $localdisk_elem->modifier()->nodes($mynode);
	  }
	}
	elsif ($option eq 'p') {
	  foreach my $prop (split ',', $value) {
	    my $tmpprop = $prop; $tmpprop =~ s/^!//;
	    if (defined $config->get_property($tmpprop)) {
	      $localdisk_elem->modifier()->properties($prop);
	    }
	    else {
	      warn "oneSIS: Config error(6): Undefined property specified: '$tmpprop'\n";
	      warn "*  *  * $line\n";
	      $localdisk_elem->modifier()->properties('__oneSIS_Invalid__');
	    }
	  }
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*BOOTLOADER:?[\s\t]+(\S+)
            (
             ([\s\t]+-c\s\S+)?   # match optional CLASS
             |([\s\t]+-n\s\S+)?  # match optional NODE
             |([\s\t]+-p\s\S+)?  # match optional PROPERTY
            )*
            $/x) {
      my ($bloader) = ($1);
      my $options = $line;
      $options =~ s/^[\s\t]*BOOTLOADER:?[\s\t]+(\S+)//;

      my $bloaderObj = $config->add_bootloader($bloader);
      if (!defined $bloaderObj) {
	warn "oneSIS: Warning! Error adding bootloader to config.\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      # Loop over supplied options
      while ($options =~ /-([cnp])[\s\t]+(\S+)/g) {
	my ($option, $value) = ($1, $2);
	if ($option eq 'c') {
	  foreach my $myclass (split ',', $value) {
	    my $tmpclass = $myclass; $tmpclass =~ s/^!//;
	    if ($config->class_exists($tmpclass)) {
	      $bloaderObj->modifier()->classes($myclass);
	    }
	    else {
	      warn "oneSIS: Config error(7): Undefined node class specified: '$myclass'\n";
	      warn "*  *  * $line\n";
	      $bloaderObj->modifier()->classes('__oneSIS_Invalid__');
	    }
	  }
	}
	elsif ($option eq 'n') {
	  foreach my $mynode (split ',', $value) {
	    $bloaderObj->modifier()->nodes($mynode);
	  }
	}
	elsif ($option eq 'p') {
	  foreach my $prop (split ',', $value) {
	    my $tmpprop = $prop; $tmpprop =~ s/^!//;
	    if (defined $config->get_property($tmpprop)) {
	      $bloaderObj->modifier()->properties($prop);
	    }
	    else {
	      warn "oneSIS: Config error(7): Undefined property specified: '$tmpprop'\n";
	      warn "*  *  * $line\n";
	      $bloaderObj->modifier()->properties('__oneSIS_Invalid__');
	    }
	  }
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*SYNCDIR:?[\s\t]+(\S+)
            (
             ([\s\t]+-c\s\S+)?   # match optional CLASS
             |([\s\t]+-n\s\S+)?  # match optional NODE
             |([\s\t]+-p\s\S+)?  # match optional PROPERTY
            )*
            $/x) {
      my ($syncdir) = ($1);
      my $options = $line;
      $options =~ s/^[\s\t]*SYNCDIR:?[\s\t]+(\S+)//;

      my $pathObj = $config->add_syncdir($syncdir);
      if (!defined $pathObj) {
	warn "oneSIS: Warning! Error adding syncdir to config.\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      # Loop over supplied options
      while ($options =~ /-([cnp])[\s\t]+(\S+)/g) {
	my ($option, $value) = ($1, $2);
	if ($option eq 'c') {
	  foreach my $myclass (split ',', $value) {
	    my $tmpclass = $myclass; $tmpclass =~ s/^!//;
	    if ($config->class_exists($tmpclass)) {
	      $pathObj->modifier()->classes($myclass);
	    }
	    else {
	      warn "oneSIS: Config error(8): Undefined node class specified: '$myclass'\n";
	      warn "*  *  * $line\n";
	      $pathObj->modifier()->classes('__oneSIS_Invalid__');
	    }
	  }
	}
	elsif ($option eq 'n') {
	  foreach my $mynode (split ',', $value) {
	    $pathObj->modifier()->nodes($mynode);
	  }
	}
	elsif ($option eq 'p') {
	  foreach my $prop (split ',', $value) {
	    my $tmpprop = $prop; $tmpprop =~ s/^!//;
	    if (defined $config->get_property($tmpprop)) {
	      $pathObj->modifier()->properties($prop);
	    }
	    else {
	      warn "oneSIS: Config error(8): Undefined property specified: '$tmpprop'\n";
	      warn "*  *  * $line\n";
	      $pathObj->modifier()->properties('__oneSIS_Invalid__');
	    }
	  }
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*EXCLUDE(SYNC|DEPLOY):?[\s\t]+(\S+)
            (
             ([\s\t]+-c\s\S+)?   # match optional CLASS
             |([\s\t]+-n\s\S+)?  # match optional NODE
             |([\s\t]+-p\s\S+)?  # match optional PROPERTY
            )*
            $/x) {
      my ($type, $path) = ($1, $2);
      my $options = $line;
      $options =~ s/^[\s\t]*EXCLUDE(SYNC|DEPLOY):?[\s\t]+(\S+)//;

      my $pathObj;
      if ($type eq 'SYNC') {
	$pathObj = $config->add_excludesync($path);
      }
      elsif ($type eq 'DEPLOY') {
	$pathObj = $config->add_excludedeploy($path);
      }
      if (!defined $pathObj) {
	warn "oneSIS: Warning! Error adding excludesync to config.\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      # Loop over supplied options
      while ($options =~ /-([cnp])[\s\t]+(\S+)/g) {
	my ($option, $value) = ($1, $2);
	if ($option eq 'c') {
	  foreach my $myclass (split ',', $value) {
	    my $tmpclass = $myclass; $tmpclass =~ s/^!//;
	    if ($config->class_exists($tmpclass)) {
	      $pathObj->modifier()->classes($myclass);
	    }
	    else {
	      warn "oneSIS: Config error(9): Undefined node class specified: '$myclass'\n";
	      warn "*  *  * $line\n";
	      $pathObj->modifier()->classes('__oneSIS_Invalid__');
	    }
	  }
	}
	elsif ($option eq 'n') {
	  foreach my $mynode (split ',', $value) {
	    $pathObj->modifier()->nodes($mynode);
	  }
	}
	elsif ($option eq 'p') {
	  foreach my $prop (split ',', $value) {
	    my $tmpprop = $prop; $tmpprop =~ s/^!//;
	    if (defined $config->get_property($tmpprop)) {
	      $pathObj->modifier()->properties($prop);
	    }
	    else {
	      warn "oneSIS: Config error(9): Undefined property specified: '$tmpprop'\n";
	      warn "*  *  * $line\n";
	      $pathObj->modifier()->properties('__oneSIS_Invalid__');
	    }
	  }
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*MAC_ADDR:?[\s\t]+(\S+)[\s\t]+(\S+)
            $/x) {
      my ($hostname, $mac_addr) = ($1, $2);
      if (! defined $config->add_mac_addr($hostname, $mac_addr)) {
	warn "oneSIS: Config error: Invalid MAC address: '$mac_addr'\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*INCLUDE:?[\s\t]+(\S+)
            $/x) {
      my ($include) = ($1);
      # Try to extract the basedir from the original config file,
      # otherwise assume an absolute path from wherever this is running
      my $basedir = '/';
      if ($configfile =~ m|(.*)/etc/sysimage.conf$|) {
	$basedir = $1;
      }
      if (! -e "$basedir/$include") {
	warn "oneSIS: Warning! Specified include file doesn't exist.\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      parse_config("$basedir/$include", $config);
    }
    elsif ($line =~ /^[\s\t]*SPECFORMAT:?[\s\t]+(\S+)[\s\t]+(\S+)([\s\t]+(HOST|IP):(\S+))?([\s\t]+SPEC:(\S+))?
            $/x) {
      my ($spec_id, $format, $trans_type, $trans1, $trans2) = ($1,$2,$4,$5,$7);
      my $specformat = $config->add_specformat($spec_id, $format);
      if (!defined $specformat) {
	warn "oneSIS: Config error: Invalid SPECFORMAT:\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      if (defined $trans1) {
	if (!defined ($specformat->add_translation($trans1, $trans_type))) {
	  warn "oneSIS: Config error: Invalid SPECFORMAT:\n";
	  warn "*  *  * $line\n";
	  next LINE;
	}
      }
      if (defined $trans2) {
	if (!defined ($specformat->add_translation($trans2, 'SPEC'))) {
	  warn "oneSIS: Config error: Invalid SPECFORMAT:\n";
	  warn "*  *  * $line\n";
	  next LINE;
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*NODECMD:?[\s\t]+(\S+)
            (
             [\s\t]+-f\s\S+      # match optional function
             |([\s\t]+-c\s\S+)+  # match optional CLASS
             |([\s\t]+-n\s\S+)+  # match optional NODE
             |([\s\t]+-p\s\S+)+  # match optional PROPERTY
            )*
            [\s\t]+(.*)          # match actual command
            $/x) {
      my ($name, $options, $cmd) = ($1, $2, $6);
      my $nodecmd = $config->add_nodecmd($name, $cmd);
      if (! defined $nodecmd) {
	warn "oneSIS: Config error: Invalid NODECMD specification.\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      # Loop over supplied options
      if (defined $options) {
	while ($options =~ /-([cnpf])[\s\t]+(\S+)/g) {
	  my ($option, $value) = ($1, $2);
	  if ($option eq 'f') {
	    $nodecmd->function($value);
	  }
	  elsif ($option eq 'c') {
	    foreach my $myclass (split ',', $value) {
	    my $tmpclass = $myclass; $tmpclass =~ s/^!//;
	      if ($config->class_exists($tmpclass)) {
		$nodecmd->modifier()->classes($myclass);
	      }
	      else {
		warn "oneSIS: Config error(10): Undefined node class specified: '$myclass'\n";
		warn "*  *  * $line\n";
		$nodecmd->modifier()->classes('__oneSIS_Invalid__');
	      }
	    }
	  }
	  elsif ($option eq 'n') {
	    foreach my $mynode (split ',', $value) {
	      $nodecmd->modifier()->nodes($mynode);
	    }
	  }
	  elsif ($option eq 'p') {
	    foreach my $prop (split ',', $value) {
	      my $tmpprop = $prop; $tmpprop =~ s/^!//;
	      if (defined $config->get_property($tmpprop)) {
		$nodecmd->modifier()->properties($prop);
	      }
	      else {
		warn "oneSIS: Config error(10): Undefined property specified: '$tmpprop'\n";
		warn "*  *  * $line\n";
		$nodecmd->modifier()->properties('__oneSIS_Invalid__');
	      }
	    }
	  }
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*POWERCMD:?[\s\t]+(\S+)
            (
             ([\s\t]+-c\s\S+)+   # match optional CLASS
             |([\s\t]+-n\s\S+)+  # match optional NODE
             |([\s\t]+-p\s\S+)+  # match optional PROPERTY
            )*
            [\s\t]+(.*)          # match actual command
            $/x) {
      my ($function, $options, $cmd) = ($1, $2, $6);
      my $powercmd = $config->add_nodecmd('pwr', $cmd);
      if (! defined $powercmd) {
	warn "oneSIS: Config error: Invalid POWERCMD specification.\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      $powercmd->function($function);
      # Loop over supplied options
      if (defined $options) {
	while ($options =~ /-([cnp])[\s\t]+(\S+)/g) {
	  my ($option, $value) = ($1, $2);
	  if ($option eq 'c') {
	    foreach my $myclass (split ',', $value) {
	    my $tmpclass = $myclass; $tmpclass =~ s/^!//;
	      if ($config->class_exists($tmpclass)) {
		$powercmd->modifier()->classes($myclass);
	      }
	      else {
		warn "oneSIS: Config error(11): Undefined node class specified: '$myclass'\n";
		warn "*  *  * $line\n";
		$powercmd->modifier()->classes('__oneSIS_Invalid__');
	      }
	    }
	  }
	  elsif ($option eq 'n') {
	    foreach my $mynode (split ',', $value) {
	      $powercmd->modifier()->nodes($mynode);
	    }
	  }
	  elsif ($option eq 'p') {
	    foreach my $prop (split ',', $value) {
	      my $tmpprop = $prop; $tmpprop =~ s/^!//;
	      if (defined $config->get_property($tmpprop)) {
		$powercmd->modifier()->properties($prop);
	      }
	      else {
		warn "oneSIS: Config error(11): Undefined property specified: '$tmpprop'\n";
		warn "*  *  * $line\n";
		$powercmd->modifier()->properties('__oneSIS_Invalid__');
	      }
	    }
	  }
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*CONSOLECMD:?
            (
             ([\s\t]+-c\s\S+)+   # match optional CLASS
             |([\s\t]+-n\s\S+)+  # match optional NODE
             |([\s\t]+-p\s\S+)+  # match optional PROPERTY
            )*
            [\s\t]+(.*)          # match actual command
            $/x) {
      my ($options, $cmd) = ($1, $5);
      my $consolecmd = $config->add_nodecmd('consl', $cmd);
      if (! defined $consolecmd) {
	warn "oneSIS: Config error: Invalid CONSOLECMD specification.\n";
	warn "*  *  * $line\n";
	next LINE;
      }
      # Loop over supplied options
      if (defined $options) {
	while ($options =~ /-([cnp])[\s\t]+(\S+)/g) {
	  my ($option, $value) = ($1, $2);
	  if ($option eq 'c') {
	    foreach my $myclass (split ',', $value) {
	    my $tmpclass = $myclass; $tmpclass =~ s/^!//;
	      if ($config->class_exists($tmpclass)) {
		$consolecmd->modifier()->classes($myclass);
	      }
	      else {
		warn "oneSIS: Config error(12): Undefined node class specified: '$myclass'\n";
		warn "*  *  * $line\n";
		$consolecmd->modifier()->classes('__oneSIS_Invalid__');
	      }
	    }
	  }
	  elsif ($option eq 'n') {
	    foreach my $mynode (split ',', $value) {
	      $consolecmd->modifier()->nodes($mynode);
	    }
	  }
	  elsif ($option eq 'p') {
	    foreach my $prop (split ',', $value) {
	      my $tmpprop = $prop; $tmpprop =~ s/^!//;
	      if (defined $config->get_property($tmpprop)) {
		$consolecmd->modifier()->properties($prop);
	      }
	      else {
		warn "oneSIS: Config error(12): Undefined property specified: '$tmpprop'\n";
		warn "*  *  * $line\n";
		$consolecmd->modifier()->properties('__oneSIS_Invalid__');
	      }
	    }
	  }
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*ETH_PRELOAD:?
            [\s\t]+(\S+)          # match preload driver name(s)
            $/x) {
      my ($preload) = ($1);
      foreach my $driver (split ',', $preload) {
	my $eth_preload = $config->add_eth_preload($driver);
	if (! defined $eth_preload) {
	  warn "oneSIS: Config error: Problem adding driver '$driver' in ETH_PRELOAD specification.\n";
	  warn "*  *  * $line\n";
	  next;
	}
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*MATCH_DNS_HOSTS:?
            [\s\t]+(\S+)          # match boolean no,yes,0,1
            $/x) {
      my ($boolean) = ($1);
      my $match_dns = $config->match_dns_hosts($1);
      if (! defined $match_dns) {
	warn "oneSIS: Config error: MATCH_DNS_HOSTS requires boolean yes/no argument.\n";
	warn "*  *  * $line\n";
	next;
      }
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*(\#.*)?$/) {}  # Ignore comments and whitespace
    else {
      warn "oneSIS: Warning! Invalid line in config file:\n";
      warn "*  *  * $line\n";
    }
  }
  close(CONFIG);
  return $config;
}

sub parse_ramfs_config {
# Desc: Parses ramfs configuration file
#       If an existing config is given, parsed directives are appended to
#       the end, superceding directives in the existing config.
# Input: 1) $  I   config file full pathname
#        2) $  I?   Optional oneSIS::config object
# Returns: $ oneSIS::ramfs_config object
#          undef: on error
  my ($configfile, $config) = @_;
  if (!defined $configfile) {
    return undef;
  }

  if (! defined $config) {
    # Create new configuration object
    $config = new oneSIS::ramfs_config();
  }

  # Parse the configuration file into the configuration object
  local *CONFIG;
  open(CONFIG, "<$configfile") or die "oneSIS: Could not open $configfile: $!\n";
 LINE:  while (defined (my $line = <CONFIG>)) {
    # Trim off trailing whitespace and comments
    $line =~ s/[\s\t]*(\#.*)?$//;
    chomp $line;

    if ($line =~ /^[\s\t]*COPY:?[\s\t]+(\S+)
            (
             ([\s\t]+-r)?   # match optional RECURSIVE flag
             |([\s\t]+-n)?  # match optional NODEPLIBS flag
            )+
         $/x) {
      my ($path) = ($1);
      my $copypath = $config->add_ramfs_copy($path);
      $config->add_directive($line);

      # Loop over supplied options
      my $options = $line;
      $options =~ s/^[\s\t]*COPY:?[\s\t]+(\S+)//;
      while ($options =~ /-([rn])/g) {
	my ($option) = ($1);
	if ($options =~ /-r/) {
	  $copypath->recurse(1);
	}
	if ($options =~ /-n/) {
	  $copypath->nodeplibs(1);
	}
      }
    }
    elsif ($line =~ /^[\s\t]*RAMDISK_ROOT
         $/x) {
      $config->ramdisk_root(1);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*NOMOUNT
         $/x) {
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*NODHCP
         $/x) {
      $config->nodhcp(1);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*NONFS
         $/x) {
      $config->nonfs(1);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*DHCP_INTERFACE:?[\s\t]+(\S+)
         $/x) {
      my ($interface) = ($1);
      $config->add_dhcp_interface($interface);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*DHCP_RETRIES:?[\s\t]+(\S+)
         $/x) {
      my ($retries) = ($1);
      $config->dhcp_retries($retries);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*NFS_RETRIES:?[\s\t]+(\S+)
         $/x) {
      my ($retries) = ($1);
      $config->nfs_retries($retries);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*BOND_INTERFACES:?[\s\t]+(.*)
         $/x) {
      my ($interfaces) = ($1);
      $config->bond_interfaces($interfaces);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*NETWORK_CHECK:?[\s\t]+(\S+)
         $/x) {
      my ($tries) = ($1);
      $config->network_check($tries);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*AUTOMOUNT
         $/x) {
      $config->automount(1);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*SWAPON
         $/x) {
      $config->swapon(1);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*MOUNT_RW:?[\s\t]+(\S+)
         $/x) {
      my ($dir) = ($1);
      $config->add_mount_rw_dir($dir);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*MOUNT_ALL_RW
         $/x) {
      $config->mount_all_rw(1);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*NOMODPROBE
         $/x) {
      $config->nomodprobe(1);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*PCIMODS
         $/x) {
      $config->pcimods(1);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*SCSIMODS
         $/x) {
      $config->scsimods(1);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*MODULE:?[\s\t]+(\S+)
         $/x) {
      my ($module) = ($1);
      $config->add_module($module);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*PRELOAD:?[\s\t]+(\S+)
         $/x) {
      my ($preload) = ($1);
      $config->add_module($preload);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*OVERLAY:?[\s\t]+(\S+)
         $/x) {
      my ($overlay) = ($1);
      $config->add_overlay($overlay);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*RAM_OVERLAY:?(?:[\s\t]+(\d+[\s\t]*[kKmMgG]?))?
            $/x) {
      my ($size) = ($1);
      $size = 0 if !defined $size;
      $config->ram_overlay($size);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*INITRD
         $/x) {
      $config->initrd(1);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*INITRD_SIZE:?[\s\t]+(\S+)
         $/x) {
      my ($size) = ($1);
      $config->initrd_size($size);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*INITRD_BUFFER:?[\s\t]+(\S+)
         $/x) {
      my ($buffer) = ($1);
      $config->initrd_buffer($buffer);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*RESUME_FROM:?[\s\t]+(\S+)
         $/x) {
      my ($device) = ($1);
      $config->resume_from($device);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*SETUP_RAID
         $/x) {
      $config->setup_raid(1);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*TEMPLATE:?[\s\t]+(\S+)
         $/x) {
      my ($template) = ($1);
      $config->template($template);
      $config->add_directive($line);
    }
    elsif ($line =~ /^[\s\t]*(\#.*)?$/) {}  # Ignore comments and whitespace
    else {
      warn "oneSIS: Warning! Invalid line in ramfs config file:\n";
      warn "*  *  * $line\n";
    }
  }
  close(CONFIG);
  return $config;
}

sub get_hostname {
# Desc: Returns the hostname of this node.  The hostname is usually given
#       by DHCP and set in the initrd.  If the hostname of the node
#       isn't set, it tries to match a hostname from A MAC_ADDR directive,
#       then from a kernel commandline parameter (hostname=), then
#       from /etc/oneSIS/hostname
# Input: 1) $  I    oneSIS::config object
# Returns: $ hostname
#          undef: on error or empty hostname
  my ($config) = @_;
  if ($#_ != 0) {
    return undef;
  }
  my $hostname = `/bin/hostname`;
  chomp $hostname;

  # If no hostname is set, attempt to match hostname from a MAC_ADDR directive
  # then from the kernel commandline
  if ($hostname =~ /^$|localhost|\(none\)/) {
    my $got_hostname = 0;
    foreach my $mac (@{$config->get_all_mac_addrs()}) {
      my $match = `/sbin/ifconfig -a |/bin/grep $mac`;
      if ($match ne '') {
	$hostname = $config->get_hostname_from_mac_addr($mac);
	$got_hostname = 1;
      }
    }
    # attempt to get hostname from /proc/cmdline
    unless ($got_hostname) {
      if (!open(CMDLINE, "</proc/cmdline")) {
	warn "oneSIS: Error! Could not open /proc/cmdline: $!\n";
      }
      else {
	while (defined ($_ = <CMDLINE>)) {
	  if (/(?:^|[\s\t]+)hostname=(\S+)/) {
	    $hostname = $1;
	    $got_hostname = 1;
	  }
	}
	close CMDLINE;
      }
    }
    # another attempt to get hostname from /etc/hosts if ip is in there
    unless ($got_hostname) {
      if (!open(CMDLINE, "</proc/cmdline")) {
	warn "oneSIS: Error! Could not open /proc/cmdline: $!\n";
      }
      else {
	my @hiparray = ();
	while (defined ($_ = <CMDLINE>)) {
	  if (/(?:^|[\s\t]+)ip=(.*)/) {
	    @hiparray = split(/:/, $1);
	  }
	}
	close CMDLINE;
	# grep for ip in /etc/hosts
	if ($hiparray[0]) {
	  if (open(HOSTS, "</etc/hosts")) {
	    $hiparray[0] =~ s/\./\\./g;
	    $hostname = (grep /^\s*$hiparray[0]\s+\S+/, <HOSTS>)[0];
	    $hostname = defined $hostname ? (split /\s+/, $hostname)[1] : '';
	    $got_hostname = 1 if $hostname;
	    close(HOSTS);
	  } else {
	    warn "Couldn't open /etc/hosts: $!";
	  }
	}
      }
    }
    # Attempt to get hostname from hard-coded config file
    # (useful for diskfull nodes)
    unless ($got_hostname) {
      if (-e "/etc/oneSIS/hostname") {
	if (open(HOSTNAME, "</etc/oneSIS/hostname")) {
	  while (defined ($_ = <HOSTNAME>)) {
	    next if /^[\s\t]*\#/;
	    if (/^[\s\t]*(\S+)/) {
	      $hostname = $1;
	      $got_hostname = 1;
	    }
	  }
	  close HOSTNAME;
	}
      }
    }
    if ($got_hostname) {
      system("/bin/hostname $hostname");
    }
  }
  if ($hostname eq '') {
    return undef;
  }
  else {
    return $hostname;
  }
}

sub get_config {
# Desc: This routine is just an interface for retreiving a oneSIS
#       configuration from alternate sources.
# Input: 1) $  I?   config file full pathname (default: /etc/sysimage.conf)
# Returns: $ oneSIS::config object
# Populates: oneSIS::main_config
#          undef: on error
  my ($configfile) = @_;

  if (!defined $configfile) {
    $configfile = '/etc/sysimage.conf';
  }

  # Parse config file
  if (defined $main_config) {
    # Add to existing config
    $main_config = oneSIS::parse_config($configfile, $main_config);
  }
  else {
    # Create new configuration object
    $main_config = oneSIS::parse_config($configfile);
  }
  return $main_config;
}

sub get_node_class {
# Desc: Returns the class name of this node.
# Input: 1) $  I    oneSIS::config object
#        2) $  I    hostname of this node
# Returns: $ class name
#          undef: on error
  my ($config, $hostname) = @_;
  if ($#_ != 1) {
    return undef;
  }
  my $myclassname = 'default';
  my $got_classname = 0;

  # Attempt to get classname from /proc/cmdline
  if (!open(CMDLINE, "</proc/cmdline")) {
    warn "oneSIS: Error! Could not open /proc/cmdline: $!\n";
  }
  else {
    while (defined ($_ = <CMDLINE>)) {
      if (/(?:^|[\s\t]+)classname=(\S+)/) {
	$myclassname = $1;
	$got_classname = 1;
      }
    }
    close CMDLINE;
  }

  unless ($got_classname) {
    # Determine classname from NODECLASS directives
    foreach my $classdef (@{$config->get_all_classdefs()}) {
      my $classdesc = $classdef->desc();

      if ($classdef->type() eq 'MAP') {
	if ($hostname eq $classdesc) {
	  $myclassname = $classdef->name();
	}
      }
      elsif ($classdef->type() eq 'REGEXP') {
	if ($hostname =~ /^$classdesc$/) {
	  $myclassname = $classdef->name();
	}
      }
      elsif ($classdef->type() eq 'RANGE') {
	if (match_range($classdesc, $hostname)) {
	  $myclassname = $classdef->name();
	}
      }
    }
  }
  return $myclassname;
}

sub get_host_ips {
# Desc: Populate a hash of hostnames and IP addresses
# Input: None
# Returns: \% Hash  Key=hostname  Value=IP address
#          undef: on error
  my $hosts;

  # Grab hosts from DNS if specified
  if (defined $main_config) {
    if ($main_config->match_dns_hosts()) {
      $hosts = get_dns_host_ips();
    }
  }

  # Grab hosts from /etc/hosts
  if (!open (HOSTS, "</etc/hosts")) {
    warn "oneSIS: WARNING! Could not open /etc/hosts: $!\n";
    return undef;
  }
  else {
    while (defined ($_ = <HOSTS>)) {
      # trim off trailing whitespace and comments
      s/[\s\t]*(\#.*)?$//;
      if (/^[\s\t]*(\S+)(([\s\t]+(\S+))+)/) {
	my ($ip, $allhosts) = ($1, $2);
	while ($allhosts =~ /[\s\t]+(\S+)/g) {
	  my $hostname = $1;
	  # if (exists $$hosts{$hostname} && $$hosts{$hostname} ne $ip) {
	  #   warn "oneSIS: WARNING! IP mismatch detected for host $hostname ($$hosts{$hostname} != $ip)\n";
	  # }
	  $$hosts{$hostname} = $ip;
	}
      }
    }
    close HOSTS;
  }
  return $hosts;
}

sub get_dns_host_ips {
# Desc: Populate a hash of hostnames and IP addresses from DNS
# Input: None
# Returns: \% Hash  Key=hostname  Value=IP address
#          undef: on error
  my %hosts;
  if (!open (RESOLV, "</etc/resolv.conf")) {
    warn "oneSIS: WARNING! Could not open /etc/resolv.conf: $!\n";
    return undef;
  }
  else {
    while (defined ($_ = <RESOLV>)) {
      # Trim off trailing whitespace and comments
      s/[\s\t]*(\#.*)?$//;
      if (/^[\s\t]*(domain|search)\s+(.*)/) {
	my ($domains) = ($2);
	for my $domain (split /\s+/, $domains) {
	  # Do a zone transfer on the domain to determine all host names
	  my @zone = `dig $domain AXFR`;
	  if ($? >> 8) {
	    warn "oneSIS: WARNING! Could not perform zone transfer for zone $domain: $!\n";
	    return undef;
	  }
	  for my $line (@zone) {
	    next if $line =~ /^;/;
	    if ($line =~ /^(\S+).*IN\s+A\s+(\S+)/) {
	      my ($host, $ip) = ($1, $2);
	      $host =~ s/\.${domain}\.$//;
	      $hosts{$host} = $ip;
	    }
	  }
	}
      }
    }
    close RESOLV;
  }
  return \%hosts;
}

sub get_range {
# Desc: Builds a range expression from an array of hostnames.
# Input: 1) \@ I    array of hostnames
#        2) $? I    Optional flag to return space-seperated string
#                   instead of comma-seperated
# Returns: $ range expression
#          undef: on error
  my ($hosts, $space) = @_;
  if ($#_ < 0 || $#_ > 1) {
    return undef;
  }
  $space = 0 unless defined $space;

  my $specs = oneSIS::cmdbuilder::get_ext_range_specs($hosts, $space);
  my $range = '';
  for my $spec (@$specs) {
    $spec =~ s/\[(\d+)\]/$1/;
    $range .= ',' unless $range eq '';
    $range .= $spec;
  }
  return $range;
}

sub expand_range {
# Desc: Expand a range into an array of hostnames
# Input: 1) $  I   range string
# Returns: \@  Array of hostnames
  my $orig_range = $_[0];
  my @nodes;

  # Pick apart each range and create an array of hostnames
  for my $range (split(/([^\[,]+(?:\[\d+(?:-\d+)?(?:,\d+(?:-\d+)?)*\])?(?:[^,]*)),?/, $orig_range)) {
    next if $range eq '';
    if ($range =~ /^([^\[]+)\[(.*)\](.*)/o) {
      my ($prefix,$range,$suffix) = ($1,$2,$3);
      for my $subrange (split ',', $range) {
        if ($subrange =~ /^(\d+)$/o) {
          push @nodes, $prefix . $1 . $suffix;
        }
        elsif ($subrange =~ /^(\d+)-(\d+)$/o) {
          for (my $i=$1; $i<=$2; $i++) {
            push @nodes, $prefix . $i . $suffix;
          }
        }
        else {
	  print "Error: Invalid range specification: $range\n";
        }
      }
    }
    else {
      push @nodes, $range;
    }
  }
  return \@nodes;
}

sub match_range {
# Desc: Matches a hostname against a NODECLASS_RANGE expression.
#       a NODECLASS_RANGE is any text with one or more RANGEs in brackets.
#       a RANGE is of the form <a-b[,x-y]...>, where a<b and x<y.
#       ie: cn[1-10,20-32] or su[1,4]cn[1-32] or my[1-32]nodes.
# Input: 1) $ I    range expression
#        2) $ I    hostname
# Returns: 0: hostname does not match range
#          1: hostname does match range
#          undef: on error
  my ($range_in, $hostname) = @_;
  if ($#_ != 1) {
    return undef;
  }

  my @ranges;

  # Split multiple comma-seperated ranges into an array
  while ($range_in =~ s/^(([^[]+?(\[.*?\])?)+?),//go) {
    push @ranges, $1;
  }
  push @ranges, $range_in;

  # Check for valid range
  for my $rangedesc (@ranges) {
    if ($rangedesc !~ /^((\w|[-.])+?)\[((\d+(-\d+)?)(,(\d+(-\d+)?))*)\]/o) {
      next;
    }

    # Check if hostname matches the range expression
    my @prefix_parts;
    my @prefixes;
    my $idx = 0;
    my $match = 0;
    while ($rangedesc =~ s/^((\w|[-.])+?)\[((\d+(-\d+)?)(,(\d+(-\d+)?))*)\]//go) {
      my ($prefix, $rangespec) = ($1, $3);
      $prefixes[$idx] = $prefix;
      while ($rangespec =~ s/^,?(?:(\d+)(?:-(\d+))?)(.*)/$3/go) {
	my ($start, $end) = ($1, $2);
	$end = $start if !defined $end;
	push @{$prefix_parts[$idx]}, [$start, $end];
      }
      $idx++;
    }

  PREFIX: for (my $i=0; $i <= $#prefixes; $i++) {
      my $prefix = $prefixes[$i];
    RANGE: foreach my $range (@{$prefix_parts[$i]}) {
	my ($start, $end) = ($$range[0], $$range[1]);
	if ($hostname =~ /^$prefix(\d+)/) {
	  my $digit = $1;
	  if ($digit >= $start && $digit <= $end) {
	    $match = 1;
	    last RANGE;
	  }
	  else {
	    $match = 0;
	  }
	}
	else {
	  $match = 0;
	  last PREFIX;
	}
      }
      if ($match) {
	$hostname =~ s/^$prefix(\d+)//;
      }
      else {
	last PREFIX;
      }
    }

    if ($match) {
      # Check for matching suffixes
      if ($hostname eq $rangedesc) {
	return 1;
      }
    }
  }
  return 0;
}

sub match_nodespecs {
# Desc: Checks a hostname against a range/regexp/class/property nodespec
# Input: 1) $   I   oneSIS::config object
#        2) $   I   hostname
#        3) \@? I   Optional array of range specs
#        4) \@? I   Optional array of regexp specs
#        5) \@? I   Optional array of class specs
#        6) \@? I   Optional array of property specs
# Returns: 1: if hostname matches any of the given specs
#          0: otherwise
  my ($config, $hostname, $ranges, $regexps, $classes, $properties) = @_;
  my $match;

  # Check range nodespecs
  if ($#$ranges >= 0) {
    my $i;
    for ($i = 0; $i <= $#$ranges; $i++) {
      my $range = $$ranges[$i];
      if (defined ($match = oneSIS::match_range($range, $hostname))) {
	if ($match) {
	  return 1;
	}
      }
      else {
	warn "oneSIS: Error! Invalid Range Specification: $range\n";
	splice(@$ranges,$i,1);
      }
    }
  }

  # Check regexp nodespecs
  if ($#$regexps >= 0) {
    foreach my $regexp (@$regexps) {
      if ($hostname =~ /^$regexp$/) {
	return 1;
      }
    }
  }

  # Check class nodespecs
  if ($#$classes >= 0) {
    my $classname = oneSIS::get_node_class($config, $hostname);
    if (defined $classname) {
      foreach my $class_spec (@$classes) {
	foreach my $class ($classname, @{$config->parents_of($classname)}) {
	  if ($class eq $class_spec) {
	    return 1;
	  }
	}
      }
    }
  }

  # Check property nodespecs
  if ($#$properties >= 0) {
    my $i;
    for ($i = 0; $i <= $#$properties; $i++) {
      my $prop = $config->get_property($$properties[$i]);
      if (defined $prop) {
	my $classname = oneSIS::get_node_class($config, $hostname);
	if (defined $classname) {
	  if ($prop->applies_to($config, $hostname)) {
	    return 1;
	  }
	}
      }
      else {
	warn "oneSIS: Error! Property doesn't exist: $$properties[$i]\n";
	splice(@$properties,$i,1);
	next;
      }
    }
  }
  return 0;
}

sub fork_parallel {
# Desc: Forks several commands in parallel
#       Note: This function (re)defines the ALRM signal handler.
# Input: 1) \@  I   Array of commands to run
#        2) $?  I   Optional limit of commands to fork in parallel
#        3) $?  I   Optional sleep time after spawning every block of tasks
# Returns: \@ exit status of each command run
  my ($cmds, $parallelism, $sleep) = @_;
  my @exit_status;
  $parallelism = 0 unless defined $parallelism;
  $sleep = 0 unless defined $sleep;
  our $sleeping = 0;

  # Set up SIGALRM handler for sleeping
  $SIG{ALRM} = 'oneSIS::unsleep';
  sub oneSIS::unsleep {
    $sleeping = 0;
  }

  # Run commands in parallel -- fork() up to $parallelism commands
  my $running = 0;
  my $totalrun = 0;
  my %pidmap;
 CMD: for (my $idx=0; $idx <= $#$cmds; $idx++) {
    my $cmd = $$cmds[$idx];
    if ($dryrun) {
      print $cmd, "\n";
      next;
    }
    if ($sleep > 0 && ($totalrun > 0 && $totalrun % $parallelism == 0)) {
      # Sleep after spawning every $parallelism tasks
      $sleeping = 1;
      alarm($sleep);
    }

  WAIT: if ($running >= $parallelism && $parallelism != 0) {
      # Wait for some jobs to finish
      my $pid = wait();
      my $status = $? >> 8;
      unless ($pid == -1) {
	$exit_status[$pidmap{$pid}] = $status;
      }
      $running--;
    }

    goto WAIT if $sleeping;

    # Fork another command
    my $pid = fork();
    if (!defined $pid) {	# Error calling fork()
      warn "Error! Could not fork command: $cmd\n";
      return undef;
    }
    elsif ($pid == 0) {	# Child process
      $debug >=3 && print $cmd, "\n";
      exec($cmd);
      die "Error! Could not exec cmd: $cmd\n";
    }
    else {			# Parent process
      $pidmap{$pid} = $idx;
      $running++;
      $totalrun++;
    }
  }

  while ($running > 0) {
    # Wait for all jobs to finish
    my $pid = wait();
    my $status = $? >> 8;
    unless ($pid == -1) {
      $exit_status[$pidmap{$pid}] = $status;
    }
    $running--;
  }

  return \@exit_status;
}

sub mount_dev {
# Desc: Mounts the devfs filesystem on /dev or configures the system for udev
#       If the kernel was compiled with devfs support, devfs is mounted
#       so that device names are consistent between /dev and /proc/partitions
# Depends: /proc filesystem must already be mounted
# Input: 1) $  I?    Optional base directory (default: '/')
# Returns: undef: on error
  my ($basedir) = @_;

  my $have_devfs = 0;
  my $output;

  if (! defined $basedir) {
    $basedir = '/';
  }

  # Check if devfs is built into the kernel
  if (!open(FS, "</proc/filesystems")) {
    warn "oneSIS: Error! Could not open /proc/filesystems: $!\n";
  }
  else {
    while (defined ($_ = <FS>)) {
      if (/devfs/) {
	$have_devfs = 1;
      }
    }
    close FS;
  }

  # Mount devfs if it is built into the kernel
  if ($have_devfs) {
    if (! -e "$basedir/dev/.devfsd") {
      $output = `mount -n -t devfs devfs $basedir/dev 2>&1`;
      if ($? >> 8) {
	$debug && warn "oneSIS: Error! Could not mount devfs:\n*  *  * $output\n";
	return undef;
      }
    }
  }
  else {
#    warn "oneSIS: Warning! devfs support has not been compiled into the kernel.\n";
#    warn "*  *  * Either devfs or udev are required for oneSIS to operate correctly.\n";
  }
}

sub get_ramdisk_size {
# Desc: Returns the size of the ramdisk to create for this node.
# Input: 1) $  I    oneSIS::config object
#        2) $  I    hostname of this node
#        3) $  I    class name of this node
# Returns: $ ramdisk size
  my ($config, $hostname, $classname) = @_;
  my $ramdisk_size = 'default';  # default to what tmpfs uses

  foreach my $ramdisk (@{$config->get_all_ramdisks()}) {
    if ($config->using_directive($ramdisk->modifier(),
				 $hostname, $classname)) {
      $ramdisk_size = $ramdisk->size() . $ramdisk->unit();
    }
  }
  return $ramdisk_size
}

sub update_ramdisk_elems {
# Desc: Create files, directories, and linkbacks in the ramdisk
#       specified in the config
# Input: 1) $  I    oneSIS::config object
#        2) $  I    hostname of this node
#        3) $  I    class name of this node
#        4) $  I    clean files in ramdisk before updating
# Returns: \% hash of paths created (key=path, value=1)
  my ($config, $hostname, $classname, $clean) = @_;
  my (%create_elem, %used_elem, %linkbacks, %created_elems, %create_default);
  my $order = 0;

  # Create/update new files/directories in the ramdisk
 RAMDISK_ELEM:
  foreach my $ramdisk_elem (@{$config->get_all_ramdisk_elems()}) {
    my (%dont_update);
    my $using = 0;
    my $path = $ramdisk_elem->file_elem()->path();
    my $type = $ramdisk_elem->type();

    # Determine if this ramdisk element should be created
    if ($config->using_directive($ramdisk_elem->modifier(),
				 $hostname, $classname)) {
      $using = 1;
    }

    # Don't necessarily create the .default link for new ramdisk elements
    # having the same path as a previous element
    $create_default{$path} = 0;

    # This block runs through every ramdisk element and determines which ones
    # should be created.  An element will be created if it represent a change
    # from the current layout of the ramdisk and if it passes all criteria
    # necessary to run on the given node.  Each parent class of the node's
    # class is checked until the element is marked for creation.
    # After all of the node's parent classes, the 'default' class is checked
    my $parents = $config->parents_of($classname);
  RAMDISK_PARENT_CLASS:
    foreach my $myclass (reverse('default', @$parents, $classname)) {
      my $linktarget;
      my $created = 0;

      # Allow the .default targets to get created even if this
      # node doesn't use the directive, except for SERVICE linkbacks
      unless ($using) {
	if ($type =~ /LINK/ && $myclass eq 'default' && !exists $used_elem{$path} &&
	    !($type eq 'LINKBACK' && $ramdisk_elem->linkback() eq 'SERVICE')) {
	  $create_default{$path} = 1;
	}
	else {
	  next RAMDISK_PARENT_CLASS;
	}
      }

    USING_RAMDISK_ELEM:
      my $create = 0;
      $path =~ m|^(.*)/|;
      my $path_dir = $1;

      # Keep track if which ramdisk_elems are being used
      $used_elem{$path} = $ramdisk_elem;

      my $glob_list = oneSIS::file_globs($path, '/');
    GLOB_FILE: foreach my $gpath (@$glob_list) {
	# Munge the gpath for non-existing paths
	if ($gpath !~ m|$path_dir/\S+|) {
	  $gpath = $path;
	}
	next GLOB_FILE if $dont_update{$gpath};

	# Determine if the ramdisk element should be created
	#   -- ie: it is different from what exists, or it doesn't exist
	if (exists $create_elem{$gpath}) {
	  # This /ram path exists from a previous ramdisk element
	  #  -- use new elem if it differs from the old one
	  my $created_elem = $create_elem{$gpath}{ELEM};
	  my $created_class = $create_elem{$gpath}{CLASS};
	  my $created_target = $create_elem{$gpath}{LINKTARGET};

	  if ($type ne $created_elem->type()) {
	    if ($type eq 'LINKBACK') {
	      $linktarget = get_linktarget($config, $ramdisk_elem, $hostname,
					   $myclass);
	    }
	    $create = 1;
	  }
	  elsif ($type eq 'LINKBACK') {
	    $linktarget = get_linktarget($config, $ramdisk_elem, $hostname,
					 $myclass);

	    # Do a readdir to force a refresh of the NFS cache
	    if ($linktarget =~ m|^(.*)/|) {
	      my $dir = $1;
	      if (-d $dir) {
		opendir(DIR, $dir);
		readdir(DIR);
		closedir DIR;
	      }
	    }

	    # Check if current target is still valid or linkback is forced
	    # Always create the default linkback unless it exists already
	    if (($linktarget eq $created_target)
		&& ((-e $linktarget || -l $linktarget)
		    || $ramdisk_elem->forced())) {
	      $dont_update{$gpath} = 1;
	    } elsif (($linktarget ne $created_target)
		     && ((-e $linktarget || -l $linktarget)
			 || $ramdisk_elem->forced()
			 || $myclass eq 'default')) {
	      $create = 1;
	    }
	  }
	}
	elsif (-e "/ram/$gpath" || -l "/ram/$gpath") {
	  # This /ram path doesn't exist from a previous ramdisk element
	  # Check if type has changed (file<>dir, file<>link, link<>dir)
	  if (-l "/ram/$gpath") { # LINKBACK element or .default link
	    if ($type eq 'LINKBACK') {
	      $linktarget = get_linktarget($config, $ramdisk_elem, $hostname,
					   $myclass);
	      my $cur_target = readlink("/ram/$gpath");

	      # Do a readdir to force a refresh of the NFS cache
	      if ($linktarget =~ m|^(.*)/|) {
		my $dir = $1;
		if (-d $dir) {
		  opendir(DIR, $dir);
		  readdir(DIR);
		  closedir DIR;
		}
	      }

	      # Check if current target is still valid or linkback is forced
	      # Always create the default linkback unless it exists already
	      if (($linktarget eq $cur_target)
		  && ((-e $linktarget || -l $linktarget)
		      || $ramdisk_elem->forced())) {
		$dont_update{$gpath} = 1;
	      } elsif (($linktarget ne $cur_target)
		       && ((-e $linktarget || -l $linktarget)
			   || $ramdisk_elem->forced()
			   || $myclass eq 'default')) {
		$create = 1;
	      }
	    }  ## $type eq 'LINKBACK'
	    elsif ($ramdisk_elem->duplicate()) {
	      # Link with duplicate() flag set
	      if (-l $gpath) {
		my $cur_target = readlink("/ram/$gpath");
		my $rel_linktarget = readlink($gpath);
		$rel_linktarget =~ s|.*/||;
		if ($rel_linktarget eq $cur_target) {
		  # Check if ram copy differs from original
		  my $abs_linktarget = final_target($gpath);
		  if (!defined $abs_linktarget) {
		    warn "*  *  * File not being copied: $gpath\n";
		    next GLOB_FILE;
		  }
		  my $mylinktarget = final_target("/ram/$gpath", 0);
		  if (!defined $mylinktarget) {
		    $create = 1;
		  }
		  else {
		    if (differs($abs_linktarget, $mylinktarget)) {
		      $create = 1;
		    }
		  }
		}
		else {
		  # Link target has changed
		  $create = 1;
		}
	      }
	      else {
		# Original path is not a link anymore
		$create = 1;
	      }
	    }  ## $ramdisk_elem->duplicate()
	    elsif ($create_default{$path}) {
	      my $mylinktarget = final_target("/ram/$gpath", 0);
	      if (defined $mylinktarget) {
		my $mypath = $gpath;
		if ($ramdisk_elem->hidden()) {
		  $mypath =~ s|^(.*/)(.*)$|$1.$2|;
		}
		if ($mylinktarget ne "$mypath.default") {
		  $create = 1;
		}
	      }
	      else {
		$create = 1;
	      }
	    }
	    else {
	      # /ram/$gpath is a link (maybe to .default), but it shouldn't be
	      $create = 1;
	    }
	  }  ## -l /ram/$gpath
	  elsif (-d "/ram/$gpath") { # *DIR element
	    # Update if type is no longer *DIR or if duplicate() flag changed
	    if ($create_default{$path}) {
	      $create = 1;
	    }
	    elsif ($type =~ /DIR/ && $ramdisk_elem->duplicate()) {
	      my $real_gpath = $gpath;
	      if (-l $gpath) {
		$real_gpath = final_target($gpath);
	      }
	      if ($type eq 'LINKDIR') {
		my $tp = transform_path('/', $real_gpath);
		if (oneSIS::differs($tp, "/ram/$gpath")) {
		  $create = 1;
		}
	      }
	      elsif (oneSIS::differs($real_gpath, "/ram/$gpath")) {
		$create = 1;
	      }
	    }
	    else {
	      $create = 1 unless $type =~ /DIR/;
	    }
	  }
	  elsif (-f "/ram/$gpath") { # *FILE element
	    # Update if type is no longer *FILE or if duplicate() flag changed
	    if ($create_default{$path}) {
	      $create = 1;
	    }
	    elsif ($type =~ /FILE/ && $ramdisk_elem->duplicate()) {
	      if ($type eq 'LINKFILE') {
		my $tp = transform_path('/', $gpath);
		if (oneSIS::differs($tp, "/ram/$gpath")) {
		  $create = 1;
		}
	      }
	      elsif (oneSIS::differs($gpath, "/ram/$gpath")) {
		$create = 1;
	      }
	    }
	    else {
	      $create = 1 unless $type =~ /FILE/;
	    }
	  }
	}  ## -e /ram/$gpath || -l /ram/$gpath
	else {
	  # /ram path doesn't exist...mark it for creation unless linkback
	  # target doesn't exist
	  if ($type eq 'LINKBACK') {
	    if ($myclass eq 'default') {
	      # Always create the default linkback
	      $create = 1;
	    }
	    else {
	      # Check if linkback target exists
	      $linktarget = get_linktarget($config, $ramdisk_elem, $hostname,
					      $myclass);

	      # Do a readdir to force a refresh of the NFS cache
	      if ($linktarget =~ m|^(.*)/|) {
		my $dir = $1;
		if (-d $dir) {
		  opendir(DIR, $dir);
		  readdir(DIR);
		  closedir DIR;
		}
	      }

	      # Check if linkback target is valid or if linkback is forced
	      if (-e $linktarget || -l $linktarget ||
		  $ramdisk_elem->forced()) {
		$create = 1;
	      }
	    }
	  }  ## $type eq 'LINKBACK'
	  else {
	    $create = 1;
	  }
	}

	if ($create) {
	  $linktarget = '' if ! defined $linktarget;
	  $create_elem{$gpath}{ELEM} = $ramdisk_elem;
	  $create_elem{$gpath}{CLASS} = $myclass;
	  $create_elem{$gpath}{LINKTARGET} = $linktarget;
	  $create_elem{$gpath}{ORDER} = $order;
	  $order++;
	  $created = 1;
	}
      } ## foreach my $gpath (@$glob_list)
      last RAMDISK_PARENT_CLASS if $created;
    } ## foreach $myclass (reverse('default', @$parents, $classname))
  } ## foreach my $ramdisk_elem (@{$config->get_all_ramdisk_elems()})

  # Create/update all elements marked for creation.
 CREATE_ELEM: foreach my $path (sort {$create_elem{$a}{ORDER} <=> $create_elem{$b}{ORDER}} keys %create_elem) {
    my $ramdisk_elem = $create_elem{$path}{ELEM};
    my $myclass = $create_elem{$path}{CLASS};
    my $linktarget = $create_elem{$path}{LINKTARGET};
    my $type = $ramdisk_elem->type();
    my $file_elem = $ramdisk_elem->file_elem();
    my $made_elem = 0;

    # Verify that link target is actually represents a change
    # -- case for multiple LINKBACKs for the same path
    unless ($create_default{$path}) {
      if (-l "/ram/$path") {
	if ($type eq 'LINKBACK') {
	  my $cur_target = readlink("/ram/$path");
	  if ($cur_target eq $linktarget) {
	    next CREATE_ELEM;
	  }
	}
      } elsif ($type =~ /DIR/ && -d "/ram/$path") {
	if ($ramdisk_elem->duplicate()) {
	  if ($ramdisk_elem->protected()) {
	    next CREATE_ELEM;
	  } else {
	    my $tp = transform_path('/', $path);
	    unless (oneSIS::differs($tp, "/ram/$path")) {
	      next CREATE_ELEM;
	    }
	  }
	} else {
	  next CREATE_ELEM;
	}
      } elsif ($type =~ /FILE/ && -f "/ram/$path") {
	if ($ramdisk_elem->duplicate()) {
	  if ($ramdisk_elem->protected()) {
	    next CREATE_ELEM;
	  } else {
	    my $tp = transform_path('/', $path);
	    unless (oneSIS::differs($tp, "/ram/$path")) {
	      next CREATE_ELEM;
	    }
	  }
	} else {
	  next CREATE_ELEM;
	}
      }
    }

    $created_elems{$path} = 1;

    # Create the ramdisk element
    if ($type =~ /DIR/ && !$create_default{$path}) {
      if ($ramdisk_elem->duplicate()) {
	$quiet || print "oneSIS: Updating to $type: /ram$path (ram copy)\n";
      }
      else {
	$quiet || print "oneSIS: Updating to $type: /ram$path\n";
      }
      $made_elem = 1;

      unless ($dryrun) {
	# Delete any existing files/links of the same name
	if ((-e "/ram/$path" || -l "/ram/$path") && (!-d "/ram/$path" || -l "/ram/$path")) {
	  `rm -rf /ram/$path`;    # unpure!
	}
      }

      # Create directory in /ram if needed
      if ($ramdisk_elem->duplicate()) {
	my $tp = transform_path('/', $path);
	if (!defined (oneSIS::copy_dir($tp, "/ram/$path", $dryrun, $quiet))) {
	  warn "*  *  * Error! Could not copy $tp to /ram\n";
	}
      }
      else {
	unless ($dryrun) {
	  if (! defined (oneSIS::mk_path($path, '/ram'))) {
	    warn "*  *  * Could not create $type: $path\n";
	    next CREATE_ELEM;
	  }
	  else {
	    oneSIS::mirror_props($path, '/', '/ram');
	  }
	}
      }
      unless ($dryrun) {
	# Set perms/ownership explicitly if any -m, -u, or -g flags are set
	# in the directive
	if (defined $file_elem->mode() || defined $file_elem->user()
	    || defined $file_elem->group()) {
	  oneSIS::set_props($file_elem, '/ram');
	}
      }
    } ## $type =~ /DIR/
    elsif ($type =~ /FILE/ && !$create_default{$path}) {
      if ($ramdisk_elem->duplicate()) {
	$quiet || print "oneSIS: Updating to $type: /ram$path (ram copy)\n";
      }
      else {
	$quiet || print "oneSIS: Updating to $type: /ram$path\n";
      }
      $made_elem = 1;
      next CREATE_ELEM if $dryrun;

      # Delete any existing directories/links of the same name
	if ((-e "/ram/$path" || -l "/ram/$path") && (!-f "/ram/$path" || -l "/ram/$path")) {
	`rm -rf /ram/$path`;    # unpure!
      }

      # Create file in /ram if needed
      if ($path =~ /^(.*)\/(.+)$/) {
	my ($dir, $filename) = ($1, $2);
	if (! defined (oneSIS::mk_path($dir, '/ram'))) {
	  warn "*  *  * Could not create $type: $path\n";
	  next CREATE_ELEM;
	}
	elsif ($ramdisk_elem->duplicate()) {
	  # Copy file into /ram
	  my $tp = transform_path('/', $path);
	  if (!defined (oneSIS::copy_file($tp, "/ram/$path", 1))) {
	    warn "oneSIS: Error! Could not copy $tp to /ram: $!\n";
	  }
	}
	else {
	  # Create an empty file
	  open(FILE, ">/ram/$path") or warn "oneSIS: Could not create file /ram/$path: $!\n";
	  close(FILE);
	}
	# Set perms/ownership explicitly if any -m, -u, or -g flags are set
	# in the directive
	if (defined $file_elem->mode() || defined $file_elem->user()
	    || defined $file_elem->group()) {
	  oneSIS::set_props($file_elem, '/ram');
	}
	else {
	  # Only mirror properties if no -m, -u, or -g flags are set
	  oneSIS::mirror_props($path, '/', '/ram');
	}
      }
      else {
	warn "oneSIS: Warning! Encountered invalid pathname: $path\n";
      }
    } ## $type =~ /FILE/
    elsif ($type eq 'LINKBACK' && !$create_default{$path}) {
      $linkbacks{$path} = 1;

      # Create links back to CLASS/NODE specific files or to given target
      unless ($dryrun) {
	# Delete any existing link/file/directory
	if (-e "/ram/$path" || -l "/ram/$path") {
	  `rm -rf /ram/$path`;    # unpure!
	}
      }

      my $linktarget = get_linktarget($config, $ramdisk_elem, $hostname,
				      $myclass);

      # Create new link if the target exists (or if forced)
      if (-e $linktarget || -l $linktarget || $ramdisk_elem->forced()) {
	$quiet || print "oneSIS: Updating to $type: /ram$path -> $linktarget\n";
	$made_elem = 1;
	next CREATE_ELEM if $dryrun;

	# Create linkback
	if ($path =~ m|^(.*)/|) {
	  my $dir = $1;
	  oneSIS::mk_path($dir, '/ram');
	  if (!symlink($linktarget, "/ram/$path")) {
	    warn "oneSIS: Error(1) creating symlink for $path: $!\n";
	  }
	}
      }
    } ## $type eq 'LINKBACK'

    # Create link back the the default file if specified or if no other link
    # was created for a linkback
    if (! $made_elem || $create_default{$path}) {
      # Create LINKBACK to the .default target
      $path =~ m|^(.*)/|;
      my $dir = $1;
      my $mypath = $path;
      if ($ramdisk_elem->hidden()) {
	$mypath =~ s|^(.*/)(.+)$|$1.$2|;
      }

      my $default_exists = 0;
      if (-l "/ram/$path") {
	my $target = readlink ("/ram/$path");
	if ($target eq "$mypath.default") {
	  $default_exists = 1;
	}
      }

      unless ($default_exists) {
	unless ($dryrun) {
	  # Delete any existing link/file/directory
	  if (-e "/ram/$path" || -l "/ram/$path") {
	    `rm -rf /ram/$path`;    # unpure!
	  }
	  oneSIS::mk_path($dir, '/ram');
	  if (!symlink("$mypath.default", "/ram/$path")) {
	    warn "oneSIS: Error(2) creating symlink for $path: $!\n";
	  }
	}
	if ($type eq 'LINKBACK' && $ramdisk_elem->linkback() eq 'SERVICE') {
	  $quiet || print "oneSIS: Updating SERVICE $type: /ram$path -> $mypath.default\n";
	} else {
	  $quiet || print "oneSIS: Linking to default: /ram$path -> $mypath.default\n";
	}
      }
    }
  } ## foreach my $path (keys %create_elem)

  # Clean up existing files/dirs in the ramdisk
  if ($clean) {
    my %protected;
    my @clean_list;
    our @clean_file_list = ();
    find({ wanted => sub { push @clean_file_list, $_; }, no_chdir => 1 }, '/ram');

    # Make lists of which files to remove and which to protect from removal
  RAMPATH: foreach my $rampath (sort by_nested_dirs_rev @clean_file_list) {
      my $path = $rampath;
      $path =~ s|/ram||;
      next if $path eq '';

      # Protect file and parent directories of valid ramdisk_elems
      # or links back to .default pathnames
      if ($config->ramdisk_elem_exists($path, '/', 0, $hostname, $classname)
	     || $create_default{$path}) {
	# Don't protect globs of linkback targets (corner case)
	$path =~ /^(.*)\/(.+)$/;
	my ($dir, $variant) = ($1, $2);
	while ($variant =~ s|(.*)\..*|$1|g) {
	  if ($linkbacks{"$dir/$variant"}) {
	    push @clean_list, $rampath;
	    next RAMPATH;
	  }
	}

	# Protect all the parent directories
	$protected{$rampath} = 1;
	my $parent = $rampath;
	while ($parent =~ s|(.*)/.*|$1|g) {
	  last if $protected{$parent};
	  $protected{$parent} = 1;
	}
      }
      else {
	# Protect any nested file/dir in a duplicated/protected dir
	my $parent = $path;
      PARENT: while ($parent =~ s|(.*)/.*|$1|g) {
	  if (exists $used_elem{$parent}
	      && $used_elem{$parent}->type() =~ /DIR/
	      && ($used_elem{$parent}->duplicate()
		  || $used_elem{$parent}->protected())) {
	    last PARENT if $protected{$parent};
	    $protected{$rampath} = 1;
	    last PARENT;
	  }
	}
	push @clean_list, $rampath;
      }
    }

    # Remove files/directories no longer in the configuration
    foreach my $rampath (@clean_list) {
      unless ($protected{$rampath}) {
	$quiet || print "oneSIS: Removing: $rampath\n";
	unless ($dryrun) {
	  `rm -rf $rampath`;    # unpure!
	}
      }
    }
  }

  return \%created_elems;

  sub get_linktarget {
    # Desc: Finds the right LINKBACK target for a given node/class/property
    # Input: 1) $  I    oneSIS::config object
    #        2) $  I    oneSIS::ramdisk_elem object
    #        3) $  I    hostname of this node
    #        4) $  I    class name of this node
    # Returns: $ linkback target
    my ($config, $ramdisk_elem, $hostname, $classname) = @_;
    my $basetarget = $ramdisk_elem->file_elem()->path();
    my $linkback = $ramdisk_elem->linkback();
    my $linktarget = '';

    if ($ramdisk_elem->hidden()) {
      $basetarget =~ s|^(.*/)(.*)$|$1.$2|;
    }

    # Determine link target
    if ($classname eq 'default') {
      $linktarget = "$basetarget.default";
    } else {
      if ($linkback eq 'SERVICE') {
	$linktarget = "$basetarget.default";
      } elsif ($linkback eq 'CLASS') {
	$linktarget = "$basetarget.$classname";
      } elsif ($linkback eq 'NODE') {
	$linktarget = "$basetarget.$hostname";
      } elsif ($linkback eq 'PROPERTY') {
	# Contrary to CLASS, a given node may have multiple properties defined,
	# but we can only link back to one.  If multiple valid PROPERTY
	# linkback targets exist, preference is given in alphabetical order.
	my $props = $config->get_all_properties();
	foreach my $propname (sort {$a cmp $b} @$props) {
	  my $prop = $config->get_property($propname);
	  if ($prop->applies_to($config, $hostname)) {
	    my $lt = "$basetarget.$propname";
	    if (-e $lt || -l $lt) {
	      $linktarget = $lt;
	      last;
	    }
	  }
	}
      } else {
	# Linkback target supplied
	$linktarget = $linkback;
	$linktarget =~ s/\$NODE/$hostname/g;
	$linktarget =~ s/\$CLASS/$classname/g;
      }
    }
    return $linktarget;
  }

  sub by_nested_dirs_rev {
    # Desc: Sort routine to sort nested directories
    #       ie: '/tmp' should come before '/', and '/usr/local' before '/usr'
    # Input: 1) $a -- implicit -- the sort target is a list of paths
    #        2) $b -- implicit -- the sort target is a list of paths
    if ($a eq $b) {
      return 0;
    }
    if ($a =~ /^$b.*$/) {
      return -1;
    }
    if ($b =~ /^$a.*$/) {
      return 1;
    }
  }
}

sub setup_localdisks {
# Desc: Configures local disks specified in the config as swap space
#       or mounted ext{2,3,4} filesystems
# Input: 1) $  I    oneSIS::config object
#        2) \@ I    array of localdisk_elem objects
#        3) $  I    hostname of this node
#        4) $  I    class name of this node
#        5) $  I?   Optional action:  (default=0)
#                   0: Mount filesystems
#                   1: Partition, format and label, but don't mount filesystems
#                   2: Dryrun -- don't partition, format, or mount filesystems
#                   3: Skip partitioning, then format and label, but don't mount filesystems
#        6) $  I?   Optional base directory for filesystem mounts.
#                   (defaults to '/')
# Returns: \% hash of filesystems
#             (key=device name; value=oneSIS::file_elem object)
#          undef: on error
  my %args = (
	      -mountparts => 1,
	      -partition => 1,
	      @_
	     );
  my ($config, $localdisk_elems, $hostname, $classname, $dryrun, $basedir, $mountparts, $partition) = 
    ($args{-config}, $args{-localdisk_elems}, $args{-hostname}, $args{-classname}, $args{-dryrun}, $args{-basedir},
     $args{-mountparts}, $args{-partition});
  my (%partitions,@swap,%diskleft,%device,%partitioned);
  my (%sfdisk_input,%parted_input,%diskinfo,%order,%raids);
  my ($mydisks,$label,$device,$partsize) = (undef,undef,undef,undef);
  my ($output) = (undef);
  my ($disksize,$disks_already_checked,$order,$have_large_partitions) = (0,0,0,0);
  our (%mounts);

  if (! defined $basedir) {
    $basedir = '/';
  }

  # Determine configuration of local disk partitions for swap and mounting
 LOCALDISK_ELEM:
  foreach my $localdisk_elem (@$localdisk_elems) {
    $order++;

    if ($config->using_directive($localdisk_elem->modifier(),
				 $hostname, $classname)) {
      # Keep track of which localdisk_elem to use for each path/SWAP space
      # This allows only 1 swap partition to be defined per node
      my $path;
      if ($localdisk_elem->type() eq 'SWAP') {
	$path = 'SWAP';
      }
      else {
	$path = $localdisk_elem->file_elem()->path();
      }
      $diskinfo{$path} = $localdisk_elem;
      $order{$path} = $order;
    }
  }

 PATH: foreach my $path (sort {$order{$a} <=> $order{$b}} keys %diskinfo) {
    my $localdisk_elem = $diskinfo{$path};

    # Build list of partitions to create
    my $diskObjs = $localdisk_elem->disk();
    my $type = $localdisk_elem->type();
    my $size = $localdisk_elem->size();
    my $raidlevel = $localdisk_elem->raidlevel();

    # Check for invalid RAID configurations
    if ($#$diskObjs > 0 && !defined $raidlevel) {
      warn "oneSIS: Warning! Multiple disks specified in non-RAID configuration\n";
      next PATH;
    }

    # Probe for available hard drives
    if (! $disks_already_checked) {
      $mydisks = check_disks();
      $disks_already_checked = 1;
    }

    for my $diskObj (@$diskObjs) {
      my $disk = $diskObj->identifier();

      if ($disk =~ /^\d+$/) {
	if (! exists $$mydisks{$disk}) {
	  warn "oneSIS: Warning! Local disk '$disk' does not exist.\n";
	  next PATH;
	}
      }
      else {
	my $gotdisk = 0;
	foreach my $ident (keys %$mydisks) {
	  my $dev = $$mydisks{$ident};
	  if ($dev eq $disk) {
	    $gotdisk = 1;
	  }
	}
	if (!$gotdisk) {
	  warn "oneSIS: Warning! Local disk '$disk' does not exist.\n";
	  next PATH;
	}
      }

      # Populate config disk objects with device names
      if ($disk =~ /^\d+$/) {
	$device = $$mydisks{$disk};
      }
      else {
	foreach my $ident (keys %$mydisks) {
	  my $dev = $$mydisks{$ident};
	  if ($dev eq $disk) {
	    $device = $disk;
	  }
	}
      }
      $diskObj->device($device);

      if (exists $diskleft{$device}) {
	# Skip localdisk element if disk is already out of space
	if ($diskleft{$device} <= 0) {
	  warn "oneSIS: Warning! Local disk '$disk' is out of space.\n";
	  next PATH;
	}
      }
      else {
	my $dev_part = $device;
	my $disk_used = 0;

	# Check if disk already has mounted filesystems, if so skip the disk
	$dev_part =~ s/disc$/part/;
	if (!open (MOUNTS, "</proc/mounts")) {
	  warn "oneSIS: Error! Unable to read /proc/mounts: $!\n";
	  return undef;
	}
	else {
	  while (defined ($_ = <MOUNTS>)) {
	    /^(\S+)/;
	    my ($mnt_device, $mnt_dev) = ($1, $1);
	    if (-l $mnt_device) {
	      $mnt_device = readlink($mnt_device);
	    }
	    if ($mnt_device =~ /$dev_part/) {
	      warn "oneSIS: Warning! Disk $disk has mounted partitions: $mnt_dev\n";
	      warn "*  *  * Skipping filesystem initialization: ",
		($localdisk_elem->type() eq 'SWAP') ? 'SWAP' : $path, "\n";
	      $disk_used = 1;
	      last;
	    }
	  }
	  close MOUNTS;
	  if ($disk_used) {
	    next PATH;
	  }
	}

	# Check if disk has enabled swap partitions, if so skip the disk
	if (!open (SWAPS, "</proc/swaps")) {
	  warn "oneSIS: Error! Unable to read /proc/swaps: $!\n";
	  return undef;
	}
	else {
	  while (defined ($_ = <SWAPS>)) {
	    /^(\S+)/;
	    my ($swap_device, $swap_dev) = ($1, $1);
	    if (-l $swap_device) {
	      $swap_device = readlink($swap_device);
	    }
	    if ($swap_device =~ /$dev_part/) {
	      warn "oneSIS: Warning! Disk $disk has active swap partitions: $swap_dev\n";
	      warn "*  *  * Skipping filesystem initialization: ",
		($localdisk_elem->type() eq 'SWAP') ? 'SWAP' : $path, "\n";
	      $disk_used = 1;
	      last;
	    }
	  }
	  close SWAPS;
	  if ($disk_used) {
	    next PATH;
	  }
	}

	# Initialize disk size
	$disksize = get_disk_size($device);
	$diskObj->size($disksize);
	if (defined $disksize) {
	  $debug && print "oneSIS: DEBUG: Disk $disk: /dev/$device\tsize: $disksize\n";
	  $diskleft{$device} = $disksize;
	}
	else {
	  warn "*  *  * Skipping device initialization: $device\n";
	  next PATH;
	}
      }

      # Determine size of local disk partition
      if ($size =~ /^(\d+)%$/) {
	$partsize = int($disksize*$1/100 +.5);
      }
      else {
	$partsize = int($size*1000000/1024 +.5);
      }
      if ($partsize > $diskleft{$device}) {
	$partsize = $diskleft{$device};
      }

      # sfdisk only does DOS/MBR partition tables, which have a (2 TiB - 512) partition size limit.
      # GNU parted can do GPT, which supports partitions up to 8 ZiB (should last us a while).
      if ($partsize >= 2*1024*1024*1024) { # 2 TiB in 1024-byte blocks
	$have_large_partitions = 1;
      }

      # Keep track of free disk space
      $diskleft{$device} -= $partsize;

      # Set actual size of localdisk_elem
      $localdisk_elem->actualsize($partsize);

      # Add localdisk_elem to partition list
      push @{$partitions{$device}}, $localdisk_elem;

      if ($debug) {
	if ($localdisk_elem->type() eq 'SWAP') {
	  print "oneSIS: DEBUG: Adding partition on $device:  SWAP\tsize: $partsize\tDisk left: $diskleft{$device}\n";
	}
	else {
	  print "oneSIS: DEBUG: Adding partition on $device:  ", $localdisk_elem->file_elem()->path(), "\tsize: $partsize\tDisk left: $diskleft{$device}\n";
	}
      }
    }
  }

  # Build input for partitioning either with sfdisk or parted.
 DEVICE: foreach my $device (keys %partitions) {
    my $offset = 2048;  # Allow initial space for embedding large bootloaders
    # Have parted make a GPT partition table
    push @{$parted_input{$device}}, "mklabel gpt";

    # Handle either devfs or udev(regular) style device names
    my $dev_part = $device;
    $dev_part =~ s/disc$/part/;

    # Build input for sfdisk
    my $num_parts = $#{$partitions{$device}};
    my ($partnum, $ext_added) = (0, 0);
    for (my $part=0; $part <= $num_parts; $part++) {

      my $localdisk_elem = $partitions{$device}[$part];
      my $diskObjs = $localdisk_elem->disk();
      my $diskObj;
      for my $obj (@$diskObjs) {
	if ($obj->device() eq $device) {
	  $diskObj = $obj;
	  last;
	}
      }
      $partnum++;

      # Add extended partition if necessary
      if ($part == 3 && $num_parts >= 4) {
	my $ext_size = $diskObj->size();
	for (my $idx=0; $idx <= 2; $idx++) {
	  $ext_size -= $partitions{$device}[$idx]->actualsize();
	}
	push @{$sfdisk_input{$device}}, "$offset,$ext_size,X,";
	$partnum++;
      }

      # Add swap and mount partitions
      $partsize = $localdisk_elem->actualsize();
      my $partname = "/dev/$dev_part$partnum";
      # check for cciss devices
      $partname = "/dev/$dev_part" . "p$partnum" if $dev_part =~ /cciss/;
      $device{$partname} = $device;
      push @{$parted_input{$device}}, sprintf "mkpart primary %dMiB %dMiB", int($offset/1024), int(($offset+$partsize)/1024)-1;
      if ($localdisk_elem->type() eq 'SWAP') {
	if (defined $localdisk_elem->raidlevel()) {
	  $localdisk_elem->partitions($partname);
	  if (!exists $raids{$partnum - 1}) {
	    $raids{$partnum - 1} = $localdisk_elem;
	  }
	}
	else {
	  push @swap, $partname;
	}
	push @{$sfdisk_input{$device}}, "$offset,$partsize,S";
	$offset += $partsize;
      }
      elsif ($localdisk_elem->type() eq 'MOUNT') {
	if (defined $localdisk_elem->raidlevel()) {
	  $localdisk_elem->partitions($partname);
	  if (!exists $raids{$partnum - 1}) {
	    $raids{$partnum - 1} = $localdisk_elem;
	  }
	}
	else {
	  $mounts{$partname} = $localdisk_elem;
	}
	push @{$sfdisk_input{$device}}, "$offset,$partsize,L,*";
	push @{$parted_input{$device}}, sprintf "set %d boot on", $part+1;
	$offset += $partsize;
      }
    }
  }

  # Create disk partitions
  if ($partition) {
  DEV: foreach my $device (keys %sfdisk_input) {
      if ($#{$sfdisk_input{$device}} != -1) {
	my ($before, $after);
	if ($have_large_partitions) {
	  # Use parted to make GPT partitions
	  # TODO: skip if already partitioned?
	  print "oneSIS: Partitioning /dev/$device ...\n";
	  next DEV if $dryrun;
	  for my $parted_command (@{$parted_input{$device}}) {
	    $output = `/sbin/parted -s /dev/$device -- $parted_command 2>&1`;
	    if ($? >> 8) {
	      warn "oneSIS: Error creating partitions on /dev/$device: $output\n";
	    } else {
	      $partitioned{$device} = 1;
	    }
	  }
	} else {
	  # Use sfdisk to make DOS/MBR partitions
	  my $sfdisk_input = join("\\n", @{$sfdisk_input{$device}});
	  $before = $after = `/bin/echo -e "$sfdisk_input" | /sbin/sfdisk -n -Lq -uB /dev/$device 2>&1`;
	  $before =~ s/(?:.*\n)+Old situation:(?:.*\n)+?((?:\/dev.*\n)+|(?:)|No partitions found)(?:.*\n)+/$1/;
	  $after =~ s/(?:.*\n)+New situation:(?:.*\n)+?((?:\/dev.*\n)+)(?:.*\n)+/$1/;
	  if ($before eq $after) {
	    print "oneSIS: Partition layout of /dev/$device unchanged.  Skipping partitioning ...\n";
	  } else {
	    print "oneSIS: Partitioning /dev/$device ...\n";
	    next DEV if $dryrun;
	    # TODO: Stop any RAIDs running on any partition of the device
	    # !! use $device{$partname} = $device and mdadm to scan for partitions of device ???
	    my $cmd = "/bin/echo -e '$sfdisk_input' | /sbin/sfdisk --force -Lq -uB /dev/$device";
	    $debug && print "oneSIS: DEBUG: $cmd\n";
	    $output = `$cmd 2>&1`;
	    if ($? >> 8) {
	      warn "oneSIS: Error creating partitions on /dev/$device: $output\n";
	    } else {
	      $partitioned{$device} = 1;
	    }
	  }
	}
      }
    }
  }

  # need to wait for the created partition to show up ...
  # particularly with /dev/cciss/cXdY like devices
  sleep 3 if scalar(keys %partitioned) > 0;

  # Set up any RAID arrays
 RAID: for my $raidnum (sort {$a cmp $b} keys %raids) {
    my $localdisk_elem = $raids{$raidnum};
    my $raid_devices = '';
    my $num_devices = 0;
    map { $raid_devices .= " $_"; $num_devices++; } @{$localdisk_elem->partitions()};
    my $raid_device = "/dev/md$raidnum";
    my $raidlevel = $localdisk_elem->raidlevel();
    if ($localdisk_elem->type() eq 'SWAP') {
      push @swap, $raid_device;
    }
    elsif ($localdisk_elem->type() eq 'MOUNT') {
      $mounts{$raid_device} = $localdisk_elem;
    }
    print "oneSIS: Creating RAID$raidlevel array $raid_device with devices: $raid_devices\n";
    next if $dryrun;
    if ($raidlevel == 0) {
      system("modprobe raid0");
    }
    elsif ($raidlevel == 1) {
      system("modprobe raid1");
    }
    elsif ($raidlevel =~ /^(4|5|6)$/) {
      system("modprobe raid456");
    }
    system("mdadm --stop $raid_device >/dev/null 2>&1");
    my $cmd = "yes | /sbin/mdadm --create $raid_device --level=$raidlevel --raid-devices=$num_devices $raid_devices";
    $debug && print "oneSIS: DEBUG: $cmd\n";
    my $output = `$cmd 2>&1`;
    if ($? >> 8) {
      warn "oneSIS: Error creating RAID array $raid_device: $output\n";
      next RAID;
    }
  }

  # Initialize swap partitions
  foreach my $part (@swap) {
    # Only do a mkswap if the swapon fails
    $output = `/sbin/swapon $part 2>&1`;
    if ($? >> 8) {
      print "oneSIS: Making swap space on $part ...\n";
      unless ($dryrun) {
	$output = `/sbin/mkswap -L swap $part 2>&1`;
	if ($? >> 8) {
	  warn "oneSIS: Error making swap partition $part: $output\n";
	}
	else {
	  $output = `/sbin/swapon $part 2>&1`;
	  if ($? >> 8) {
	    warn "oneSIS: Error activating swap partition $part: $output\n";
	  }
	}
      }
    }
    if ($dryrun || !$mountparts) {
      $output = `/sbin/swapoff $part 2>&1`;
    }
  }

  # Format, label, and mount partitions
 PARTITION: foreach my $partition (sort by_nested_dirs keys %mounts) {
    my $localdisk_elem = $mounts{$partition};
    my $mountpoint = $localdisk_elem->file_elem()->path();
    my $fstype = $localdisk_elem->fstype();
    my $do_fastmount = $localdisk_elem->fastmount();
    my $label = $localdisk_elem->label();
    my $device = $device{$partition};
    my $mkfsopts = "";

    # Verify label if we are doing a fastmount
    # ext filesystems only at the moment
    $do_fastmount = 0 if (defined $device && exists $partitioned{$device});
    if ($do_fastmount) {
      if ($fstype =~ /^xfs$/i) {
	my $disklabel = `/usr/sbin/xfs_admin -l $partition`;
	chomp $disklabel;
	$disklabel =~ /label = "(.*)"/;
	if (defined $label) {
	  unless ($label eq $1) {
	    $do_fastmount = 0;
	  }
	}
	else {
	  $do_fastmount = 0;
	}
      }
      elsif ($fstype =~ /^ext[234]$/i) {
	my $disklabel = `/sbin/e2label $partition`;
	chomp $disklabel;
	if (defined $label) {
	  unless ($label eq $disklabel) {
	    $do_fastmount = 0;
	  }
	}
	else {
	  $do_fastmount = 0;
	}
      }
      else {
	print "oneSIS: Fastmount option not yet supported on $fstype\n";
	$do_fastmount = 0;
      }
    }

    unless ($do_fastmount) {
      # varying options for differing filesystem types -cdm
      $mkfsopts = " -q -b 4096  " if $fstype =~ /^ext[234]$/i;
      $mkfsopts = " -f " if $fstype eq "xfs" or $fstype eq "reiserfs" or $fstype eq "jfs";
      $mkfsopts = " -f -y " if $fstype eq "reiser4";

      # Format partition
      my $mntpoint = "$basedir/$mountpoint";
      $mntpoint =~ s|/+|/|g;
      print "oneSIS: Making $fstype filesystem on $partition for $mntpoint ...\n";
      unless ($dryrun) {
	$output = `/sbin/mkfs.$fstype $mkfsopts $partition 2>&1`;
	if ($? >> 8) {
	  warn "oneSIS: Error! Problem making $fstype partition on $partition:\n";
	  warn "*  *  * $output\n";
	  delete $mounts{$partition};
	  next PARTITION;
	}
      }

      # Label partition
      if (defined $label) {
	print "oneSIS: Labeling $partition: $label\n";
	unless ($dryrun) {
	  my $label_cmd = "";
	  $label_cmd = "/sbin/e2label $partition $label" if $fstype =~ /^ext[234]$/i;
	  $label_cmd = "/usr/sbin/xfs_admin -L $label $partition" if $fstype eq "xfs";
	  $label_cmd = "/sbin/reiserfstune $partition -l $label " if $fstype eq "reiserfs" or $fstype eq "reiser4";
	  $label_cmd = "/sbin/jfs_tune -L $label $partition" if $fstype eq "jfs";

	  $output = `$label_cmd 2>&1`; 
	  if ($? >> 8) {
	    warn "oneSIS: Error! Problem labelling partition $partition:\n";
	    warn "*  *  * $output\n";
	  }
	  if (!$label_cmd) {
	    warn "oneSIS: Warning! Did not label partition $partition:\n";
	    warn "*  *  * Filesystem type: $fstype\n";
	  }
	}
      }
    }

    # Mount partition
    if ($mountparts) {
      my $mntpoint = "$basedir/$mountpoint";
      $mntpoint =~ s|/+|/|g;
      print "oneSIS: Mounting $partition on $mntpoint\n";
      unless ($dryrun) {
	# Remember original directory's mode, user, and group
	my $transformed_path = transform_path($basedir, $mountpoint);
	my (undef,undef,$mode,undef,$uid,$gid) = lstat($transformed_path);
	$output = `/bin/mount $partition $basedir/$mountpoint 2>&1`;
	if ($? >> 8) {
	  warn "oneSIS: Error! Unable to mount $partition on $basedir/$mountpoint:\n";
	  warn "*  *  * $output\n";
	  delete $mounts{$partition};
	  next PARTITION;
	}

	# Set up permissions, user, and group of mounted filesystem to be the
	# same as its corresponding directory in the master image
	if ((chmod $mode, "$basedir/$mountpoint") < 1) {
	  warn "oneSIS: Warning! Unable to set permissions for $basedir/$mountpoint: $!\n";
	}
	if ((chown $uid, $gid, "$basedir/$mountpoint") < 1) {
	  warn "oneSIS: Warning! Unable to set ownership for $basedir/$mountpoint: $!\n";
	}
      }
    }
  }

  return (\%mounts, \@swap);

  sub by_nested_dirs {
  # Desc: Sort routine to sort nested directories from the top down
  #       ie: '/' should come before '/tmp', and '/usr' before '/usr/local'
  # Input: 1) $a -- implicit sort() argument
  #        2) $b -- implicit sort() argument
    my $dir_a = $mounts{$a}->file_elem()->path();
    my $dir_b = $mounts{$b}->file_elem()->path();
    if ($dir_a eq $dir_b) {
      return 0;
    }
    if ($dir_a =~ /^$dir_b.*$/) {
      return 1;
    }
    if ($dir_b =~ /^$dir_a.*$/) {
      return -1;
    }
  }
}

sub transform_path {
# Desc: Finds the valid transformation of a directory path containing possible
#       .default directories, or (optionally) all possible transformations of
#       the pathname, including valid CLASS/NODE/PROPERTY LINKBACK targets
# Input: 1) $  I   base pathname
#        2) $  I   relative pathname to find transformation of
#        3) $  I?  optional oneSIS::config object
#        4) $  I?  optional second oneSIS::config object only used to check if
#                  a previous config had hidden elements (requires option #3)
# Returns: If Input #3 is not present: $ full pathname possibly transformed
#                                      with .default directories or ''
#                                      if path doesn't exist
#          If Input #3 is present: \@ of all existing transformations of the
#                                  pathname including valid CLASS or NODE
#                                  LINKBACK targets
#          undef: on error
  if ($#_ < 1 || $#_ > 3) {
    return undef;
  }
  my ($basedir, $pathname, $config, $last_config) = @_;
  my (%linkback, %classes, %nodes, %props);
  my $regular_path = '';
  my $_transform_path;

  $_transform_path = sub {
  # Desc: Recursive anonymous inner subroutine for finding all existing
  #       path combinations.  It needs to be anonymous so it can share
  #       the 'linkback', 'classes', 'nodes', and 'props' hashes.
  # Input: 1) $  I   base pathname
  #        2) $  I   relative pathname to find transformation of
  #        3) $  I   The untransformed pathname of argument #1
  # Returns: \@ of all existing transformations of the pathname including
  #          valid CLASS/NODE/PROPERTY LINKBACK targets
    my ($transformed_path, $pathname, $regular_path) = @_;
    my (@all_paths);

    if ($pathname eq '' || $pathname eq '/') {
      push @all_paths, $transformed_path;
      return \@all_paths;
    }
    else {
      # Remove extra or trailing '/' marks.
      $pathname =~ s|/+|/|g;
    }

    # Iterate through directory tree, transforming the path if necessary
    $pathname =~ m|^/([^/]+)(/?.*)|;
    my ($file, $subdir) = ($1, $2);
    $regular_path .= "/$file";

    # Determine if file is already a oneSIS link (to /ram)
    if (-l "$transformed_path/$file") {
      my $target = readlink("$transformed_path/$file");
      if ($target =~ /^\/ram\//) {
	# Pathname is a oneSIS link to /ram.
	# Find all possible variations of linkback target paths
	# Check for regular and hidden version of the file
	my (@variations);

	if (! opendir(DIR, $transformed_path)) {
	  warn "oneSIS: Warning! Could not read directory $transformed_path: $!\n";
	  warn "*  *  * CLASS/NODE specific LINKBACK directories will not be affected.\n";
	}

	# Determine whether to check for a hidden file
	my $actual_file = $file;
	if ($linkback{$regular_path}{HIDDEN}) {
	  $actual_file = ".$file";
	}

	foreach my $path (grep /^$actual_file(\.\S+)?$/, readdir(DIR)) {
	  if ($path =~ /^$actual_file\.(\S+)$/) {
	    my $type = $1;
	    if ($type eq 'default') {
	      push @variations, "$transformed_path/$path";
	    }
	    elsif ($linkback{$regular_path}{CLASS} && $classes{$type}) {
	      push @variations, "$transformed_path/$path";
	    }
	    elsif ($linkback{$regular_path}{NODE} && $nodes{$type}) {
	      push @variations, "$transformed_path/$path";
	    }
	    elsif ($linkback{$regular_path}{PROPERTY} && $props{$type}) {
	      push @variations, "$transformed_path/$path";
	    }
	  }
	}
	closedir DIR;

	# Add the transformed path of each valid linkback variation
	foreach my $var (@variations) {
	  my $paths = &$_transform_path($var, $subdir, $regular_path);
	  foreach my $path (@$paths) {
	    push @all_paths, $path;
	  }
	}
      }
      else {
	# Path is a normal link, not a oneSIS (/ram) link
        # Append un-transformed path element to transformed path
	my $paths = &$_transform_path("$transformed_path/$file", $subdir, $regular_path);
	foreach my $path (@$paths) {
	  push @all_paths, $path;
	}
      }
    }
    elsif (-e "$transformed_path/$file" || -l "$transformed_path/$file") {
      # Append un-transformed path element to transformed path
      my $paths = &$_transform_path("$transformed_path/$file", $subdir, $regular_path);
      foreach my $path (@$paths) {
	push @all_paths, $path;
      }
    }
    else {
	#warn "oneSIS: Warning! Path doesn't exist: $transformed_path/$file\n";
    }
    return \@all_paths;
  };


  # This is the true start of the transform_path() subroutine
  if (defined $config) {

    if (defined $last_config) {
      # Mark all hidden paths in the last config
      foreach my $ramdisk_elem (@{$last_config->get_all_ramdisk_elems()}) {
	# Set flag if linkback is hidden
	if ($ramdisk_elem->hidden()) {
	  $linkback{$ramdisk_elem->file_elem()->path()}{HIDDEN} = 1;
	}
	else {
	  $linkback{$ramdisk_elem->file_elem()->path()}{HIDDEN} = 0;
	}
      }
    }

    # Build a hash of all valid CLASS/NODE/PROPERTY LINKBACKs
    # so we don't have to loop through the config each time
    foreach my $ramdisk_elem (@{$config->get_all_ramdisk_elems()}) {
      next unless $ramdisk_elem->type() =~ /^LINKBACK/;

      # Set flag if linkback is hidden
      if ($ramdisk_elem->hidden()) {
	$linkback{$ramdisk_elem->file_elem()->path()}{HIDDEN} = 1;
      }
      else {
	$linkback{$ramdisk_elem->file_elem()->path()}{HIDDEN} = 0;
      }

      # Specify that a CLASS LINKBACK exists for this path element
      if ($ramdisk_elem->linkback() eq 'CLASS') {
	$linkback{$ramdisk_elem->file_elem()->path()}{CLASS} = 1;
	if (scalar(keys %classes) == 0) {
	  # Populate a list of valid classes if we haven't done it already
	  foreach my $class (@{$config->get_all_classdefs}) {
	    $classes{$class->name()} = 1;
	  }
	}
      }
      elsif ($ramdisk_elem->linkback() eq 'NODE') {
	$linkback{$ramdisk_elem->file_elem()->path()}{NODE} = 1;
	if (scalar(keys %nodes) == 0) {
	  # Populate a hash of valid nodes if we haven't done it already
	  if (!open (HOSTS, "<$basedir/etc/hosts")) {
	    warn "oneSIS: WARNING! Could not open $basedir/etc/hosts: $!\n";
	    warn "*  *  * NODE specific LINKBACK directories will not be affected.\n";
	  }
	  else {
	    while (defined ($_ = <HOSTS>)) {
	      # trim off trailing whitespace and comments
	      s/[\s\t]*(\#.*)?$//;
	      if (/^[\s\t]*\S+(([\s\t]+(\S+))+)/) {
		my $hosts = $1;
		while ($hosts =~ /[\s\t]+(\S+)/g) {
		  $nodes{$1} = 1;
		}
	      }
	    }
	    close HOSTS;
	  }
	}
      }
      elsif ($ramdisk_elem->linkback() eq 'PROPERTY') {
	$linkback{$ramdisk_elem->file_elem()->path()}{PROPERTY} = 1;
	if (scalar(keys %props) == 0) {
	  # Populate a list of valid properties if we haven't done it already
	  foreach my $prop (@{$config->get_all_properties}) {
	    $props{$prop} = 1;
	  }
	}
      }
    }
  }

  my $transformed_paths = &$_transform_path($basedir, $pathname, $regular_path);
  if (defined $config) {
    return $transformed_paths;
  }
  else {
    if (defined $$transformed_paths[0]) {
      return $$transformed_paths[0];
    }
    else {
      return '';
    }
  }

}

sub file_globs {
# Desc: Takes a path with (or without) wildcard globbing and returns all
#       matches for the glob.  Probable LINKBACK targets and .default files
#       are filtered out of the glob results.
# Input: 1) $  I   full pathname possibly containing wildcard glob syntax
#        2) $  I   base directory
#        3) $? I   hash of linkback paths to ignore (key=pathname, value=1)
# Returns: \@ array of pathnames of all files matching the glob
#          undef: on error
  if ($#_ < 1 || $#_ > 2) {
    return undef;
  }
  my ($path, $basedir, $linkbacks) = @_;
  my (@glob_files, @tmp_file_list, @file_list);

  $path =~ m|^(.*)/(.+)$|;
  my ($dir, $filename) = ($1, $2);
  $dir = '/' if $dir eq '';

  # Glob files in the the transformed directory of the right root image
  my $transformed_path = oneSIS::transform_path($basedir, $dir);
  return undef if !defined $transformed_path;
  $transformed_path = '/' if $transformed_path eq '';
  @tmp_file_list = bsd_glob("$transformed_path/$filename");

  # Don't allow any oneSIS file variants (.default files, etc.)
  # to be included in the glob match
  foreach my $file (@tmp_file_list) {
    my $oneSIS_file = 0;
    if ($file =~ /(.*)\.default$/) {
      my $base_file = $1;
      if (-l $base_file) {
	my $target = readlink($base_file);
	$oneSIS_file = 1 if $target =~ m|^/ram/|;
      }
    }
    $file =~ /^(.*)\/(.+)$/;
    my ($translated_dir, $variant) = ($1, $2);
    while ($variant =~ s|(.*)\..*|$1|g) {
      $oneSIS_file = 1 if $$linkbacks{"$dir/$variant"};
    }
    unless ($oneSIS_file) {
      push @file_list, $file;
    }
  }

  # Build file list of globbed files with the un-transformed directory
  foreach my $file (@file_list) {
    $file =~ s|$transformed_path|$dir|;
    $file =~ s|/+|/|g;
    push @glob_files, $file;
  }

  return \@glob_files;
}

sub check_disks {
# Desc: Checks for available hard-drive devices.
# Input: None
# Returns: \% hash of device names (key=device number; value=device name)
  my (%disks);
  my $num = 1;

  print "oneSIS: Checking for local disks ...\n";

  # Check for existence of disks
  open(PARTITIONS, "</proc/partitions")
    or warn "Could not open /proc/partitions: $!\n";
  while (defined ($_ = <PARTITIONS>)) {
    my $device = undef;
    my $diskdevice = 0;
    next unless (/^[\s\t]+\d+[\s\t]+\d+[\s\t]+\d+[\s\t]+(\S+)/);
    $device = $1;
    if ($device =~ /disc$/) {
      $diskdevice = 1;
    }
    elsif ($device =~ /c\d+d\d+$/) {
      # non-devfs cciss naming convention
      $diskdevice = 1;
    }
    elsif ($device !~ /\d+$/) {
      $diskdevice = 1;
    }

    if ($diskdevice) {
      print "oneSIS: Found local disk: /dev/$device\n";
      $disks{$num} = $device;
      $num++;
    }
  }
  close(PARTITIONS);

  return \%disks;
}

sub get_disk_size {
# Desc: Return safely usable disk size of given device
#       There's really gotta be a better way of doing this.
#       I don't know how to determine the exact number of usable blocks
# Input: 1) $  I   Device name (ie: hda, sda)
# Returns: $ size of disk device
#          undef: on error
  my ($device) = @_;
  my ($diskinfo, $disksize);

  $disksize = `/sbin/sfdisk -s /dev/$device 2>/dev/null`;
  if ($? >> 8) {
    warn "oneSIS: Error(1) running sfdisk: $disksize";
    return undef;
  }
  $diskinfo = `/sbin/sfdisk -l /dev/$device 2>/dev/null`;
  if ($? >> 8) {
    warn "oneSIS: Error(2) running sfdisk: $diskinfo";
    return undef;
  }
  if ($diskinfo =~ /(\d+) cylinders/) {
    # sfdisk cannot use all of the blocks it reports.
    # subtract the number of cylinders to be safe
    $disksize -= $1;
  }
  else {
    warn "oneSIS: Unexpected output from sfdisk: $diskinfo\n";
    return undef;
  }

  # Reserve 2048 blocks for embedding larger bootloaders (eg: grub2)
  $disksize -= 2048;
  return $disksize;
}

sub mk_path {
# Desc: Recursively create a directory
# Input: 1) $  I   directory
#        2) $  I   base directory
# Returns: undef: on error
  my ($path, $basedir) = @_;

  unless (-d "$basedir/$path") {
    if ($path =~ /^(.*)\/(.+)$/) {
      my ($parent, $dir) = ($1, $2);
      mk_path($parent, $basedir);

      # Create the directory
      if (!mkdir("$basedir/$path", oct('0755'))) {
	warn "oneSIS: Error! Unable to create directory $basedir$path: $!\n";
	return undef;
      }
    }
    elsif ($path =~ /^$basedir$|^$/) {
      return 0;
    }
  }
}

sub differs {
# Desc: Check if file or directory tree differs
# Input: 1) $  I    src file or dir
#        2) $  I    destination file or dir
# Returns: 1: files or dirs differ
#          0: files or dirs do not differ
  my ($src, $dest) = @_;
  my $differs = 0;
  our @diff_file_list = ();
  my $dest_rename = $dest;
  $dest_rename =~ s|/ram||;

  if (-l $src) {
    if (-l $dest) {
      my $src_target = readlink($src);
      my $dest_target = readlink($dest);
      if ($src_target ne $dest_target) {
	$differs = 1;
      }
    }
    else {
      $differs = 1;
    }
  }
  elsif (-f $src) {
    if (-l $dest) {
      $differs = 1;
    }
    elsif (-f $dest) {
      my $chksum1 = `md5sum $src`; chomp $chksum1;
      my $chksum2 = `md5sum $dest`; chomp $chksum2;
      $chksum1 =~ s/^(\S+).*/$1/;
      $chksum2 =~ s/^(\S+).*/$1/;
      if ($chksum1 ne $chksum2) {
	$differs = 1;
      }
    }
    else {
      $differs = 1;
    }
  }
  elsif (-d $src) {
    if (-d $dest) {
      find({ wanted => sub {push @diff_file_list, $_}, no_chdir => 1 }, $src);
      foreach my $file (@diff_file_list) {
	my $file_rename = $file;
	$file_rename =~ s/$src/$dest_rename/;
	if (-e "/ram/$file_rename") {
	  if (-f $file) {
	    if (differs($file, "/ram/$file_rename")) {
	      $differs = 1;
	    }
	  }
	}
	else {
	  $differs = 1;
	}
      }
    }
    else  {
      $differs = 1;
    }
  }
  else {
    $differs = 1;
  }

  return $differs;
}

sub final_target {
# Desc: Follow a symbolic link to determine the absolute path
#       of its final target
# Input: 1) $  I    absolute path of link to follow
#        2) $  I    quiet -- don't print warnings
# Returns: $ absolute path of final link target
#          undef: on error
  my ($file, $quiet) = @_;
  my $abs_file = $file;
  my $orig_file = $file;
  $file =~ m|^(.*)/.+$|;
  my $target_dir = $1;
  my $target;
  my %seen;

  if (! -l $file) {
    return undef;
  }

  # Follow link to final target
  while (defined ($target = readlink $abs_file)) {
    if ($seen{$target}) {
      $quiet || warn "oneSIS: Warning! Circular link found: $orig_file\n";
      return undef;
    }
    $seen{$file} = 1;
    $file = $target;
    # Keep track of absolute path of link target
    if ($file =~ m|^/|) {	# Absolute path
      $abs_file = $file;
      if ($file =~ m|^(/.*)/|) {
	$target_dir = $1;
      } else {
	$target_dir = $file;
      }
    } else {			# Relative path
      $abs_file = "$target_dir/$file";
    }
    if (! (-e $abs_file || -l $abs_file)) {
      $quiet || warn "oneSIS: Warning! Broken link found: $orig_file\n";
      return undef;
    }
  }
  return $abs_file;
}

sub copy_file {
# Desc: Copy file if it differs, following links if necessary
# Input: 1) $  I    src file
#        2) $  I    destination file (not dir)
#        3) $  I?   Optional: check if files differ first
# Returns: undef: on error
  my ($src, $dest, $do_check) = @_;

  $src =~ m|^(.*)/(.*)$|;
  my ($src_dir, $src_file) = ($1, $2);
  $dest =~ m|^(.*)/(.*)$|;
  my ($dest_dir, $dest_file) = ($1, $2);

  # Check if the existing file is the same as the image file
  my $copy = 1;
  if ($do_check) {
    if (! differs($src, $dest)) {
      $copy = 0;
    }
  }

  if ($copy) {
    # Copy the file from the image
    if (-l $src) {
      # Traverse links / copy first link and the actual file
      my $final_target = final_target($src);
      if (!defined $final_target) {
	warn "*  *  * File not being copied: $src\n";
	return undef;
      }
      if (-d $final_target) {
	warn "oneSIS: Warning! Not copying directory: $src\n";
	return undef;
      }

      # Copy final link target as well
      $final_target =~ m|^.*/(.+)$|;
      my $filename = $1;

      if (defined (copy_file($final_target, "$dest_dir/$filename"))) {
	unless ($filename eq $src_file) {
	  chdir($dest_dir);
	  unless (symlink($filename, $src_file)) {
	    warn "oneSIS: Error! Could not create symlink for $src: $!\n";
	  }
	}
      }
      else {
	return undef;
      }
    }
    else {
      oneSIS::mk_path($src_dir, '/ram');
      system("cp -a '$src' '$dest' &> /dev/null");
      if ($? >> 8) {
	warn "oneSIS: Error! Could not copy file: $src: $!\n";
	return undef;
      }

      if ($src_file ne $dest_file) {
	rename("$dest_dir/$src_file", "$dest_dir/$dest_file");
      }
    }
  }
}

sub copy_dir {
# Desc: # Copy a directory tree
# Input: 1) $  I    src dir
#        2) $  I    destination dir
#        3) $  I?   dryrun
#        4) $  I?   quiet
# Returns: undef: on error
  my ($src, $dest, $dryrun, $quiet) = @_;
  my $dest_rename = $dest;
  $dest_rename =~ s|/ram||;

  $src =~ m|^(.*)/(.+)$|;
  my ($src_dir, $src_file) = ($1, $2);
  $dest =~ m|^(.*)/(.+)$|;
  my ($dest_dir, $dest_file) = ($1, $2);

  if (! -d $src) {
    warn "oneSIS: Warning! Not a directory: $src\n";
    return undef;
  }
  our @copy_file_list = undef;
  find({ wanted => sub {push @copy_file_list, $File::Find::name}, no_chdir => 1 }, $src);

  foreach my $file (@copy_file_list) {
    next if !defined $file;
    my $file_rename = $file;
    $file_rename =~ s/$src/$dest_rename/;
    if (-d $file) {
      unless (-d "/ram/$file_rename") {
	$quiet || print "*  *  * Copying directory to /ram: $file\n";
	unless ($dryrun) {
	  oneSIS::mk_path($file_rename, '/ram');
	  oneSIS::mirror_props($file_rename, '/', '/ram');
	}
      }
    }
    elsif (differs($file, "/ram/$file_rename")) {
      $quiet || print "*  *  * Copying file to /ram: $file\n";
      unless ($dryrun) {
	if (!defined (copy_file($file, "/ram/$file_rename"))) {
	  warn "oneSIS: Error! Could not copy file to /ram: $file: $!\n";
	}
      }
    }
  }
}

sub set_props {
# Desc: Sets file permissions, owner, and group of a ramdisk element.
# Input: 1) $  I   file_elem class
#        2) $  I?  Optional base directory (defaults to '/')
# Returns: Nothing
  my ($file_elem, $basedir) = @_;
  my ($mode, $user, $group);
  my $path = $file_elem->path();

  if (! defined $basedir) {
    $basedir = '/';
  }

  # Set mode if configured
  if (defined ($mode = $file_elem->mode())) {
    chmod oct($mode), "$basedir/$path";
  }

  # Set user if configured
  if (defined ($user = $file_elem->user())) {
    my (undef,undef,$uid) = getpwnam($user) or warn "oneSIS: Warning! $user not in passwd file: setting uid 0 for $basedir/$path\n";
    if (!defined $uid) { $uid = 0; }
    if (!chown($uid, -1, "$basedir/$path")) {
      warn "oneSIS: Error changing ownership on $basedir/$path\n";
    }
  }

  # Set user if configured
  if (defined ($group = $file_elem->group())) {
    my (undef,undef,$gid) = getgrnam($group) or warn "oneSIS: Warning! $group not in group file: setting gid 0 for $basedir/$path\n";
    if (!defined $gid) { $gid = 0; }
    if (!chown(-1, $gid, "$basedir/$path")) {
      warn "oneSIS: Error changing group ownership on $basedir/$path\n";
    }
  }
}

sub mirror_props {
# Desc: Sets file permissions, owner, and group of a pqth element to be
#       the same as the corresponding file in the rootFS image
# Input: 1) $  I   pathname of filesystem element (relative to $basedir)
#        2) $  I   Master image location
#        3) $  I   Base directory of pathname to operate on
# Returns: undef: on error
  my ($path, $image, $basedir) = @_;

  # Read existing permissions, user, and group
  my $transformed_path = transform_path('/', $path);
  if (!defined $transformed_path || $transformed_path eq '') {
    warn "oneSIS: Cannot mirror properties of $path\n";
    return undef;
  }
  my (undef,undef,$mode,undef,$uid,$gid) = lstat($transformed_path);
  if (!defined $mode) {
    warn "oneSIS: lstat of file failed: $transformed_path: $!\n";
    warn "*  *  * Cannot mirror properties of $path\n";
    return undef;
  }

  unless (-l "$basedir/$path") {
    # Set permissions mode
    if ((chmod $mode, "$basedir/$path") < 1) {
      warn "oneSIS: Warning! Unable to set permissions for $basedir/$path: $!\n";
    }

    # Set owning user and group
    if ((chown $uid, $gid, "$basedir/$path") < 1) {
      warn "oneSIS: Warning! Unable to set ownership for $basedir/$path: $!\n";
    }
  }
}


#-------- class Object --------#

package oneSIS::class;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &name
	     &add_subclass
	     &get_subclass
	     &parent
	     );

sub new {
# Desc: class object constructor
# Input: 1) $  I   class name
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 0) {
      return undef;
    }
    my ($name) = @_;

    $self->name($name);
    $self->{SUBCLASSES} = {};
    $self->{PARENT} = undef;

    return $self;
}

# class->name() method
sub name {
# Desc: Gets or sets class name
# Input: 1) $  I?  Optional class name.
#                  The data is set to the value of the argument, if given.
# Returns: $ class name
    my $self = shift;
    if (@_) { $self->{NAME} = shift; }
    return $self->{NAME};
}

# class->add_subclass() method
sub add_subclass {
# Desc: Adds a subclass to the current class
# Input: 1) $  I   subclass name
# Returns: $ oneSIS::class object
#          undef: on error
    my $self = shift;
    if ($#_ != 0) {
      return undef;
    }
    my ($name) = @_;

    ${$self->{SUBCLASSES}}{$name} = new oneSIS::class($name);
    ${$self->{SUBCLASSES}}{$name}->{PARENT} = $self;

    return ${$self->{SUBCLASSES}}{$name};
}

# class->get_subclass() method
sub get_subclass {
# Desc: Retreive a subclass of the current class
# Input: 1) $  I   subclass name
# Returns: $ oneSIS::class object
#          undef: on error
    my $self = shift;
    if ($#_ != 0) {
      return undef;
    }
    my ($name) = @_;

    if (exists ${$self->{SUBCLASSES}}{$name}) {
      return ${$self->{SUBCLASSES}}{$name};
    }
    else {
      return undef;
    }
}

# class->parent() method
sub parent {
# Desc: Retreive the parent class of the current subclass
# Input: None
# Returns: $ oneSIS::class object
#          undef: on error
    my $self = shift;
    if ($#_ != -1) {
      return undef;
    }

    return $self->{PARENT};
}


#-------- classdef Object --------#

package oneSIS::classdef;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &name
	     &desc
	     &type
	     );

sub new {
# Desc: classdef object constructor
# Input: 1) $  I   class name
#        2) $  I   description -- can be regexp string, range spec, or hostname
#        3) $  I   type -- can be one of 'REGEXP', 'MAP', or 'RANGE'
# Returns: $ blessed object, populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 2) {
      return undef;
    }
    my ($name, $desc, $type) = @_;

    $self->name($name);
    $self->desc($desc);
    if (defined $self->type($type)) {
      return $self;
    }
    else {
      return undef;
    }
}

# classdef->name() method
sub name {
# Desc: Gets or sets class name
# Input: 1) $  I?  Optional class name.
#                  The data is set to the value of the argument, if given.
# Returns: $ class name
    my $self = shift;
    if (@_) { $self->{NAME} = shift; }
    return $self->{NAME};
}

# classdef->desc() method
sub desc {
# Desc: Gets or sets class description
# Input: 1) $  I?  Optional description -- regexp, range spec, or hostname.
#                  The data is set to the value of the argument, if given.
# Returns: \@ descriptions of this class
    my $self = shift;
    if (@_) { $self->{DESC} = shift; }
    return $self->{DESC};
}

# classdef->type() method
sub type {
# Desc: Gets or sets class type
# Input: 1) $  I?  Optional type -- can be one of 'REGEXP', 'MAP', or 'RANGE'.
#                  The data is set to the value of the argument, if given.
# Returns: $ class type
#          undef: on error
    my $self = shift;
    if (@_) {
      my $type = shift;
      if ($type =~ /^(MAP|REGEXP|RANGE)$/i) {
        $self->{TYPE} = $type;
      }
      else {
        warn "oneSIS: Error! Invalid class type: $type\n";
        return undef;
      }
    }
    return $self->{TYPE};
}


#-------- modifier Object --------#

package oneSIS::modifier;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &classes
	     &nodes
	     &properties
	     &ranges
	     &regexps
	     );

sub new {
# Desc: modifier object constructor
# Input: None
# Returns: $ blessed object, empty
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != -1) {
      return undef;
    }

    $self->{CLASSES} = [];
    $self->{NODES} = [];
    $self->{PROPERTIES} = [];
    $self->{RANGES} = [];
    $self->{REGEXPS} = [];

    return $self;
}

# modifier->classes() method
sub classes {
# Desc: Adds a class or returns all classes in the object
# Input: 1) $  I?  Optional class name.
#                  The data is set to the value of the argument, if given.
# Returns: \@ all classes in the object
    my $self = shift;
    if (@_) { push @{$self->{CLASSES}}, shift; }
    return \@{$self->{CLASSES}};
}

# modifier->nodes() method
sub nodes {
# Desc: Adds a node or returns all nodes in the object
# Input: 1) $  I?  Optional node name.
#                  The data is set to the value of the argument, if given.
# Returns: \@ all nodes in the object
    my $self = shift;
    if (@_) { push @{$self->{NODES}}, shift; }
    return \@{$self->{NODES}};
}

# modifier->properties() method
sub properties {
# Desc: Adds a property or returns all properties in the object
# Input: 1) $  I?  Optional property name.
#                  The data is set to the value of the argument, if given.
# Returns: \@ all properties in the object
    my $self = shift;
    if (@_) { push @{$self->{PROPERTIES}}, shift; }
    return \@{$self->{PROPERTIES}};
}

# modifier->ranges() method
sub ranges {
# Desc: Adds a range or returns all ranges in the object
# Input: 1) $  I?  Optional range.
#                  The data is set to the value of the argument, if given.
# Returns: \@ all ranges in the object
    my $self = shift;
    if (@_) { push @{$self->{RANGES}}, shift; }
    return \@{$self->{RANGES}};
}

# modifier->regexps() method
sub regexps {
# Desc: Adds a regexp or returns all regexps in the object
# Input: 1) $  I?  Optional regexp.
#                  The data is set to the value of the argument, if given.
# Returns: \@ all regexps in the object
    my $self = shift;
    if (@_) { push @{$self->{REGEXPS}}, shift; }
    return \@{$self->{REGEXPS}};
}


#-------- property Object --------#

package oneSIS::property;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &property
             &applies_to
	     &modifier
	     );

sub new {
# Desc: property object constructor
# Input: 1) $  I   property
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 0) {
      return undef;
    }
    my ($property) = @_;

    $self->{PROPERTY} = $property;
    $self->{MODIFIER} = new oneSIS::modifier();

    return $self;
}

# property->property() method
sub property {
# Desc: Gets or sets property
# Input: 1) $  I?  Optional property.
#                  The data is set to the value of the argument, if given.
# Returns: $ property
    my $self = shift;
    if (@_) { $self->{PROPERTY} = shift; }
    return $self->{PROPERTY};
}

# property->applies_to() method
sub applies_to {
# Desc: Checks if property applies to a given class, host
# Input: 1) $  I   oneSIS::config object
#        2) $  I   hostname
# Returns: $ 1: if property applies to the given hostname
#            0: otherwise
#        undef: on error
  my $self = shift;

  if ($#_ != 1) {
    return undef;
  }
  my ($config, $hostname) = @_;
  my $applies_to = 0;

  # Check if property applies to the given node
  foreach my $node (@{$self->modifier()->nodes()}) {
    if ($node eq $hostname) {
      $applies_to = 1;
      last;
    }
  }
  return 1 if $applies_to;

  # Check if property applies to the node's class
  my $myclass = oneSIS::get_node_class($config, $hostname);
  if (defined $myclass) {
  CLASS: foreach my $class (@{$self->modifier()->classes()}) {
      foreach my $classname ($myclass, @{$config->parents_of($myclass)}) {
	if ($classname eq $class) {
	  $applies_to = 1;
	  last CLASS;
	}
      }
    }
  }
  return 1 if $applies_to;

  # Check if property applies to the given range of nodes
  foreach my $range (@{$self->modifier()->ranges()}) {
    if (oneSIS::match_range($range, $hostname)) {
      $applies_to = 1;
      last;
    }
  }
  return 1 if $applies_to;

  # Check if property applies to the given regexp of nodes
  foreach my $regexp (@{$self->modifier()->regexps()}) {
    if ($hostname =~ /^$regexp$/) {
      $applies_to = 1;
      last;
    }
  }
  return $applies_to;
}

# property->modifier() method
sub modifier {
# Desc: Returns the modifier object contained in this object
# Input: None
# Returns: $ oneSIS::modifier object
#          undef: on error
    my $self = shift;
    if ($#_ == -1) {
      return $self->{MODIFIER};
    }
    else {
      return undef;
    }
}


#-------- file_elem Object --------#

package oneSIS::file_elem;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &path
	     &mode
             &user
             &group
	     );

sub new {
# Desc: file_elem object constructor
# Input: 1) $  I   file_elem full pathname
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 0) {
      return undef;
    }
    my ($path) = @_;

    if (!defined $self->path($path)) {
      return undef;
    }
    $self->{MODE} = undef;
    $self->{USER} = undef;
    $self->{GROUP} = undef;

    return $self;
}

# file_elem->path() method
sub path {
# Desc: Gets or sets file_elem path
# Input: 1) $  I?  Optional file_elem full pathname.
#                  The data is set to the value of the argument, if given.
# Returns: $ path
#          undef: on error
    my $self = shift;
    if (@_) {
      my $path = shift;

      # Only allow absolute paths
      if ($path !~ /^\//) {
	warn "oneSIS: Error! Not an absolute pathname: $path\n";
	return undef;
      }

      # Remove any trailing '/'s but allow the '/' directory
      unless ($path =~ /^\/+$/) {
        $path =~ s/^(.*)\/+$/$1/;
      }
      $self->{PATH} = $path;
    }
    return $self->{PATH};
}

# file_elem->mode() method
sub mode {
# Desc: Gets or sets file_elem mode
# Input: 1) $  I?  Optional file_elem permissions mode.
#                  The data is set to the value of the argument, if given.
# Returns: $ mode
    my $self = shift;
    if (@_) { $self->{MODE} = shift; }
    return $self->{MODE};
}

# file_elem->user() method
sub user {
# Desc: Gets or sets file_elem user
# Input: 1) $  I?  Optional file_elem user name.
#                  The data is set to the value of the argument, if given.
# Returns: $ user
    my $self = shift;
    if (@_) { $self->{USER} = shift }
    return $self->{USER};
}

# file_elem->group() method
sub group {
# Desc: Gets or sets file_elem group
# Input: 1) $  I?  Optional file_elem group name.
#                  The data is set to the value of the argument, if given.
# Returns: $ group
    my $self = shift;
    if (@_) { $self->{GROUP} = shift; }
    return $self->{GROUP};
}


#-------- service Object --------#

package oneSIS::service;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &name
	     &ramdisk_elem
	     );

sub new {
# Desc: service object constructor
# Input: 1) $  I   service name
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 0) {
      return undef;
    }
    my ($name) = @_;

    $self->name($name);
    $self->{RAMDISK_ELEM} = undef;
    $self->{MODIFIER} = new oneSIS::modifier();

    return $self;
}

# service->name() method
sub name {
# Desc: Gets or sets service name
# Input: 1) $  I?  Optional service name.
#                  The data is set to the value of the argument, if given.
# Returns: $ service name
    my $self = shift;
    if (@_) { $self->{NAME} = shift; }
    return $self->{NAME};
}

# service->ramdisk_elem() method
sub ramdisk_elem {
# Desc: Gets or sets the service ramdisk_elem
# Input: 1) $  I?  Optional service ramdisk_elem.
#                  The data is set to the value of the argument, if given.
# Returns: $ service ramdisk_elem
    my $self = shift;
    if (@_) { $self->{RAMDISK_ELEM} = shift; }
    return $self->{RAMDISK_ELEM};
}


#-------- ramdisk_elem Object --------#

package oneSIS::ramdisk_elem;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &file_elem
	     &type
	     &linkback
	     &forced
	     &hidden
	     &duplicate
	     &protected
	     &modifier
	     );

sub new {
# Desc: ramdisk_elem object constructor
# Input: 1) $  I   ramdisk_elem full pathname
#        2) $  I   type of directive  =~ RAM(FILE|DIR) or LINK(FILE|DIR|BACK)
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 1) {
      return undef;
    }
    my ($path, $type) = @_;

    $self->{FILE_ELEM} = new oneSIS::file_elem($path);
    if (!defined $self->{FILE_ELEM}) {
      return undef;
    }
    if (!defined $self->type($type)) {
      return undef;
    }
    $self->{LINKBACK} = undef;
    $self->{FORCED} = 0;
    $self->{HIDDEN} = 0;
    $self->{DUPLICATE} = 0;
    $self->{PROTECTED} = 0;
    $self->{MODIFIER} = new oneSIS::modifier();

    return $self;
}

# ramdisk_elem->file_elem() method
sub file_elem {
# Desc: Returns the file_elem object contained in this object
# Input: None
# Returns: $ oneSIS::file_elem object
#          undef: on error
    my $self = shift;
    if ($#_ == -1) {
      return $self->{FILE_ELEM};
    }
    else {
      return undef;
    }
}

# ramdisk_elem->type() method
sub type {
# Desc: Gets or sets ramdisk_elem type
# Input: 1) $  I?  Optional ramdisk_elem type.
#                  RAM(FILE|DIR) or LINK(FILE|DIR|BACK).
#                  The data is set to the value of the argument, if given.
# Returns: $ type
#          undef: on error
    my $self = shift;
    if (@_) {
      my $type = shift;
      if ($type =~ /^RAM(FILE|DIR)|LINK(FILE|DIR|BACK)$/i) {
	$self->{TYPE} = $type;
      }
      else { return undef; }
    }
    return $self->{TYPE};
}

# ramdisk_elem->linkback() method
sub linkback {
# Desc: Gets or sets ramdisk_elem linkback
# Input: 1) $  I?  Optional ramdisk_elem linkback target.
#                  The data is set to the value of the argument, if given.
# Returns: $ linkback target
    my $self = shift;
    if (@_) { $self->{LINKBACK} = shift; }
    return $self->{LINKBACK};
}

# ramdisk_elem->forced() method
sub forced {
# Desc: Gets or sets ramdisk_elem forced linkback flag
# Input: 1) $  I?  Optional ramdisk_elem forced linkback flag (0,1).
#                  The data is set to the value of the argument, if given.
# Returns: $ forced linkback status
#          undef: on error
    my $self = shift;
    if (@_) {
      my $status = shift;
      if ($status != 0 && $status != 1) {
        return undef;
      }
      $self->{FORCED} = $status;
    }
    return $self->{FORCED};
}

# ramdisk_elem->hidden() method
sub hidden {
# Desc: Gets or sets ramdisk_elem hidden flag
# Input: 1) $  I?  Optional ramdisk_elem hidden flag (0,1).
#                  The data is set to the value of the argument, if given.
# Returns: $ hidden linkback status
#          undef: on error
    my $self = shift;
    if (@_) {
      my $status = shift;
      if ($status != 0 && $status != 1) {
        return undef;
      }
      $self->{HIDDEN} = $status;
    }
    return $self->{HIDDEN};
}

# ramdisk_elem->duplicate() method
sub duplicate {
# Desc: Gets or sets ramdisk_elem duplicate flag used to indicate whether
#       the path element should be duplicated (copied) into /ram
# Input: 1) $  I?  Optional ramdisk_elem duplicate flag (0,1).
#                  The data is set to the value of the argument, if given.
# Returns: $ duplicate status
#          undef: on error
    my $self = shift;
    if (@_) {
      my $status = shift;
      if ($status != 0 && $status != 1) {
        return undef;
      }
      $self->{DUPLICATE} = $status;
    }
    return $self->{DUPLICATE};
}

# ramdisk_elem->protected() method
sub protected {
# Desc: Gets or sets ramdisk_elem protected flag used to indicate whether
#       the path element should be protected during updates to /ram
# Input: 1) $  I?  Optional ramdisk_elem protected flag (0,1).
#                  The data is set to the value of the argument, if given.
# Returns: $ protected status
#          undef: on error
    my $self = shift;
    if (@_) {
      my $status = shift;
      if ($status != 0 && $status != 1) {
        return undef;
      }
      $self->{PROTECTED} = $status;
    }
    return $self->{PROTECTED};
}

# ramdisk_elem->modifier() method
sub modifier {
# Desc: Returns the modifier object contained in this object
# Input: None
# Returns: $ oneSIS::modifier object
#          undef: on error
    my $self = shift;
    if ($#_ == -1) {
      return $self->{MODIFIER};
    }
    else {
      return undef;
    }
}


#-------- ramdisk Object --------#

package oneSIS::ramdisk;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &size
	     &unit
	     &modifier
	     );

sub new {
# Desc: ramdisk object constructor
# Input: 1) $  I   ramdisk size
#        2) $  I   unit of size (K, M, G) kilo, mega, or giga bytes
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 1) {
      return undef;
    }
    my ($size, $unit) = @_;

    $self->size($size);
    if (! defined $self->unit($unit)) {
      return undef;
    }
    $self->{MODIFIER} = new oneSIS::modifier();

    return $self;
}

# ramdisk->size() method
sub size {
# Desc: Gets or sets ramdisk size
# Input: 1) $  I?  Optional ramdisk size.
#                  The data is set to the value of the argument, if given.
# Returns: $ ramdisk size
    my $self = shift;
    if (@_) { $self->{SIZE} = shift; }
    return $self->{SIZE};
}

# ramdisk->unit() method
sub unit {
# Desc: Gets or sets ramdisk unit
# Input: 1) $  I?  Optional ramdisk unit (K, M, or G).
#                  The data is set to the value of the argument, if given.
# Returns: $ ramdisk unit
#          undef: on error
    my $self = shift;
    if (@_) {
      my $unit = shift;

      if (!defined $unit) {
	$unit = 'm';
      }
      elsif ($unit =~ /^[kKmMgG]$/) {
	$unit = lc($unit);
      }
      else {
	return undef;
      }
      $self->{UNIT} = $unit;
    }
    return $self->{UNIT};
}

# ramdisk->modifier() method
sub modifier {
# Desc: Returns the modifier object contained in this object
# Input: None
# Returns: $ oneSIS::modifier object
#          undef: on error
    my $self = shift;
    if ($#_ == -1) {
      return $self->{MODIFIER};
    }
    else {
      return undef;
    }
}


#-------- bootloader Object --------#

package oneSIS::bootloader;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &bootloader
	     &modifier
	     );

sub new {
# Desc: bootloader object constructor
# Input: 1) $  I   bootloader name (grub|grub2|lilo)
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 0) {
      return undef;
    }
    my ($bloader) = @_;

    if (!defined $self->bootloader($bloader)) {
	return undef;
    }
    $self->{MODIFIER} = new oneSIS::modifier();

    return $self;
}

# bootloader->bootloader() method
sub bootloader {
# Desc: Gets or sets bootloader name (grub|grub2|lilo)
# Input: 1) $  I?  Optional bootloader name.
#                  The data is set to the value of the argument, if given.
# Returns: $ bootloader name
    my $self = shift;
    if (@_) {
      my $bloader = shift;
      if ($bloader =~ /^(grub|grub2|lilo)$/i) {
	$self->{BOOTLOADER} = lc($bloader);
      }
      else { return undef; }
    }
    return $self->{BOOTLOADER};
}

# bootloader->modifier() method
sub modifier {
# Desc: Returns the modifier object contained in this object
# Input: None
# Returns: $ oneSIS::modifier object
#          undef: on error
    my $self = shift;
    if ($#_ == -1) {
      return $self->{MODIFIER};
    }
    else {
      return undef;
    }
}


#-------- path Object --------#

package oneSIS::path;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &path
	     &modifier
	     );

sub new {
# Desc: path object constructor
# Input: 1) $  I   path
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 0) {
      return undef;
    }
    my ($path) = @_;

    $self->{PATH} = $path;
    $self->{MODIFIER} = new oneSIS::modifier();

    return $self;
}

sub path {
# Desc: Gets or sets path
# Input: 1) $  I?  Optional path.
#                  The data is set to the value of the argument, if given.
# Returns: $ path
    my $self = shift;
    if (@_) { $self->{PATH} = shift; }
    return $self->{PATH};
}

# path->modifier() method
sub modifier {
# Desc: Returns the modifier object contained in this object
# Input: None
# Returns: $ oneSIS::modifier object
#          undef: on error
    my $self = shift;
    if ($#_ == -1) {
      return $self->{MODIFIER};
    }
    else {
      return undef;
    }
}


#-------- disk Object --------#

package oneSIS::disk;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &identifier
	     &device
	     &size
	     );

sub new {
# Desc: disk object constructor
# Input: 1) $  I   disk identifier (number, device)
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 0) {
      return undef;
    }
    my ($identifier) = @_;

    if (!defined $self->identifier($identifier)) {
	return undef;
    }
    $self->{DEVICE} = undef;
    $self->{SIZE} = undef;

    return $self;
}

# disk->identifier() method
sub identifier {
# Desc: Gets or sets disk identifier (number, device)
# Input: 1) $  I?  Optional disk identifier (number, device).
#                  The data is set to the value of the argument, if given.
# Returns: $ disk identifier
    my $self = shift;
    if (@_) { $self->{IDENTIFIER} = shift; }
    return $self->{IDENTIFIER};
}

# disk->device() method
sub device {
# Desc: Gets or sets disk device name
# Input: 1) $  I?  Optional device name (ie: hda, sda).
#                  The data is set to the value of the argument, if given.
# Returns: $ disk's device name
    my $self = shift;
    if (@_) { $self->{DEVICE} = shift; }
    return $self->{DEVICE};
}

# disk->size() method
sub size {
# Desc: Gets or sets disk size (in blocks)
# Input: 1) $  I?  Optional disk size (in blocks).
#                  The data is set to the value of the argument, if given.
# Returns: $ size (in blocks)
    my $self = shift;
    if (@_) { $self->{SIZE} = shift; }
    return $self->{SIZE};
}


#-------- localdisk_elem Object --------#

package oneSIS::localdisk_elem;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &disk
	     &type
	     &size
	     &actualsize
             &fstype
             &raidlevel
             &partitions
             &label
	     &file_elem
	     &modifier
	     );

sub new {
# Desc: localdisk_elem object constructor
# Input: 1) \@ I   array of oneSIS::disk objects
#        2) $  I   type of partition (SWAP,MOUNT)
#        3) $  I   size of partition
#        4) $? I   mount point of partition (for MOUNT type)
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 2 && $#_ != 3) {
      return undef;
    }
    my ($disks, $type, $size, $mountpoint) = @_;

    $self->{DISK} = $disks;
    if (!defined $self->type($type)) {
      return undef;
    }
    $self->size($size);
    $self->{ACTUALSIZE} = undef;
    if (defined $mountpoint) {
      if ($self->type() eq 'MOUNT') {
	$self->{FILE_ELEM} = new oneSIS::file_elem($mountpoint);
      }
      else {
	return undef;
      }
    }
    $self->{PARTITIONS} = [];
    $self->{FSTYPE} = 'ext2';
    $self->{RAIDLEVEL} = undef;
    $self->{LABEL} = undef;
    $self->{FASTMOUNT} = 0;
    $self->{NOMOUNT} = 0;
    $self->{MODIFIER} = new oneSIS::modifier();

    return $self;
}

# localdisk_elem->disk() method
sub disk {
# Desc: Gets the localdisk disk object(s)
# Input: None
# Returns: \@ array of oneSIS::disk objects
    my $self = shift;
    return $self->{DISK};
}

# localdisk_elem->partitions() method
sub partitions {
# Desc: Gets or sets localdisk partitions
# Input: 1) $  I?  Optional partition name (/dev/sda1, /dev/sdb1, etc).
#                  The data is appended with the value of the argument, if given.
# Returns: \@ array of partition names
#          undef: on error
    my $self = shift;
    if (@_) {
      push @{$self->{PARTITIONS}}, shift;
    }
    return $self->{PARTITIONS};
}

# localdisk_elem->type() method
sub type {
# Desc: Gets or sets localdisk type
# Input: 1) $  I?  Optional localdisk partition type (SWAP or MOUNT).
#                  The data is set to the value of the argument, if given.
# Returns: $ type
#          undef: on error
    my $self = shift;
    if (@_) {
      my $type = shift;
      if ($type =~ /^(SWAP|MOUNT)$/i) {
	$self->{TYPE} = $type;
      }
      else { return undef; }
    }
    return $self->{TYPE};
}

# localdisk_elem->size() method
sub size {
# Desc: Gets or sets localdisk size
# Input: 1) $  I?  Optional localdisk partition size (percentage or number).
#                  The data is set to the value of the argument, if given.
# Returns: $ size (percentage or number)
    my $self = shift;
    if (@_) { $self->{SIZE} = shift; }
    return $self->{SIZE};
}

# localdisk_elem->actualsize() method
sub actualsize {
# Desc: Gets or sets the actual size of the localdisk (in blocks)
# Input: 1) $  I?  Optional localdisk partition actual size (in blocks).
#                  The data is set to the value of the argument, if given.
# Returns: $ size
    my $self = shift;
    if (@_) { $self->{ACTUALSIZE} = shift; }
    return $self->{ACTUALSIZE};
}

# localdisk_elem->fstype() method
sub fstype {
# Desc: Gets or sets the localdisk element's filesystem type
# Input: 1) $  I?  Optional disk element's filesystem type.
#                  The data is set to the value of the argument, if given.
# Returns: $ type
#          undef: on error
    my $self = shift;
    if (@_) {
      my $type = shift;
       if (-x "/sbin/mkfs.$type") {
	$self->{FSTYPE} = $type;
      }
      else { return undef; }
    }
    return $self->{FSTYPE};
}

# localdisk_elem->raidlevel() method
sub raidlevel {
# Desc: Gets or sets the localdisk element's filesystem type
# Input: 1) $  I?  Optional disk element's filesystem type.
#                  The data is set to the value of the argument, if given.
# Returns: $ type
#          undef: on error
    my $self = shift;
    if (@_) {
      my $level = shift;
       if ($level =~ /^[0156]$/) {
	$self->{RAIDLEVEL} = $level;
      }
      else { return undef; }
    }
    return $self->{RAIDLEVEL};
}

# localdisk_elem->label() method
sub label {
# Desc: Gets or sets the localdisk element's label
# Input: 1) $  I?  Optional disk element's label.
#                  The data is set to the value of the argument, if given.
# Returns: $ label
    my $self = shift;
    if (@_) { $self->{LABEL} = shift; }
    return $self->{LABEL};
}

# localdisk_elem->fastmount() method
sub fastmount {
# Desc: Gets or sets flag to fastmount a disk (skip partitioning/mkfs)
# Input: 1) $  I?  1: fastmount flag
#                  The data is set to the value of the argument, if given.
# Returns: $ fastmount flag
    my $self = shift;
    if (@_) { $self->{FASTMOUNT} = shift; }
    return $self->{FASTMOUNT};
}

# localdisk_elem->nomount() method
sub nomount {
# Desc: Gets or sets flag to skip mounting of a disk (just partition/mkfs)
# Input: 1) $  I?  nomount flag
#                  The data is set to the value of the argument, if given.
# Returns: $ nomount flag
    my $self = shift;
    if (@_) { $self->{NOMOUNT} = shift; }
    return $self->{NOMOUNT};
}

# localdisk_elem->file_elem() method
sub file_elem {
# Desc: Returns the file_elem object contained in this object
# Input: None
# Returns: $ oneSIS::file_elem object
#          undef: on error
    my $self = shift;
    if ($#_ == -1) {
      return $self->{FILE_ELEM};
    }
    else {
      return undef;
    }
}

# localdisk_elem->modifier() method
sub modifier {
# Desc: Returns the modifier object contained in this object
# Input: None
# Returns: $ oneSIS::modifier object
#          undef: on error
    my $self = shift;
    if ($#_ == -1) {
      return $self->{MODIFIER};
    }
    else {
      return undef;
    }
}


#-------- specformat Object --------#

package oneSIS::specformat;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &spec_id
	     &format
	     &add_translation
	     &get_translations
	     );

sub new {
# Desc: specformat object constructor
# Input: 1) $  I   nodespec format (hostname,basic_range,ext_range etc.)
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 0) {
      return undef;
    }
    my ($format) = @_;

    if ($format !~ /^(ext_range\+?|basic_range\+?|hostname\+?|ipaddr\+?)$/) {
      warn "oneSIS: Error! Invalid nodespec format: $format\n";
      return undef;
    }

    $self->{FORMAT} = $format;
    $self->{TRANSLATIONS} = {};
    return $self;
}

# specformat->format() method
sub format {
# Desc: Gets specformat format type
# Input: None
# Returns: $ specformat format type
#          undef: on error
    my $self = shift;
    if ($#_ == -1) {
      return $self->{FORMAT};
    }
    else {
      return undef;
    }
}

# specformat->add_translation() method
sub add_translation {
# Desc: Gets or sets the specformat translation
# Input: 1) $  I   specformat translation (perl s/// expression)
#        2) $  I   specformat translation type (HOST|IP|SPEC)
# Returns: $ specformat translation
#          undef: on error
    my $self = shift;
    if ($#_ != 1) {
      return undef;
    }
    my ($translation, $type) = @_;
    if (exists $self->{TRANSLATIONS}{$type}) {
      warn "oneSIS: Error! $type translation for specformat '", $self->format(), "' already exists.\n";
      return undef;
    }
    if (($type eq 'HOST' && exists $self->{TRANSLATIONS}{IP})
	|| ($type eq 'IP' && exists $self->{TRANSLATIONS}{HOST})) {
      warn "oneSIS: Error! Only one HOST or IP translation allowed in specformat:", $self->format(), "\n";
      return undef;
    }

    $self->{TRANSLATIONS}{$type} = $translation;
    return $self->{TRANSLATIONS}{$type};
}

# specformat->get_translations() method
sub get_translations {
# Desc: Gets all translations defined for the specformat
# Input: None
# Returns: \% hash (key=translation type, value=specformat::translation object)
    my $self = shift;
    return \%{$self->{TRANSLATIONS}};
}


#-------- nodecmd Object --------#

package oneSIS::nodecmd;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &name
	     &function
	     &cmd
	     &modifier
	     );

sub new {
# Desc: nodecmd object constructor
# Input: 1) $  I   nodecmd name
#        2) $  I   command/arguments (any valid bash command(s))
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 1) {
      return undef;
    }
    my ($name, $cmd) = @_;

    $self->name($name);
    $self->cmd($cmd);
    $self->{MODIFIER} = new oneSIS::modifier();
    $self->{FUNCTION} = undef;

    return $self;
}

# nodecmd->name() method
sub name {
# Desc: Gets or sets nodecmd name
# Input: 1) $  I?  Optional name
#                  The data is set to the value of the argument, if given.
# Returns: $ name
#          undef: on error
    my $self = shift;
    if (@_) {
      $self->{NAME}  = shift;
    }
    return $self->{NAME};
}

# nodecmd->function() method
sub function {
# Desc: Gets or sets nodecmd function
# Input: 1) $  I?  Optional function
#                  The data is set to the value of the argument, if given.
# Returns: $ function
#          undef: on error
    my $self = shift;
    if (@_) {
      $self->{FUNCTION}  = shift;
    }
    return $self->{FUNCTION};
}

# nodecmd->cmd() method
sub cmd {
# Desc: Gets or sets nodecmd command
# Input: 1) $  I?  Optional command/arguments (any valid bash command(s)).
#                  The data is set to the value of the argument, if given.
# Returns: $ command string
    my $self = shift;
    if (@_) { $self->{CMD} = shift; }
    return $self->{CMD};
}

# nodecmd->modifier() method
sub modifier {
# Desc: Returns the modifier object contained in this object
# Input: None
# Returns: $ oneSIS::modifier object
#          undef: on error
    my $self = shift;
    if ($#_ == -1) {
      return $self->{MODIFIER};
    }
    else {
      return undef;
    }
}


#-------- cmdbuilder Object --------#

package oneSIS::cmdbuilder;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &add_nodes
             &get_nodes
             &add_range
             &get_ranges
             &add_regexp
             &get_regexps
             &add_class
             &get_classes
             &add_prop
             &get_props
	     &buildcmds
             &get_basic_range_specs
             &get_ext_range_specs
	     );

sub new {
# Desc: cmdbuilder object constructor
# Input: 1) $  I  Populated oneSIS::config object
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 0) {
      return undef;
    }
    my ($config) = @_;

    $self->{CONFIG} = $config;
    $self->{HOSTS} = [];
    $self->{RANGES} = [];
    $self->{REGEXPS} = [];
    $self->{CLASSES} = [];
    $self->{PROPS} = [];

    return $self;
}

# cmdbuilder->add_nodes() method
sub add_nodes {
# Desc: Adds nodes to build commands for
# Input: 1) \@  I  Array of hostnames
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  my ($nodes) = @_;

  map { push @{$self->{HOSTS}}, $_; } @$nodes;
}

# cmdbuilder->get_nodes() method
sub get_nodes {
# Desc: Returns all nodes (not ranges/regexps/classes/props) in the object
# Input: None
# Returns: \@  Array of hostnames
  my $self = shift;
  return  \@{$self->{HOSTS}};
}

# cmdbuilder->add_range() method
sub add_range {
# Desc: Adds a range specification of nodes to build commands for
# Input: 1) $  I  Range specification
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  my ($range) = @_;

  push @{$self->{RANGES}}, $range;
}

# cmdbuilder->get_ranges() method
sub get_ranges {
# Desc: Returns all ranges specification of nodes to build commands for
# Input: None
# Returns: \@  Array of range specifications
  my $self = shift;
  return  \@{$self->{RANGES}};
}

# cmdbuilder->add_regexp() method
sub add_regexp {
# Desc: Adds a regexp matching nodes to build commands for
# Input: 1) $  I  Regexp
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  my ($regexp) = @_;

  push @{$self->{REGEXPS}}, $regexp;
}

# cmdbuilder->get_regexps() method
sub get_regexps {
# Desc: Returns all regexps of nodes to build commands for
# Input: None
# Returns: \@  Array of regexps
  my $self = shift;
  return  \@{$self->{REGEXPS}};
}

# cmdbuilder->add_class() method
sub add_class {
# Desc: Adds a class name of nodes to build commands for
# Input: 1) $  I  Class name
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  my ($class) = @_;

  push @{$self->{CLASSES}}, $class;
}

# cmdbuilder->get_classes() method
sub get_classes {
# Desc: Returns all class names of nodes to build commands for
# Input: None
# Returns: \@  Array of class names
  my $self = shift;
  return  \@{$self->{CLASSES}};
}

# cmdbuilder->add_prop() method
sub add_prop {
# Desc: Adds a property of nodes to build commands for
# Input: 1) $  I  Property name
# Returns: undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  my ($prop) = @_;

  push @{$self->{PROPS}}, $prop;
}

# cmdbuilder->get_props() method
sub get_props {
# Desc: Returns all property names of nodes to build commands for
# Input: None
# Returns: \@  Array of property names
  my $self = shift;
  return  \@{$self->{PROPS}};
}

# cmdbuilder->noderange() method
sub noderange {
# Desc: Build a range of all nodes in the cmdbuilder object
# Input: 1) $   I   1: Return an array instead of a string
# Returns: $ range string of all nodes in the cmdbuilder object
#          \@  unsorted array of all nodes (if argument 1 is given)
#          undef: on error
  my $self = shift;
  my ($array) = @_;

  my $orig_hosts = oneSIS::get_host_ips();
  my $config = $self->{CONFIG};

  # Check range/regexp/class/property nodespecs
  my $hosts = $self->get_nodes();
  my $ranges = $self->get_ranges();
  my $regexps = $self->get_regexps();
  my $classes = $self->get_classes();
  my $props = $self->get_props();
  foreach my $hostname (keys %$orig_hosts) {
    if (oneSIS::match_nodespecs($config, $hostname, $ranges, $regexps,
				$classes, $props)) {
      push @$hosts, $hostname;
    }
  }
  if ($array) {
    return $hosts;
  }
  else {
    my $specs = $self->get_ext_range_specs($hosts);
    my $range = '';
    for my $spec (@$specs) {
      $spec =~ s/\[(\d+)\]/$1/;
      $range .= ',' unless $range eq '';
      $range .= $spec;
    }
    return $range;
  }
}

# cmdbuilder->buildcmds() method
sub buildcmds {
# Desc: This is the main engine for building commands based on node specs
# Input: 1) $   I   Name of command (used with oneSIS::config->add_nodecmd() )
#        2) $?  I   Option function (sub-command) for given command name
# Returns: \@ Array of commands to run
#          undef: on error
  my $self = shift;
  my ($cmd_name, $function) = @_;
  my (%format,%translation,%trans_left,%trans_right,@all_ophosts,$orig_hosts);
  my (%using_node_idx,%nodecmd_nodes,%node_hosts,%trans_hosts);
  my (%trans,@nodecmds);
  our (%rev_trans);

  $orig_hosts = oneSIS::get_host_ips();

  # Get all the configured node commands for the given name (and function)
  my %config_nodecmds;
  my $nodecmd_idx = 0;
  my $config = $self->{CONFIG};
  foreach my $nodecmd (@{$config->get_all_nodecmds()}) {
    next if $nodecmd->name() ne $cmd_name;
    if (defined $function) {
      my $node_func = $nodecmd->function();
      next if ! defined $node_func;
      if ($node_func eq $function) {
	$config_nodecmds{$nodecmd_idx} = $nodecmd;
	$nodecmd_idx++;
      }
    }
    else {
      $config_nodecmds{$nodecmd_idx} = $nodecmd;
      $nodecmd_idx++;
    }
  }

  if (defined $function && scalar(keys %config_nodecmds) == 0) {
    warn "oneSIS: Error! No NODECMD directive defined for function: $function\n";
    return undef;
  }

  # Determine all specformats used
  foreach my $nodecmd_idx (keys %config_nodecmds) {
    my $nodecmd = $config_nodecmds{$nodecmd_idx};
    if (defined $function) {
      next unless $nodecmd->function() eq $function;
    }
    my ($specformat, $spec_id) = (undef, undef);
    my $cmd = $nodecmd->cmd();

    if ($cmd =~ /SPEC:(\S+).*SPEC:(\S+)/) {
      if (defined $function) {
	warn "oneSIS: Error! Multiple SPECFORMATs referenced in NODECMD '$cmd_name', function '$function'\n";
      }
      else {
	warn "oneSIS: Error! Multiple SPECFORMATs referenced in NODECMD '$cmd_name'\n";
      }
      return undef;
    }
    if ($cmd =~ /SPEC:(\S+)/) {
      $spec_id = $1;
      if (!defined ($specformat = $config->get_specformat($spec_id))) {
	warn "oneSIS: Error! SPECFORMAT doesn't exist: $spec_id\n";
	if (defined $function) {
	  warn  "*  *  * NODECMD '$cmd_name' function '$function'\n";
	}
	else {
	  warn  "*  *  * NODECMD '$cmd_name'\n";
	}
	return undef;
      }
    }
    else {
      warn "oneSIS: Error! No SPECFORMAT referenced in NODECMD:\n";
      if (defined $function) {
	warn  "*  *  * NODECMD '$cmd_name' function '$function'\n";
      }
      else {
	warn  "*  *  * NODECMD '$cmd_name'\n";
      }
      return undef;
    }

    # Get the desired format
    $format{$spec_id} = $specformat->format();

    # Check for any nodespec translations
    my $spec_trans = $specformat->get_translations();
    foreach my $type (keys %$spec_trans) {
      $translation{$spec_id}{$type} = $$spec_trans{$type};
      $translation{$spec_id}{$type} =~ m|^s?/([^/]*)/([^/]*)/$|;
      ($trans_left{$spec_id}{$type},$trans_right{$spec_id}{$type}) = ($1,$2);

      # Add quotes so we can eval() the right hand side of the s///ee below
      # and any backreferences ($1,$2,etc.) will be interpolated
      $trans_right{$spec_id}{$type} = "\"$trans_right{$spec_id}{$type}\"";

      # Individually eval() any {...} blocks on the right hand so we can do
      # inline math in the s///ee substitutions below.  This is a break from
      # having a pure perl s/// expression in the SPECFORMAT translation, but
      # it lets us do what we want to do (inline math).
      $trans_right{$spec_id}{$type} =~ s/({.*?})/" . eval $1 . "/g;
    }
  }

  # Check hostname nodespecs
  my $ophosts = $self->get_nodes();
 OPHOST: foreach my $ophost (@$ophosts) {
    if (exists $$orig_hosts{$ophost}) {
      push @all_ophosts, $ophost;
      last OPHOST;
    }
  }

  # Check range/regexp/class/property nodespecs
  my $ranges = $self->get_ranges();
  my $regexps = $self->get_regexps();
  my $classes = $self->get_classes();
  my $props = $self->get_props();
  foreach my $hostname (keys %$orig_hosts) {
    if (oneSIS::match_nodespecs($config, $hostname, $ranges, $regexps,
				$classes, $props)) {
      push @all_ophosts, $hostname;
    }
  }

  # Find the right nodecmd and apply any translations for each node
 OPHOST: foreach my $hostname (@all_ophosts) {
    my ($spec_id) = (undef);
    my $classname = oneSIS::get_node_class($config, $hostname);
    next OPHOST unless defined $classname;

    # Determine which nodecmd to use for this node
    foreach my $nodecmd_idx (sort {$a <=> $b} keys %config_nodecmds) {
      my $nodecmd = $config_nodecmds{$nodecmd_idx};

      if ($config->using_directive($nodecmd->modifier(), $hostname,
				   $classname)) {
	# Keep track of which host uses which nodecmd and vice-versa
	$nodecmd->cmd() =~ /SPEC:(\S+)/;
	$spec_id = $1;
	$using_node_idx{$hostname} = $nodecmd_idx;
	$nodecmd_nodes{$nodecmd_idx}{HOSTS}{$hostname} = $$orig_hosts{$hostname};
	$nodecmd_nodes{$nodecmd_idx}{NODECMD} = $nodecmd;
      }
    }

    # Apply any nodespec translations
    if (!defined $using_node_idx{$hostname}) {
      warn "oneSIS: Warning! No matching NODECMD directive for node: $hostname\n";
      $node_hosts{$hostname} = 1;
      next OPHOST;
    }
    my $nodecmd_idx = $using_node_idx{$hostname};
    if (exists $translation{$spec_id}) {
      if (exists $translation{$spec_id}{HOST}) {
	# Apply the translation to the hostname
	my $nodetrans = $hostname;
	$nodetrans =~ s/$trans_left{$spec_id}{HOST}/$trans_right{$spec_id}{HOST}/ee;
	push @{$trans_hosts{$nodecmd_idx}}, $nodetrans;
	$rev_trans{$nodetrans} = $hostname;
	$trans{$hostname} = $nodetrans;
      } elsif (exists $translation{$spec_id}{IP}) {
	# Apply the translation to the IP address
	my $ip = $$orig_hosts{$hostname};
	my $orig_ip = $ip;
	$ip =~ s/$trans_left{$spec_id}{IP}/$trans_right{$spec_id}{IP}/ee;
	$rev_trans{$ip} = $orig_ip;
      }
    } else {
      push @{$trans_hosts{$nodecmd_idx}}, $hostname;
    }
    $node_hosts{$hostname} = 1;
  }

  # Complain about any hosts that don't exist in config file
  foreach my $host (@$ophosts) {
    unless ($node_hosts{$host}) {
      warn "oneSIS: Warning! Host unknown to oneSIS: $host\n";
    }
  }

  # Build nodespecs and node commands from every host
  foreach my $nodecmd_idx (keys %nodecmd_nodes) {
    my $nodecmd = $nodecmd_nodes{$nodecmd_idx}{NODECMD};
    my $hosts = $nodecmd_nodes{$nodecmd_idx}{HOSTS};
    my @nodespecs;

    # Get the specformat ID for this nodecmd
    my $cmd = $nodecmd->cmd();
    $cmd =~ /SPEC:(\S+)/;
    my $spec_id = $1;

    # Remove any hosts that shouldn't be operated on
    foreach my $host (keys %$hosts) {
      unless ($node_hosts{$host} && $using_node_idx{$host} == $nodecmd_idx) {
	delete $$hosts{$host};
      }
    }

    # Get nodespecs for the given spec format
    my @specs;
    if ($format{$spec_id} eq 'ext_range') {
      foreach my $nodespec (@{$self->get_ext_range_specs(\@{$trans_hosts{$nodecmd_idx}}, 0)}) {
	push @specs, $nodespec;
      }
    } elsif ($format{$spec_id} eq 'ext_range+') {
      foreach my $nodespec (@{$self->get_ext_range_specs(\@{$trans_hosts{$nodecmd_idx}}, 1)}) {
	push @specs, $nodespec;
      }
    } elsif ($format{$spec_id} eq 'basic_range') {
      foreach my $nodespec (@{$self->get_basic_range_specs(\@{$trans_hosts{$nodecmd_idx}}, 0)}) {
	push @specs, $nodespec;
      }
    } elsif ($format{$spec_id} eq 'basic_range+') {
      foreach my $nodespec (@{$self->get_basic_range_specs(\@{$trans_hosts{$nodecmd_idx}}, 1)}) {
	push @specs, $nodespec;
      }
    } elsif ($format{$spec_id} eq 'hostname') {
      if (exists $translation{$spec_id}{HOST}) {
	foreach my $trans (sort rev_trans_by_lastdigit keys %rev_trans) {
	  if (exists $$hosts{$rev_trans{$trans}}) {
	    push @specs, $trans;
	  }
	}
      } else {
	foreach my $host (sort keys %$hosts) {
	  push @specs, $host;
	}
      }
    } elsif ($format{$spec_id} eq 'hostname+') {
      my $all_hosts = '';
      if (exists $translation{$spec_id}{HOST}) {
	foreach my $trans (sort rev_trans_by_lastdigit keys %rev_trans) {
	  if (exists $$hosts{$rev_trans{$trans}}) {
	    $all_hosts .= " $trans";
	  }
	}
      } else {
	foreach my $host (sort keys %$hosts) {
	  $all_hosts .= " $host";
	}
      }
      push @specs, $all_hosts;
    } elsif ($format{$spec_id} eq 'ipaddr') {
      if (exists $translation{$spec_id}{IP}) {
	foreach my $trans (sort rev_trans_by_lastdigit keys %rev_trans) {
	  foreach my $host (sort keys %$hosts) {
	    if ($$hosts{$host} eq $rev_trans{$trans}) {
	      push @specs, $trans;
	      last;
	    }
	  }
	}
      } elsif (exists $translation{$spec_id}{HOST}) {
	foreach my $trans (sort rev_trans_by_lastdigit keys %rev_trans) {
	  if (exists $$orig_hosts{$trans}) {
	    foreach my $host (sort keys %$hosts) {
	      if ($host eq $rev_trans{$trans}) {
		push @specs, $$orig_hosts{$trans};
		last;
	      }
	    }
	  } else {
	    warn "oneSIS: Warning: Could not determine IP address of $trans\n";
	  }
	}
      } else {
	foreach my $host (sort keys %$hosts) {
	  push @specs, $$hosts{$host};
	}
      }
    } elsif ($format{$spec_id} eq 'ipaddr+') {
      my $all_ips = '';
      if (exists $translation{$spec_id}{IP}) {
	foreach my $trans (sort rev_trans_by_lastdigit keys %rev_trans) {
	  foreach my $host (sort keys %$hosts) {
	    if ($$hosts{$host} eq $rev_trans{$trans}) {
	      $all_ips .= " $trans";
	      last;
	    }
	  }
	}
      } else {
	foreach my $host (sort keys %$hosts) {
	  $all_ips .= " $$hosts{$host}";
	}
      }
      push @specs, $all_ips;
    }

    # Apply any SPEC translations to each formatted spec
    foreach my $spec (@specs) {
      if (exists $translation{$spec_id}{SPEC}) {
	# Apply the translation to the formatted spec
	$spec =~ s/$trans_left{$spec_id}{SPEC}/$trans_right{$spec_id}{SPEC}/ee;
      }
      push @nodespecs, $spec;
    }

    # Build actual node command with the given nodespec format
  SPEC: foreach my $spec (sort by_lastdigit @nodespecs) {
      my $mycmd = $cmd;
      $mycmd =~ s/SPEC:$spec_id/$spec/;

      # Find original hostname/ipaddr for $NODE/$IP interpolation
      my ($hostname, $ip) = ('','');
      my $host_exists = 0;
      if ($mycmd =~ /\$NODE|\$IP/) {
	if ($format{$spec_id} eq 'hostname') {
	  my $transhost = $spec;
	  if (exists $translation{$spec_id}{HOST}) {
	    if (exists $rev_trans{$transhost}) {
	      $hostname = $rev_trans{$transhost};
	    }
	  }
	  else {
	    $hostname = $transhost;
	  }
	  $ip = $$orig_hosts{$hostname};
	  $host_exists = 1;
	}
	elsif ($format{$spec_id} eq 'ipaddr') {
	  my $transip = $spec;
	  $hostname = '';
	  foreach my $host (keys %$hosts) {
	    if (exists $translation{$spec_id}{HOST}) {
	      if (exists $trans{$host}) {
		if ($transip eq $$orig_hosts{$trans{$host}}) {
		  $hostname = $host;
		  $ip = $$orig_hosts{$hostname};
		  $host_exists = 1;
		  last;
		}
	      }
	    }
	    elsif (exists $translation{$spec_id}{IP}) {
	      if (exists $rev_trans{$transip}) {
		$ip = $rev_trans{$transip};
		foreach my $host (keys %$hosts) {
		  if ($ip eq $$orig_hosts{$host}) {
		    $hostname = $host;
		    $host_exists = 1;
		    last;
		  }
		}
	      }
	    }
	  }
	}
	else {
	  $quiet || warn "oneSIS: Warning! Cannot interpolate \$NODE or \$IP for format: $format{$spec_id}\n";
	  if (defined $function) {
	    warn  "*  *  * NODECMD '$cmd_name' function '$function'\n";
	  }
	  else {
	    warn  "*  *  * NODECMD '$cmd_name'\n";
	  }
	  next SPEC;
	}

	# Interpolate/Substitute original hostname/ip
	$mycmd =~ s/\$NODE/$hostname/g;
	$mycmd =~ s/\$IP/$ip/g;
      }
      # Add cmd to list to be executed
      push @nodecmds, $mycmd;
    }
  }
  return \@nodecmds;

  # Sort routines used in this function
  sub by_lastdigit {
    # Desc: Sort routine to sort hostnames by their trailing digits
    # Input: 1) $a -- implicit sort() argument
    #        2) $b -- implicit sort() argument
    my ($digit_a, $digit_b);
    $a =~ /(\d+)$/ ? $digit_a = $1 : return 0;
    $b =~ /(\d+)$/ ? $digit_b = $1 : return 0;

    if ($digit_a == $digit_b) {
      return 0;
    }
    if ($digit_a > $digit_b) {
      return 1;
    }
    if ($digit_a < $digit_b) {
      return -1;
    }
  }

  sub rev_trans_by_lastdigit {
    # Desc: Sort routine to sort hostnames by their trailing digits
    # Input: 1) $a -- implicit sort() argument
    #        2) $b -- implicit sort() argument
    my ($digit_a, $digit_b);
    $rev_trans{$a} =~ /(\d+)$/ ? $digit_a = $1 : return 0;
    $rev_trans{$b} =~ /(\d+)$/ ? $digit_b = $1 : return 0;
    if ($digit_a == $digit_b) {
      return 0;
    }
    if ($digit_a > $digit_b) {
      return 1;
    }
    if ($digit_a < $digit_b) {
      return -1;
    }
  }
}

# cmdbuilder->get_basic_range_specs() method
sub get_basic_range_specs {
# Desc: Builds a node specification for basic_range specformats
#       The node spec is of the form: (prefix[n-m], where n<m)
# Input: 1) \@  I   array of hostnames/translations
#        2) $?  I   multi-spec flag: 0 = one spec per line
#                                    1 = multiple specs per line
# Returns: \@ node specifications
#          undef: on error
  my $self = shift;
  my ($hosts,$multi) = @_;
  if (!defined $multi) {
    $multi = 0;
  }
  my (%prefixhost, %rangespec);
  my @nodespecs;
  my $full_rangespec = '';

  # Build a hash of the prefix (up to the last digits) of each hostname
  foreach my $host (@$hosts) {
    if ($host =~ /^(.*?)\d+$/) {
      my ($prefix) = $1;
      push @{$prefixhost{$prefix}}, $host;
    }
    else {
      if ($multi) {
	$full_rangespec .= " $host";
      }
      else {
	push @nodespecs, $host;
      }
    }
  }

  # Build a range spec from the last digits of each host prefix
  foreach my $prefix (sort keys %prefixhost) {
    $rangespec{$prefix} = undef;
    my $idx = 0;
    foreach my $host (sort by_lastdigit @{$prefixhost{$prefix}}) {
      $host =~ /(\d+)$/;
      my $digit = $1;
      if (!defined $rangespec{$prefix}[$idx]) {
	$rangespec{$prefix}[$idx] = $digit;
      }
      else {
	$rangespec{$prefix}[$idx] =~ /(.*?)((-)?(\d+))$/;
	my ($head,$tail,$isrange,$lastdigit) = ($1,$2,$3,$4);
	if ($digit == $lastdigit + 1) {
	  if (defined $isrange) {
	    $rangespec{$prefix}[$idx] = "$head-$digit";
	  }
	  else {
	    $rangespec{$prefix}[$idx] = "$lastdigit-$digit";
	  }
	}
	else {
	  $idx++;
	  $rangespec{$prefix}[$idx] = "$digit";
	}
      }
    }
  }

  # Build complete range specification from each prefix/rangespec pair
  foreach my $prefix (sort keys %rangespec) {
    foreach my $spec (@{$rangespec{$prefix}}) {
      if ($multi) {
	$full_rangespec .= " $prefix\[$spec\]";
      }
      else {
	push @nodespecs, "$prefix\[$spec\]";
      }
    }
  }
  if ($multi) {
    push @nodespecs, $full_rangespec;
  }
  return \@nodespecs;
}

# cmdbuilder->get_ext_range_specs() method
sub get_ext_range_specs {
# Desc: Builds a node specification for ext_range specformats
#       The node spec is of the form: (prefix[n-m,l-k,...], where n<m and l<k)
# Input: 1) \@  I   array of hostnames/translations
#        2) $?  I   multi-spec flag: 0 = one spec per line
#                                    1 = multiple specs per line
# Returns: \@ node specifications
#          undef: on error
  my $self;

  # Allow this method to be called directly
  if (UNIVERSAL::isa($_[0], "oneSIS::cmdbuilder")) {
    $self = shift;
  }
  my ($hosts,$multi) = @_;

  if (!defined $multi) {
    $multi = 0;
  }
  my (%prefixhost, %rangespec);
  my @nodespecs;
  my $full_rangespec = '';

  # Build a hash of the prefix (up to the last digits) of each hostname
  foreach my $host (@$hosts) {
    if ($host =~ /^(.*?)\d+$/) {
      my ($prefix) = $1;
      push @{$prefixhost{$prefix}}, $host;
    }
    else {
      if ($multi) {
	$full_rangespec .= " $host";
      }
      else {
	push @nodespecs, $host;
      }
    }
  }

  # Build a range spec from the last digits of each host prefix
  foreach my $prefix (sort keys %prefixhost) {
    $rangespec{$prefix} = undef;
    foreach my $host (sort by_lastdigit @{$prefixhost{$prefix}}) {
      $host =~ /(\d+)$/;
      my $digit = $1;
      if (!defined $rangespec{$prefix}) {
	$rangespec{$prefix} = $digit;
      }
      else {
	$rangespec{$prefix} =~ /(.*?)((-)?(\d+))$/;
	my ($head,$tail,$isrange,$lastdigit) = ($1,$2,$3,$4);
	if ($digit == $lastdigit + 1) {
	  if (defined $isrange) {
	    $rangespec{$prefix} = "$head-$digit";
	  }
	  else {
	    $rangespec{$prefix} = $head . "$lastdigit-$digit";
	  }
	}
	else {
	  $rangespec{$prefix} = $head . $tail . ",$digit";
	}
      }
    }
  }

  # Build complete range specification from each prefix/rangespec pair
  foreach my $prefix (sort keys %rangespec) {
    if ($multi) {
      $full_rangespec .= " $prefix\[$rangespec{$prefix}\]";
    }
    else {
      push @nodespecs, "$prefix\[$rangespec{$prefix}\]";
    }
  }
  if ($multi) {
    push @nodespecs, $full_rangespec;
  }
  return \@nodespecs;
}


#-------- powercmd Object --------#

package oneSIS::powercmd;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &function
	     &cmd
	     &modifier
	     );

sub new {
# Desc: powercmd object constructor
# Input: 1) $  I   function (ON|OFF|CYCLE|STATUS|LED(ON|OFF|STATUS))
#        2) $  I   command/arguments (any valid bash command(s))
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 1) {
      return undef;
    }
    my ($function, $cmd) = @_;

    $self->function($function);
    $self->cmd($cmd);
    $self->{MODIFIER} = new oneSIS::modifier();

    return $self;
}

# powercmd->function() method
sub function {
# Desc: Gets or sets powercmd function
# Input: 1) $  I?  Optional function (ON|OFF|CYCLE|STATUS|LED(ON|OFF|STATUS)).
#                  The data is set to the value of the argument, if given.
# Returns: $ function
#          undef: on error
    my $self = shift;
    if (@_) {
      my $function = shift;
      if ($function !~ /^(ON|OFF|CYCLE|STATUS|LED(ON|OFF|STATUS))$/) {
	warn "oneSIS: Error! Invalid POWERCMD function: $function\n";
	return undef;
      }
      $self->{FUNCTION} = $function;
    }
    return $self->{FUNCTION};
}

# powercmd->cmd() method
sub cmd {
# Desc: Gets or sets powercmd command
# Input: 1) $  I?  Optional command/arguments (any valid bash command(s)).
#                  The data is set to the value of the argument, if given.
# Returns: $ command string
    my $self = shift;
    if (@_) { $self->{CMD} = shift; }
    return $self->{CMD};
}

# powercmd->modifier() method
sub modifier {
# Desc: Returns the modifier object contained in this object
# Input: None
# Returns: $ oneSIS::modifier object
#          undef: on error
    my $self = shift;
    if ($#_ == -1) {
      return $self->{MODIFIER};
    }
    else {
      return undef;
    }
}

#-------- consolecmd Object --------#

package oneSIS::consolecmd;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &cmd
	     &modifier
	     );

sub new {
# Desc: consolecmd object constructor
# Input: 1) $  I   command/arguments (any valid bash command(s))
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 0) {
      return undef;
    }
    my ($cmd) = @_;

    $self->cmd($cmd);
    $self->{MODIFIER} = new oneSIS::modifier();

    return $self;
}

# consolecmd->cmd() method
sub cmd {
# Desc: Gets or sets consolecmd command
# Input: 1) $  I?  Optional command/arguments (any valid bash command(s)).
#                  The data is set to the value of the argument, if given.
# Returns: $ command string
    my $self = shift;
    if (@_) { $self->{CMD} = shift; }
    return $self->{CMD};
}

# consolecmd->modifier() method
sub modifier {
# Desc: Returns the modifier object contained in this object
# Input: None
# Returns: $ oneSIS::modifier object
#          undef: on error
    my $self = shift;
    if ($#_ == -1) {
      return $self->{MODIFIER};
    }
    else {
      return undef;
    }
}

#-------- config Object --------#

package oneSIS::config;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &distro_name
             &distro_version
             &skippatch
             &keepnet
	     &add_class
	     &get_class
             &class_exists
             &parents_of
             &get_all_classdefs
	     &add_property
             &get_property
             &get_all_properties
	     &add_service
             &get_all_services
	     &service_exists
	     &service_enabled
	     &add_ramdisk
	     &get_all_ramdisks
	     &add_ramdisk_elem
	     &get_all_ramdisk_elems
	     &ramdisk_elem_exists
	     &add_disk
	     &get_all_disks
	     &add_localdisk_elem
	     &get_all_localdisk_elems
	     &add_deploydisk_elem
	     &get_all_deploydisk_elems
	     &add_bootloader
	     &get_all_bootloaders
	     &add_syncdir
	     &get_all_syncdirs
	     &add_excludesync
	     &get_all_excludesyncs
	     &add_excludedeploy
	     &get_all_excludedeploys
             &add_mac_addr
             &get_all_mac_addrs
             &get_hostname_from_mac_addr
             &add_specformat
             &get_specformat
             &add_eth_preload
             &get_all_eth_preloads
             &match_dns_hosts
             &add_directive
             &get_all_directives
             &using_directive
	     );

sub new {
# Desc: config object constructor
# Input: None
# Returns: $ blessed object, empty
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != -1) {
      return undef;
    }

    $self->{DISTRO_NAME} = undef;
    $self->{DISTRO_VERSION} = undef;
    $self->{SKIPPATCH} = 0;
    $self->{KEEPNET} = 0;
    $self->{CLASSDEFS} = [];
    $self->{CLASSES} = {};
    $self->{PROPERTIES} = {};
    $self->{SERVICES} = [];
    $self->{RAMDISK_ELEMS} = [];
    $self->{BOOTLOADERS} = [];
    $self->{DISKS} = {};
    $self->{LOCALDISK_ELEMS} = [];
    $self->{DEPLOYDISK_ELEMS} = [];
    $self->{SYNCDIRS} = [];
    $self->{EXCLUDESYNCS} = [];
    $self->{EXCLUDEDEPLOYS} = [];
    $self->{RAMDISKS} = [];
    $self->{MAC_HOST_MAP} = {};
    $self->{SPECFORMAT} = {};
    $self->{NODECMDS} = [];
    $self->{ETH_PRELOADS} = [];
    $self->{MATCH_DNS_HOSTS} = 0;
    $self->{DIRECTIVES} = [];

    return $self;
}

# config->distro_name() method
sub distro_name {
# Desc: Gets or sets the distribution name
# Input: 1) $  I?  Optional distro name (RedHat,Debian,SuSe,Fedora, etc).
#                  The data is set to the value of the argument, if given.
# Returns: $ distro name
    my $self = shift;
    if (@_) { $self->{DISTRO_NAME} = shift; }
    return $self->{DISTRO_NAME};
}

# config->distro_version() method
sub distro_version {
# Desc: Gets or sets the version of the distribution
# Input: 1) $  I?  Optional distro version (9.0, 8.2, EL-AS4, etc).
#                  The data is set to the value of the argument, if given.
# Returns: $ distro version
    my $self = shift;
    if (@_) { $self->{DISTRO_VERSION} = shift; }
    return $self->{DISTRO_VERSION};
}

# config->skippatch() method
sub skippatch {
# Desc: Gets or sets the flag specifying whether to skip the distro patch
# Input: 1) $  I?  0: Use a distro patch
#                  1: Skip applying a distro patch (in mk-sysimage)
#                  The data is set to the value of the argument, if given.
# Returns: $ usepatch flag
    my $self = shift;
    if (@_) { $self->{SKIPPATCH} = shift; }
    return $self->{SKIPPATCH};
}

# config->keepnet() method
sub keepnet {
# Desc: Gets or sets the flag specifying whether to keep network config files
#       when running mk-sysimage
# Input: 1) $  I?  0: Do no keep network configs
#                  1: Keep network configs when running mk-sysimage
#                  The data is set to the value of the argument, if given.
# Returns: $ usepatch flag
    my $self = shift;
    if (@_) { $self->{KEEPNET} = shift; }
    return $self->{KEEPNET};
}

# config->add_class() method
sub add_class {
# Desc: Adds a class to the configuration
# Input: 1) $  I   class name
#        2) $  I   description -- can be regexp string, range spec, or hostname
#        3) $  I   type -- can be one of 'REGEXP', 'MAP', or 'RANGE'
# Returns: $ oneSIS::classdef object
#          undef: on error
    my $self = shift;

    if ($#_ != 2) {
      return undef;
    }
    my ($name, $desc, $type) = @_;
    my ($class) = (undef);

    # Check for valid class name
    if ($name =~ /\.\./) {
      warn "oneSIS: Error! Invalid classname: $name\n";
      return undef;
    }

    # Check for subclass definition
    if ($name =~ /^([^.]+)\.(.*)/) {
      # Classdef contains subclasses
      my ($classname, $subnames) = ($1, $2);

      # Add class if it doesn't exist
      if (exists $self->{CLASSES}{$classname}) {
	$class = $self->{CLASSES}{$classname};
      }
      else {
	$class = new oneSIS::class($classname);
	$self->{CLASSES}{$classname} = $class;
      }

      # Iterate through subclasses
      my $prevclass = $class;
      my $subname = $subnames;
      while ($subname =~ /^([^.]+)\.?(.*)/g) {
	my ($classname) = $1;
	$subname = $2;

	# Add sub-classes if they don't exist
	my $subclass = undef;
	if (! defined ($subclass = $prevclass->get_subclass($classname))) {
	  $subclass = $prevclass->add_subclass($classname);
	}
	$prevclass = $subclass;
      }
    }
    else {  # Classdef doesn't contain subclasses

      # Add class if it doesn't exist
      unless (exists $self->{CLASSES}{$name}) {
	$self->{CLASSES}{$name} = new oneSIS::class($name);
      }
    }

    # Add new classdef
    my $classdef = new oneSIS::classdef($name, $desc, $type);
    if (!defined $classdef) {
      return undef;
    }

    push @{$self->{CLASSDEFS}}, $classdef;
    return $classdef;
}

# config->get_class() method
sub get_class {
# Desc: Gets class with the given name
# Input: 1) $  I   class name
# Returns: $ oneSIS::class object
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($name) = @_;
    if (!defined $name) {
      return undef;
    }
    my ($class);

    # Check for subclass definition
    if ($name =~ /^([^.]+)\.(.+)/) {
      # Classdef contains subclasses
      my ($classname, $subnames) = ($1, $2);

      # Check for top level class
      if (! exists $self->{CLASSES}{$classname}) {
	return undef;
      }

      $class = $self->{CLASSES}{$classname};

      # Iterate through subclasses
      my $subname = $subnames;
      while ($subname =~ /^([^.]+)\.?(.*)/g) {
	my ($classname) = $1;
	$subname = $2;

	# Check for existance of sub-classes
	my $subclass = undef;
	if (! defined ($subclass = $class->get_subclass($classname))) {
	  return undef;
	}
	$class = $subclass;
      }
      return $class;
    }
    else {  # Classdef doesn't contain subclasses
      # Check for top level class
      if (! exists $self->{CLASSES}{$name}) {
	return undef;
      }
      else {
	return $self->{CLASSES}{$name};
      }
    }
}

# config->class_exists() method
sub class_exists {
# Desc: Checks if given class exists in the configuration
# Input: 1) $  I   class name
# Returns: 0: if class doesn't exists
#          1: if class exists
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($name) = @_;

    # Check for top level class
    if (defined $self->get_class($name)) {
      return 1;
    }
    return 0;
}

# config->parents_of() method
sub parents_of {
# Desc: Return an array of the parents of a class
# Input: 1) $  I   full class name
# Returns: \@ parents of the class ordered from the top down
    my $self = shift;
    if ($#_ != 0) {
      return [];
    }
    my ($classname) = @_;
    if (!defined $classname) {
      return [];
    }
    my ($class, @parents, @parents_full);

    if ($classname eq 'default') {
      return [];
    }

    if (! defined ($class = $self->get_class($classname))) {
      return [];
    }

    while (defined ($class = $class->parent())) {
      push @parents, $class->name();
    }

    @parents = reverse(@parents);

    my $classname_full = undef;
    foreach my $parent (@parents) {
      if (defined $classname_full) {
	$classname_full .= '.';
      }
      $classname_full .= $parent;
      push @parents_full, $classname_full;
    }

    return \@parents_full;
}

# config->get_all_classdefs() method
sub get_all_classdefs {
# Desc: Gets all defined classdefs in the configuration
# Input: None
# Returns: \@ array of oneSIS::classdef objects in order of appearance
    my $self = shift;

    return \@{$self->{CLASSDEFS}};
}

# config->add_property() method
sub add_property {
# Desc: Adds a property to the configuration
# Input: 1) $  I   property name
# Returns: $ oneSIS::property object
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($propname) = @_;
    my ($property) = (undef);

    # Check for valid property name
    if ($propname =~ /\.\./) {
      warn "oneSIS: Error! Invalid property name: $propname\n";
      return undef;
    }

    # Add property if it doesn't exist
    if (exists $self->{PROPERTIES}{$propname}) {
      return undef;
    }
    else {
      $property = new oneSIS::property($propname);
      $self->{PROPERTIES}{$propname} = $property;
    }

    return $property;
}

# config->get_property() method
sub get_property {
# Desc: Gets property with the given name
# Input: 1) $  I   property name
# Returns: $ oneSIS::property object
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($propname) = @_;
    if (!defined $propname) {
      return undef;
    }
    my ($property);

    # Check for property
    if (! exists $self->{PROPERTIES}{$propname}) {
      return undef;
    }

    $property = $self->{PROPERTIES}{$propname};
    return $property;
}

# config->get_all_properties() method
sub get_all_properties {
# Desc: Gets all defined properties in the configuration
# Input: None
# Returns: \@ array of property names
    my $self = shift;
    my @props = keys %{$self->{PROPERTIES}};
    return \@props;
}

# config->add_service() method
sub add_service {
# Desc: Adds a service to the configuration
# Input: 1) $  I   service name
# Returns: $ oneSIS::service object
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($name) = @_;
    my $service = undef;
    $service = new oneSIS::service($name);
    if (!defined $service) {
      return undef;
    }
    else {
      # Create a ramdisk_elem for the service
      my $ramdisk_elem = $self->add_ramdisk_elem("/etc/init.d/$name",
						 'LINKBACK');
      $ramdisk_elem->hidden(1);
      $ramdisk_elem->linkback('SERVICE');
      $service->ramdisk_elem($ramdisk_elem);
      push @{$self->{SERVICES}}, $service;

      return $service;
    }
}

# config->get_all_services() method
sub get_all_services {
# Desc: Gets all defined services in the configuration
# Input: None
# Returns: \@ array of service objects in order of appearance in the config
    my $self = shift;

    return \@{$self->{SERVICES}};
}

# config->service_exists() method
sub service_exists {
# Desc: Checks if the given service exists in the configuration
# Input: 1) $  I   service name
# Returns: 0: if the service does not exist in the configuration
#          1: if the service does exist in the configuration
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($service_name) = @_;

    # Check if service is in the config
    foreach my $service (@{$self->{SERVICES}}) {
      if ($service->name() eq $service_name) {
	return 1;
      }
    }
    return 0;
}

# config->service_enabled() method
sub service_enabled {
# Desc: Checks if the given service exists in the configuration and is
#       enabled for the given node/class
# Input: 1) $  I   service name
#        2) $  I   hostname of node
#        3) $  I   class of node
# Returns: 0: if the service is not enabled for the given node/class
#          1: if the service is enabled for the given node/class
#         -1: if the service does not exist in the config
#          undef: on error
    my $self = shift;

    if ($#_ != 2) {
      return undef;
    }
    my ($service_name, $hostname, $classname) = @_;

    # Check if service enabled for the given node/class in the config
    my $enabled = 0;
    my $found_service = 0;
  SERVICE: foreach my $serviceObj (@{$self->{SERVICES}}) {
      if ($serviceObj->name() eq $service_name) {
	$found_service = 1;
	my $ramdisk_elem = $serviceObj->ramdisk_elem();
	$enabled = $self->using_directive($ramdisk_elem->modifier(),
					  $hostname, $classname);
      }
    }
    return - 1 unless $found_service;
    return $enabled;
}

# config->add_ramdisk_elem() method
sub add_ramdisk_elem {
# Desc: Adds a ramdisk_elem to the configuration
# Input: 1) $  I   ramdisk_elem full pathname
#        2) $  I   type of directive  =~ RAM(FILE|DIR)|LINK(FILE|DIR|BACK)
# Returns: $ oneSIS::ramdisk_elem object
#          undef: on error
    my $self = shift;

    if ($#_ != 1) {
      return undef;
    }
    my ($path, $type) = @_;
    my $ramdisk_elem = undef;

    # Don't allow globbing of LINKBACK directives
    if ($path =~ /\*|\[|\{|\?/) {
      if ($type eq 'LINKBACK') {
	warn "oneSIS: Warning! Globbing not allowed for LINKBACK directives.\n";
	return undef;
      }
    }

    $ramdisk_elem = new oneSIS::ramdisk_elem($path, $type);
    if (!defined $ramdisk_elem) {
      return undef;
    }
    else {
      push @{$self->{RAMDISK_ELEMS}}, $ramdisk_elem;
      return $ramdisk_elem;
    }
}

# config->get_all_ramdisk_elems() method
sub get_all_ramdisk_elems {
# Desc: Gets all defined ramdisk_elems in the configuration
# Input: None
# Returns: \@ array of ramdisk_elem objects ordered by appearance in the config
    my $self = shift;

    return \@{$self->{RAMDISK_ELEMS}};
}

# config->ramdisk_elem_exists() method
sub ramdisk_elem_exists {
# Desc: Checks if the given pathname exists in the configuration and
#       optionally whether the path is a link to /ram
# Input: 1) $  I   full pathname
#        2) $  I   base directory
#        3) $  I?  optional flag to check whether pathname is a LINK*
#        4) $  I?  optional hostname: check whether the pathname element
#                  exists for the hostname.  Requires option #5
#        5) $  I?  optional classname: check whether the pathname element
#                  exists for the classname.  Requires option #5
# Returns: 0: if the config does not contain an element with the given pathname
#          1: if the config does contain an element with the given pathname
#          undef: on error
    my $self = shift;
    unless ($#_ >= 1 && $#_ <= 4) {
      return undef;
    }
    my ($pathname, $basedir, $checklink, $hostname, $classname) = @_;
    my $check_node_class = 0;
    if (!defined $checklink) {
      $checklink = 0;
    }
    if (defined $hostname && defined $classname) {
      $check_node_class = 1;
    }

    # Remove any redundant/trailing /'s
    $pathname =~ s|/+|/|g;
    $pathname =~ s/^(.*)\/+$/$1/;

    # Check if pathname is in config
  PATHNAME: foreach my $elem (@{$self->{RAMDISK_ELEMS}}) {
      if ($check_node_class) {
	unless ($self->using_directive($elem->modifier(),
				       $hostname, $classname)) {
	  next PATHNAME;
	}
      }
      my $elem_path = $elem->file_elem()->path();
      my $glob_list;
      $$glob_list[0] = $elem_path;
      # Check all file globs if specified
      if ($elem_path =~ /\*|\[|\{|\?/) {
	$glob_list = oneSIS::file_globs($elem_path, $basedir);
      }
      foreach my $path (@$glob_list) {
	if ($checklink) {
	  next unless $elem->type() =~ /^LINK/;
	}
	if ($path eq $pathname) {
	  return 1;
	}
      }
    }

    return 0;
}

# config->add_disk() method
sub add_disk {
# Desc: Adds a disk to the configuration
# Input: 1) $  I   disk identifier (number, device)
# Returns: $ oneSIS::disk object
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($identifier) = @_;
    my $diskObj = undef;

    $diskObj = new oneSIS::disk($identifier);
    if (!defined $diskObj) {
      return undef;
    }
    else {
      $self->{DISKS}{$identifier} = $diskObj;
      return $diskObj;
    }
}

# config->get_all_disks() method
sub get_all_disks {
# Desc: Gets all defined disks in the configuration
# Input: None
# Returns: \% hash of oneSIS::disk objects
    my $self = shift;
    return \%{$self->{DISKS}};
}

# config->add_bootloader() method
sub add_bootloader {
# Desc: Adds a bootloader to the configuration
# Input: 1) $  I   bootloader name
# Returns: $ oneSIS::bootloader object
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($bloader) = @_;
    my $bloaderObj = undef;

    $bloaderObj = new oneSIS::bootloader($bloader);
    if (!defined $bloaderObj) {
      return undef;
    }
    else {
      push @{$self->{BOOTLOADERS}}, $bloaderObj;
      return $bloaderObj;
    }
}

# config->get_all_bootloaders() method
sub get_all_bootloaders {
# Desc: Gets all defined bootloaders in the configuration
# Input: None
# Returns: \@ array of bootloader objects in order of appearance in the config
    my $self = shift;
    return \@{$self->{BOOTLOADERS}};
}

# config->add_syncdir() method
sub add_syncdir {
# Desc: Adds a syncdir to the configuration
# Input: 1) $  I   syncdir path
# Returns: $ oneSIS::path object
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($syncdir) = @_;
    my $pathObj = undef;

    $pathObj = new oneSIS::path($syncdir);
    if (!defined $pathObj) {
      return undef;
    }
    else {
      push @{$self->{SYNCDIRS}}, $pathObj;
      return $pathObj;
    }
}

# config->get_all_syncdirs() method
sub get_all_syncdirs {
# Desc: Gets all defined syncdirs in the configuration
# Input: None
# Returns: \@ array of oneSIS::path objects in order of appearance in config
    my $self = shift;
    return \@{$self->{SYNCDIRS}};
}

# config->add_excludesync() method
sub add_excludesync {
# Desc: Adds an excludesync to the configuration
# Input: 1) $  I   excludesync path
# Returns: $ oneSIS::path object
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($excludesync) = @_;
    my $pathObj = undef;

    $pathObj = new oneSIS::path($excludesync);
    if (!defined $pathObj) {
      return undef;
    }
    else {
      push @{$self->{EXCLUDESYNCS}}, $pathObj;
      return $pathObj;
    }
}

# config->get_all_excludesyncs() method
sub get_all_excludesyncs {
# Desc: Gets all defined excludesyncs in the configuration
# Input: None
# Returns: \@ array of oneSIS::path objects in order of appearance in config
    my $self = shift;
    return \@{$self->{EXCLUDESYNCS}};
}

# config->add_excludedeploy() method
sub add_excludedeploy {
# Desc: Adds an excludedeploy to the configuration
# Input: 1) $  I   excludedeploy path
# Returns: $ oneSIS::path object
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($excludedeploy) = @_;
    my $pathObj = undef;

    $pathObj = new oneSIS::path($excludedeploy);
    if (!defined $pathObj) {
      return undef;
    }
    else {
      push @{$self->{EXCLUDEDEPLOYS}}, $pathObj;
      return $pathObj;
    }
}

# config->get_all_excludedeploys() method
sub get_all_excludedeploys {
# Desc: Gets all defined excludedeploys in the configuration
# Input: None
# Returns: \@ array of oneSIS::path objects in order of appearance in config
    my $self = shift;
    return \@{$self->{EXCLUDEDEPLOYS}};
}

# config->add_localdisk_elem() method
sub add_localdisk_elem {
# Desc: Adds a localdisk_elem to the configuration
# Input: 1) \@ I   array of localdisk identifiers (number, device)
#        2) $  I   type of partition (SWAP,MOUNT)
#        3) $  I   size of partition
#        4) $  I   mount point of partition (only for MOUNT type)
# Returns: $ oneSIS::localdisk_elem object
#          undef: on error
  my $self = shift;

  if ($#_ != 2 && $#_ != 3) {
    return undef;
  }
  my ($disks, $type, $size, $mountpoint) = @_;
  my ($diskObj, $localdisk_elem) = (undef,undef);
  my $all_diskObjs = $self->get_all_disks();
  my @diskObjs;

  for my $disk (@$disks) {
    $disk =~ s|/dev/||;
    # Get an existing disk object or add a new one
    if (exists ($$all_diskObjs{$disk})) {
      $diskObj = $$all_diskObjs{$disk};
    }
    else {
      $diskObj = $self->add_disk($disk);
      if (!defined $diskObj) {
	return undef;
      }
    }
    push @diskObjs, $diskObj;
  }

  $localdisk_elem = new oneSIS::localdisk_elem(\@diskObjs, $type, $size, $mountpoint);
  if (!defined $localdisk_elem) {
    return undef;
  }

  push @{$self->{LOCALDISK_ELEMS}}, $localdisk_elem;
  return $localdisk_elem;
}

# config->get_all_localdisk_elems() method
sub get_all_localdisk_elems {
# Desc: Gets all defined localdisk_elems in the configuration
# Input: None
# Returns: \@ array of localdisk_elem objects in order of appearance in the config
    my $self = shift;

    return \@{$self->{LOCALDISK_ELEMS}};
}


# config->add_deploydisk_elem() method
sub add_deploydisk_elem {
# Desc: Adds a deploydisk_elem to the configuration
# Input: 1) \@ I   array of deploydisk identifiers (number, device)
#        2) $  I   type of partition (SWAP,MOUNT)
#        3) $  I   size of partition
#        4) $? I   mount point of partition (only for MOUNT type)
# Returns: $ oneSIS::localdisk_elem object
#          undef: on error
  my $self = shift;

  if ($#_ != 2 && $#_ != 3) {
    return undef;
  }
  my ($disks, $type, $size, $mountpoint) = @_;
  my ($diskObj, $localdisk_elem) = (undef,undef);
  my $all_diskObjs = $self->get_all_disks();
  my @diskObjs;

  for my $disk (@$disks) {
    $disk =~ s|/dev/||;
    # Get an existing disk object or add a new one
    if (exists ($$all_diskObjs{$disk})) {
      $diskObj = $$all_diskObjs{$disk};
    }
    else {
      $diskObj = $self->add_disk($disk);
      if (!defined $diskObj) {
	return undef;
      }
    }
    push @diskObjs, $diskObj;
  }

  $localdisk_elem = new oneSIS::localdisk_elem(\@diskObjs, $type, $size, $mountpoint);
  if (!defined $localdisk_elem) {
    return undef;
  }

  push @{$self->{DEPLOYDISK_ELEMS}}, $localdisk_elem;
  return $localdisk_elem;
}

# config->get_all_deploydisk_elems() method
sub get_all_deploydisk_elems {
# Desc: Gets all defined deploydisk_elems in the configuration
# Input: None
# Returns: \@ array of localdisk_elem objects in order of appearance in the config
    my $self = shift;
    return \@{$self->{DEPLOYDISK_ELEMS}};
}

# config->add_ramdisk() method
sub add_ramdisk {
# Desc: Adds a ramdisk to the configuration
# Input: 1) $  I   ramdisk size
#        2) $  I   unit of size (K, M, G) kilo, mega, or giga bytes
# Returns: $ oneSIS::ramdisk object
#          undef: on error
    my $self = shift;

    if ($#_ != 1) {
      return undef;
    }
    my ($size, $unit) = @_;
    my $ramdisk = undef;
    $ramdisk = new oneSIS::ramdisk($size, $unit);
    if (!defined $ramdisk) {
      return undef;
    }
    else {
      push @{$self->{RAMDISKS}}, $ramdisk;
      return $ramdisk;
    }
}

# config->get_all_ramdisks() method
sub get_all_ramdisks {
# Desc: Gets all defined ramdisks in the configuration
# Input: None
# Returns: \@ array of ramdisk objects in order of appearance in the config
    my $self = shift;

    return \@{$self->{RAMDISKS}};
}

# config->add_mac_addr() method
sub add_mac_addr {
# Desc: Adds a MAC address mapping to the configuration
# Input: 1) $  I   host name
#        2) $  I   MAC address
# Returns: 0: on success
#          undef: on error
    my $self = shift;

    if ($#_ != 1) {
      return undef;
    }
    my ($hostname, $mac) = @_;

    if ($mac !~ /^(\w{1,2}[-:]){5}\w{1,2}$/) {
      return undef;
    }

    $mac = uc($mac);
    $mac =~ s/-/:/g;
    $self->{MAC_HOST_MAP}{$mac} = $hostname;
    return 0;
}

# config->get_all_mac_addrs() method
sub get_all_mac_addrs {
# Desc: Gets all MAC addersses defined in the configuration
# Input: None
# Returns: \@ array of mac addresses appearing in the config
#          undef: on error
    my $self = shift;

    if ($#_ != -1) {
      return undef;
    }

    my @macs = keys %{$self->{MAC_HOST_MAP}};

    return \@macs;
}

# config->get_hostname_from_mac_addr() method
sub get_hostname_from_mac_addr {
# Desc: Returns the a hostname associated with a MAC, if it exists
# Input: 1) $  I   MAC address
# Returns: $ host name
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($mac) = @_;

    if (exists $self->{MAC_HOST_MAP}{$mac}) {
      return $self->{MAC_HOST_MAP}{$mac};
    }
    return undef;
}

# config->add_nodecmd() method
sub add_nodecmd {
# Desc: Adds a NODECMD function command description to the configuration
# Input: 1) $  I   node command name
#        2) $  I   command/arguments (can be full pathname if desired)
# Returns: $ oneSIS::nodecmd object
#          undef: on error
    my $self = shift;

    if ($#_ != 1) {
      return undef;
    }
    my ($name, $cmd) = @_;
    my $nodecmd;

    $nodecmd = new oneSIS::nodecmd($name, $cmd);
    if (!defined $nodecmd) {
      return undef;
    }
    else {
      push @{$self->{NODECMDS}}, $nodecmd;
      return $nodecmd;
    }
}

# config->get_all_nodecmds() method
sub get_all_nodecmds {
# Desc: Gets all NODECMD function command descriptions in the configuration
# Input: None
# Returns: \@ array of oneSIS::nodecmd objects
#          undef: on error
    my $self = shift;

    if ($#_ != -1) {
      return undef;
    }

    return \@{$self->{NODECMDS}};
}

# config->add_specformat() method
sub add_specformat {
# Desc: Adds a POWERCMD nodespec format
# Input: 1) $  I   specformat spec_id
#        2) $  I   nodespec format (hostname,basic_range,ext_range, etc.)
# Returns: $ oneSIS::specformat object
#          undef: on error
  my $self = shift;
  if ($#_ != 1) {
    return undef;
  }
  my ($spec_id, $format) = @_;
  $format = lc($format);

  my $specformat = new oneSIS::specformat($format);
  if (!defined $specformat) {
    return undef;
  }

  $self->{SPECFORMAT}{$spec_id} = $specformat;

  return $specformat;
}

# config->get_specformat() method
sub get_specformat {
# Desc: Gets a specified POWERCMD nodespec format
# Input: 1) $  I   specformat spec_id
# Returns: $ oneSIS::specformat object
#          undef: on error
  my $self = shift;
  if ($#_ != 0) {
    return undef;
  }
  my ($spec_id) = @_;

  if (!exists $self->{SPECFORMAT}{$spec_id}) {
    return undef;
  }

  return $self->{SPECFORMAT}{$spec_id};
}

# config->add_eth_preload() method
sub add_eth_preload {
# Desc: Adds a driver from an ETH_PRELOAD directive to the configuration
# Input: 1) $  I   ethnernet driver name
# Returns: $ undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($driver) = @_;

    push @{$self->{ETH_PRELOADS}}, $driver;
}

# config->get_all_eth_preloads() method
sub get_all_eth_preloads {
# Desc: Gets all drivers specified in ETH_PRELOAD directives
#       in the configuration
# Input: None
# Returns: \@ array of driver names
#          undef: on error
    my $self = shift;

    if ($#_ != -1) {
      return undef;
    }

    return \@{$self->{ETH_PRELOADS}};
}

# config->match_dns_hosts() method
sub match_dns_hosts {
# Desc: Gets or sets whether or not oneSIS should try to match hosts from DNS in addition to /etc/hosts
# Input: 1) $  I?  Optional boolean (yes/no/1/0)
# Returns: $ undef: on error
    my $self = shift;

    if (@_) {
      my ($boolean) = shift;
      if ($boolean =~ /^yes$/i) {
	$boolean = 1;
      }
      elsif ($boolean =~ /^no$/i) {
	$boolean = 0;
      }
      elsif ($boolean != 0 && $boolean != 1) {
	return undef;
      }
      $self->{MATCH_DNS_HOSTS} = $boolean;
    }

    return $self->{MATCH_DNS_HOSTS};
}

# config->directive() method
sub add_directive {
# Desc: Adds a configuration directive to the configuration
# Input: 1) $  I   directive text
# Returns: $  directive text
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($directive) = @_;
    push @{$self->{DIRECTIVES}}, $directive;
    return $directive;
}

# config->get_all_directives() method
sub get_all_directives {
# Desc: Gets all valid directives in the configuration
# Input: None
# Returns: \@ array of directives in order of appearance in the config
    my $self = shift;

    return \@{$self->{DIRECTIVES}};
}

# config->using_directive() method
sub using_directive {
# Desc: Checks the modifier object of a directive against a given hostname
#       and classname to determine whether the directive should be used
# Input: 1) $  I   oneSIS::modifier object
#        2) $  I   hostname
#        3) $  I   classname
# Returns: 0: if the directive should NOT be used
#          1: if the directive should be used
#          undef: on error
    my $self = shift;
    if ($#_ < 2 || $#_ > 3) {
      return undef;
    }
    my ($modifier, $hostname, $classname) = @_;
    my $parents = [];
    my $using = 1;

    # Check for node specific directive
  MODIFIER_NODE: foreach my $node (@{$modifier->nodes()}) {
      if ($node =~ /^!/) {
	my $realnode = $node;
	$realnode =~ s/^!//;
	$using = 1;
	if ($realnode eq $hostname) {
	  $using = 0;
	  next MODIFIER_NODE;
	}
      }
      else {
	$using = 0;
	if ($node eq $hostname) {
	  $using = 1;
	  goto USING_DIRECTIVE_END;
	}
      }
    }
    
    # Check the current class and all parent classes
    $parents = $self->parents_of($classname);
  MODIFIER_CLASS: foreach my $class (@{$modifier->classes()}) {
      if ($class =~ /^!/) {
	# Check negated values from the top down
	my $realclass = $class;
	$realclass =~ s/^!//;
	foreach my $myclass (@$parents, $classname) {
	  $using = 1;
	  if ($realclass eq $myclass) {
	    $using = 0;
	    next MODIFIER_CLASS;
	  }
	}
      }
      else {
	# Check non-negated values from the bottom up down
	foreach my $myclass (reverse(@$parents, $classname)) {
	  $using = 0;
	  if ($class eq $myclass) {
	    $using = 1;
	    goto USING_DIRECTIVE_END;
	  }
	}
      }
    }

    # Check for property specific directive
  MODIFIER_PROPERTY: foreach my $prop (@{$modifier->properties()}) {
      if ($prop =~ /^!/) {
	my $realprop = $prop;
	$realprop =~ s/^!//;
	my $propObj = $self->get_property($realprop);
	next unless defined $propObj;
	$using = 1;
	if ($propObj->applies_to($self, $hostname)) {
	  $using = 0;
	  next MODIFIER_PROPERTY;
	}
      }
      else {
	my $propObj = $self->get_property($prop);
	next unless defined $propObj;
	$using = 0;
	if ($propObj->applies_to($self, $hostname)) {
	  $using = 1;
	  goto USING_DIRECTIVE_END;
	}
      }
    }

  USING_DIRECTIVE_END:
    return $using;
}

#-------- ramfs_copy Object --------#

package oneSIS::ramfs_copy;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
	     &path
	     &deplibs
	     &recurse
	     );

sub new {
# Desc: path object constructor
# Input: 1) $  I   path
# Returns: $ blessed object, partially populated
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != 0) {
      return undef;
    }
    my ($path) = @_;

    $self->{PATH} = $path;
    $self->{NODEPLIBS} = 0;
    $self->{RECURSE} = 0;

    return $self;
}

# ramfs_copy->path() method
sub path {
# Desc: Gets or sets path
# Input: 1) $  I?  Optional path.
#                  The data is set to the value of the argument, if given.
# Returns: $ path
    my $self = shift;
    if (@_) { $self->{PATH} = shift; }
    return $self->{PATH};
}

# ramfs_copy->nodeplibs() method
sub nodeplibs {
# Desc: Gets or sets the nodeplibs flag
# Input: 1) $  I?  Optional nodeplibs flag
# Returns: $ recurse flag
#          undef: on error
    my $self = shift;
    if (@_) { $self->{NODEPLIBS} = shift; }
    return $self->{NODEPLIBS};
}

# ramfs_copy->recurse() method
sub recurse {
# Desc: Gets or sets the recurse flag
# Input: 1) $  I?  Optional recurse flag
# Returns: $ recurse flag
#          undef: on error
    my $self = shift;
    if (@_) { $self->{RECURSE} = shift; }
    return $self->{RECURSE};
}

#-------- ramfs_config Object --------#

package oneSIS::ramfs_config;
use strict;

require Exporter;
@ISA= qw(Exporter);
@EXPORT = qw(&new
             &ramdisk_root
             &add_ramfs_copy
             &get_all_ramfs_copies
             &add_directive
             &get_all_directives
	     );

sub new {
# Desc: ramfs_config object constructor
# Input: None
# Returns: $ blessed object, empty
#          undef: on error
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $self = {};
    bless($self, $class);

    if ($#_ != -1) {
      return undef;
    }

    $self->{RAMDISK_ROOT} = 0;
    $self->{RAMFS_COPIES} = [];
    $self->{NODHCP} = 0;
    $self->{NONFS} = 0;
    $self->{INITRD} = 0;
    $self->{DHCP_RETRIES} = undef;
    $self->{NFS_RETRIES} = undef;
    $self->{BOND_INTERFACES} = undef;
    $self->{NETWORK_CHECK} = undef;
    $self->{INITRD_SIZE} = undef;
    $self->{INITRD_BUFFER} = undef;
    $self->{RESUME_FROM} = undef;
    $self->{TEMPLATE} = undef;
    $self->{AUTOMOUNT} = 0;
    $self->{SWAPON} = 0;
    $self->{MOUNT_RW_DIRS} = [];
    $self->{MOUNT_ALL_RW} = 0;
    $self->{NOMODPROBE} = 0;
    $self->{SCSIMODS} = 0;
    $self->{SETUP_RAID} = 0;
    $self->{PRELOADS} = [];
    $self->{MODULES} = [];
    $self->{OVERLAYS} = [];
    $self->{DIRECTIVES} = [];

    return $self;
}

# ramfs_config->ramdisk_root() method
sub ramdisk_root {
# Desc: Gets or sets the ramdisk_root flag
# Input: 1) $  I?  Optional path.
#                  The data is set to the value of the argument, if given.
# Returns: $ path
    my $self = shift;
    if (@_) { $self->{RAMDISK_ROOT} = shift; }
    return $self->{RAMDISK_ROOT};
}

# ramfs_config->add_ramfs_copy() method
sub add_ramfs_copy {
# Desc: Adds a path to copy to the ramfs
# Input: 1) $  I   pathname
# Returns: $ oneSIS::ramfs_copy object
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($path) = @_;
    my $ramfs_copy = new oneSIS::ramfs_copy($path);
    push @{$self->{RAMFS_COPIES}}, $ramfs_copy;
    return $ramfs_copy;
}

# ramfs_config->get_ramfs_copies() method
sub get_ramfs_copies {
# Desc: Gets all defined ramfs_copies in the configuration
# Input: None
# Returns: \@ array of oneSIS::ramfs_copy objects in order of appearance in the config
    my $self = shift;

    return \@{$self->{RAMFS_COPIES}};
}

# ramfs_config->add_dhcp_interface() method
sub add_dhcp_interface {
# Desc: Adds a dhcp interface to use in the ramfs
# Input: 1) $  I   interface name (eg: eth0)
# Returns: $ interface name
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($interface) = @_;
    my $seen = 0;
    map {$seen = 1 if $_ eq $interface} @{$self->{DHCP_IFS}};
    push @{$self->{DHCP_IFS}}, $interface unless $seen;
    return $interface;
}

# ramfs_config->get_dhcp_interfaces() method
sub get_dhcp_interfaces {
# Desc: Gets all defined dhcp interfaces in the configuration
# Input: None
# Returns: \@ array of dhcp interface names in order of appearance in the config
    my $self = shift;
    return \@{$self->{DHCP_IFS}};
}


# ramfs_config->initrd() method
sub initrd {
# Desc: Gets or sets the initrd flag
# Input: 1) $  I?  Optional initrd flag
#                  The data is set to the value of the argument, if given.
# Returns: $ initrd flag
    my $self = shift;
    if (@_) { $self->{INITRD} = shift; }
    return $self->{INITRD};
}

# ramfs_config->nodhcp() method
sub nodhcp {
# Desc: Gets or sets the nodhcp flag
# Input: 1) $  I?  Optional nodhcp flag
#                  The data is set to the value of the argument, if given.
# Returns: $ nodhcp flag
    my $self = shift;
    if (@_) { $self->{NODHCP} = shift; }
    return $self->{NODHCP};
}

# ramfs_config->nonfs() method
sub nonfs {
# Desc: Gets or sets the nonfs flag
# Input: 1) $  I?  Optional nonfs flag
#                  The data is set to the value of the argument, if given.
# Returns: $ nonfs flag
    my $self = shift;
    if (@_) { $self->{NONFS} = shift; }
    return $self->{NONFS};
}

# ramfs_config->dhcp_retries() method
sub dhcp_retries {
# Desc: Gets or sets the number of dhcp retries
# Input: 1) $  I?  Number of dhcp retries
#                  The data is set to the value of the argument, if given.
# Returns: $ number of dhcp retries
    my $self = shift;
    if (@_) { $self->{DHCP_RETRIES} = shift; }
    return $self->{DHCP_RETRIES};
}

# ramfs_config->nfs_retries() method
sub nfs_retries {
# Desc: Gets or sets the number of nfs retries
# Input: 1) $  I?  Number of nfs retries
#                  The data is set to the value of the argument, if given.
# Returns: $ number of nfs retries
    my $self = shift;
    if (@_) { $self->{NFS_RETRIES} = shift; }
    return $self->{NFS_RETRIES};
}

# ramfs_config->bond_interfaces() method
sub bond_interfaces {
# Desc: Gets or sets a bonded interface (only one bond allowed at the moment)
# Input: 1) $  I?  Space-seperated list of interface names to bond (eg: 'eth0 eth1')
#                  The data is set to the value of the argument, if given.
# Returns: $ bonded interface names
    my $self = shift;
    if (@_) { $self->{BOND_INTERFACES} = shift; }
    return $self->{BOND_INTERFACES};
}

# ramfs_config->network_check() method
sub network_check {
# Desc: Gets or sets the network_check flag
# Input: 1) $  I?  Optional network_check flag
#                  The data is set to the value of the argument, if given.
# Returns: $ network_check flag
    my $self = shift;
    if (@_) { $self->{NETWORK_CHECK} = shift; }
    return $self->{NETWORK_CHECK};
}

# ramfs_config->automount() method
sub automount {
# Desc: Gets or sets the automount flag
# Input: 1) $  I?  Optional automount flag
#                  The data is set to the value of the argument, if given.
# Returns: $ mountlabels flag
    my $self = shift;
    if (@_) { $self->{AUTOMOUNT} = shift; }
    return $self->{AUTOMOUNT};
}

# ramfs_config->swapon() method
sub swapon {
# Desc: Gets or sets the swapon flag
# Input: 1) $  I?  Optional swapon flag
#                  The data is set to the value of the argument, if given.
# Returns: $ swapon flag
    my $self = shift;
    if (@_) { $self->{SWAPON} = shift; }
    return $self->{SWAPON};
}

# ramfs_config->add_mount_rw() method
sub add_mount_rw_dir {
# Desc: Adds a directory to mount read-write in the ramfs
# Input: 1) $  I   directory
# Returns: $ directory
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($dir) = @_;
    push @{$self->{MOUNT_RW_DIRS}}, $dir;
    return $dir;
}

# ramfs_config->get_mount_rw_dirs() method
sub get_mount_rw_dirs {
# Desc: Gets all dirs configured to be mounted read-write in the ramfs
# Input: None
# Returns: \@ array of directory names
    my $self = shift;
    return \@{$self->{MOUNT_RW_DIRS}};
}

# ramfs_config->mount_all_rw() method
sub mount_all_rw {
# Desc: Gets or sets the mount_all_rw flag
# Input: 1) $  I?  Optional mount_all_rw flag
#                  The data is set to the value of the argument, if given.
# Returns: $ mount_all_rw flag
    my $self = shift;
    if (@_) { $self->{MOUNT_ALL_RW} = shift; }
    return $self->{MOUNT_ALL_RW};
}

# ramfs_config->nomodprobe() method
sub nomodprobe {
# Desc: Gets or sets the nomodprobe flag
# Input: 1) $  I?  Optional nomodprobe flag
#                  The data is set to the value of the argument, if given.
# Returns: $ nomodprobe flag
    my $self = shift;
    if (@_) { $self->{NOMODPROBE} = shift; }
    return $self->{NOMODPROBE};
}

# ramfs_config->pcimods() method
sub pcimods {
# Desc: Gets or sets the pcimods flag
# Input: 1) $  I?  Optional pcimods flag
#                  The data is set to the value of the argument, if given.
# Returns: $ pcimods flag
    my $self = shift;
    if (@_) { $self->{PCIMODS} = shift; }
    return $self->{PCIMODS};
}

# ramfs_config->scsimods() method
sub scsimods {
# Desc: Gets or sets the scsimods flag
# Input: 1) $  I?  Optional scsimods flag
#                  The data is set to the value of the argument, if given.
# Returns: $ scsimods flag
    my $self = shift;
    if (@_) { $self->{SCSIMODS} = shift; }
    return $self->{SCSIMODS};
}

# ramfs_config->initrd_size() method
sub initrd_size {
# Desc: Gets or sets the initrd size
# Input: 1) $  I?  Optional initrd size
#                  The data is set to the value of the argument, if given.
# Returns: $ initrd size
    my $self = shift;
    if (@_) { $self->{INITRD_SIZE} = shift; }
    return $self->{INITRD_SIZE};
}

# ramfs_config->initrd_buffer() method
sub initrd_buffer {
# Desc: Gets or sets the initrd buffer size
# Input: 1) $  I?  Optional initrd buffer size
#                  The data is set to the value of the argument, if given.
# Returns: $ initrd buffer size
    my $self = shift;
    if (@_) { $self->{INITRD_BUFFER} = shift; }
    return $self->{INITRD_BUFFER};
}

# ramfs_config->setup_raid() method
sub setup_raid {
# Desc: Gets or sets the setup_raid flag
# Input: 1) $  I?  Optional setup_raid flag
#                  The data is set to the value of the argument, if given.
# Returns: $ setup_raid flag
    my $self = shift;
    if (@_) { $self->{SETUP_RAID} = shift; }
    return $self->{SETUP_RAID};
}

# ramfs_config->resume_from() method
sub resume_from {
# Desc: Gets or sets the resume device
# Input: 1) $  I?  Optional resume device name (with or without /dev)
#                  The data is set to the value of the argument, if given.
# Returns: $ resume device name
    my $self = shift;
    if (@_) { $self->{RESUME_FROM} = shift; }
    return $self->{RESUME_FROM};
}

# ramfs_config->template() method
sub template {
# Desc: Gets or sets the template to use
# Input: 1) $  I?  Optional template path
#                  The data is set to the value of the argument, if given.
# Returns: $ template path
    my $self = shift;
    if (@_) { $self->{TEMPLATE} = shift; }
    return $self->{TEMPLATE};
}

# ramfs_config->add_module() method
sub add_module {
# Desc: Adds a module (and its dependencies) to the ramfs
# Input: 1) $  I   module name
# Returns: $ module name
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($module) = @_;
    push @{$self->{MODULES}}, $module;
    return $module;
}

# ramfs_config->get_modules() method
sub get_modules {
# Desc: Gets all defined modules in the configuration
# Input: None
# Returns: \@ array of module names
    my $self = shift;

    return \@{$self->{MODULES}};
}

# ramfs_config->add_preload() method
sub add_preload {
# Desc: Adds a module (and its dependencies) to be preloaded (before scsi modules) in the ramfs
# Input: 1) $  I   preload name
# Returns: $ preload name
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($preload) = @_;
    push @{$self->{PRELOADS}}, $preload;
    return $preload;
}

# ramfs_config->get_preloads() method
sub get_preloads {
# Desc: Gets all defined module preloads in the configuration
# Input: None
# Returns: \@ array of preload names
    my $self = shift;

    return \@{$self->{PRELOADS}};
}

# ramfs_config->add_overlay() method
sub add_overlay {
# Desc: Adds an overlay to the ramfs
# Input: 1) $  I   overlay path
# Returns: $ overlay path
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($overlay) = @_;
    push @{$self->{OVERLAYS}}, $overlay;
    return $overlay;
}

# ramfs_config->get_overlays() method
sub get_overlays {
# Desc: Gets all defined overlays in the configuration
# Input: None
# Returns: \@ array of overlay names
    my $self = shift;

    return \@{$self->{OVERLAYS}};
}

# ramfs_config->ram_overlay() method
sub ram_overlay {
# Desc: Gets or sets a ram overlay size
# Input: 1) $  I?  Optional ram overlay maximum size
#                  The data is set to the value of the argument, if given.
# Returns: $ ram_overlay size
    my $self = shift;
    if (@_) { $self->{RAM_OVERLAY} = shift; }
    return $self->{RAM_OVERLAY};
}

# ramfs_config->directive() method
sub add_directive {
# Desc: Adds a configuration directive to the configuration
# Input: 1) $  I   directive text
# Returns: $  directive text
#          undef: on error
    my $self = shift;

    if ($#_ != 0) {
      return undef;
    }
    my ($directive) = @_;
    push @{$self->{DIRECTIVES}}, $directive;
    return $directive;
}

# ramfs_config->get_directives() method
sub get_directives {
# Desc: Gets all valid directives in the configuration
# Input: None
# Returns: \@ array of directives in order of appearance in the config
    my $self = shift;

    return \@{$self->{DIRECTIVES}};
}


1;

__END__


=head1 NAME

oneSIS - Perl module interface to the routines used by oneSIS programs

=head1 SYNOPSIS

  use oneSIS;
  my $config   = oneSIS::get_config('/etc/sysimage.conf');
  my $hostname = oneSIS::get_hostname($config);
  my $class    = oneSIS::get_node_class($config, $hostname);

=head1 DESCRIPTION

This module contains functions and classes used by all oneSIS scripts.

Much of the actual heavy stuff is done by these functions.
This documentation describes these functions in basic detail.

For information on using oneSIS application programs, run each program
without any arguments for usage information.
For additional information, visit the oneSIS web page,

http://onesis.org

or refer to the oneSIS Administrator's manual.

=head1 ============================================================================

=head1 oneSIS module functions

=head1 ============================================================================

B<oneSIS::parse_config($configfile, $config);>

B<Description:>  Parses configuration from specified file (normally /etc/sysimage.conf). If an existing config is given, parsed directives are appended to the end, superceding directives in the existing config.

=over

=item B<Parameters:>

=over

=item $configfile   I      config file full pathname

=item $config       I?     Optional oneSIS::config object

=back

=item B<Return Values:>

=over

=item $ oneSIS::config object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::parse_ramfs_config($configfile, $config);>

B<Description:>  Parses ramfs configuration file If an existing config is given, parsed directives are appended to the end, superceding directives in the existing config.

=over

=item B<Parameters:>

=over

=item $configfile   I      config file full pathname

=item $config       I?     Optional oneSIS::config object

=back

=item B<Return Values:>

=over

=item $ oneSIS::ramfs_config object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::get_hostname($config);>

B<Description:>  Returns the hostname of this node.  The hostname is usually given by DHCP and set in the initrd.  If the hostname of the node isn't set, it tries to match a hostname from A MAC_ADDR directive, then from a kernel commandline parameter (hostname=), then from /etc/oneSIS/hostname

=over

=item B<Parameters:>

=over

=item $config   I      oneSIS::config object

=back

=item B<Return Values:>

=over

=item $ hostname

=item undef: on error or empty hostname

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::get_config($configfile, $config);>

B<Description:>  This routine is just an interface for retreiving a oneSIS configuration from alternate sources.

=over

=item B<Parameters:>

=over

=item $configfile   I      config file full pathname

=item $config       I?     Optional oneSIS::config object to add to

=back

=item B<Return Values:>

=over

=item $ oneSIS::config object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::get_node_class($config, $hostname);>

B<Description:>  Returns the class name of this node.

=over

=item B<Parameters:>

=over

=item $config      I      oneSIS::config object

=item $hostname    I      hostname of this node

=back

=item B<Return Values:>

=over

=item $ class name

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::get_host_ips( );>

B<Description:>  Populate a hash of hostnames and IP addresses

=over

=item B<Return Values:>

=over

=item \% Hash  Key=hostname  Value=IP address

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::get_range(\@hosts, $?space);>

B<Description:>  Builds a range expression from an array of hostnames.

=over

=item B<Parameters:>

=over

=item \@hosts   I      array of hostnames

=item $?space   I      Optional flag to return space-seperated string

=item -------             instead of comma-seperated

=back

=item B<Return Values:>

=over

=item $ range expression

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::expand_range($rangedesc, $hostname);>

B<Description:>  Matches a hostname against a NODECLASS_RANGE expression. a NODECLASS_RANGE is any text with one or more RANGEs in brackets. a RANGE is of the form <a-b[,x-y]...>, where a<b and x<y. ie: cn[1-10,20-32] or su[1,4]cn[1-32] or my[1-32]nodes.

=over

=item B<Parameters:>

=over

=item $rangedesc   I      range expression

=item $hostname    I      hostname

=back

=item B<Return Values:>

=over

=item 0: hostname does not match range

=item 1: hostname does match range

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::match_nodespecs($config, $hostname, \@?ranges, \@?regexps, \@?classes, \@?properties);>

B<Description:>  Checks a hostname against a range/regexp/class/property nodespec

=over

=item B<Parameters:>

=over

=item $config        I      oneSIS::config object

=item $hostname      I      hostname

=item \@?ranges      I      Optional array of range specs

=item \@?regexps     I      Optional array of regexp specs

=item \@?classes     I      Optional array of class specs

=item \@?properties   I      Optional array of property specs

=back

=item B<Return Values:>

=over

=item 1: if hostname matches any of the given specs

=item 0: otherwise

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::fork_parallel(\@cmds, $?parallelism, $?sleep);>

B<Description:>  Forks several commands in parallel Note: This function (re)defines the ALRM signal handler.

=over

=item B<Parameters:>

=over

=item \@cmds          I      Array of commands to run

=item $?parallelism   I      Optional limit of commands to fork in

=item -------------             parallel

=item $?sleep         I      Optional sleep time after spawning every

=item -------                   block of tasks

=back

=item B<Return Values:>

=over

=item \@ exit status of each command run

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::mount_dev($basedir);>

B<Description:>  Mounts the devfs filesystem on /dev or configures the system for udev If the kernel was compiled with devfs support, devfs is mounted so that device names are consistent between /dev and /proc/partitions

B<Dependencies:> /proc filesystem must already be mounted

=over

=item B<Parameters:>

=over

=item $basedir   I?     Optional base directory (default: '/')

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::get_ramdisk_size($config, $hostname, $classname);>

B<Description:>  Returns the size of the ramdisk to create for this node.

=over

=item B<Parameters:>

=over

=item $config       I      oneSIS::config object

=item $hostname     I      hostname of this node

=item $classname    I      class name of this node

=back

=item B<Return Values:>

=over

=item $ ramdisk size

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::update_ramdisk_elems($config, $hostname, $classname, $clean);>

B<Description:>  Create files, directories, and linkbacks in the ramdisk specified in the config

=over

=item B<Parameters:>

=over

=item $config       I      oneSIS::config object

=item $hostname     I      hostname of this node

=item $classname    I      class name of this node

=item $clean        I      clean files in ramdisk before updating

=back

=item B<Return Values:>

=over

=item \% hash of paths created (key=path, value=1)

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::setup_localdisks($config, \@localdisk_elems, $hostname, $classname, $action, $basedir);>

B<Description:>  Configures local disks specified in the config as swap space or mounted ext2 filesystems

=over

=item B<Parameters:>

=over

=item $config             I      oneSIS::config object

=item \@localdisk_elems   I      array of localdisk_elem objects

=item $hostname           I      hostname of this node

=item $classname          I      class name of this node

=item $action             I?     Optional action:  (default=0)

=item -------                    0: Mount filesystems

=item -------                    1: Format and label, but don't mount

=item -------                       filesystems

=item -------                    2: Dryrun -- don't partition, format,

=item -------                       or mount filesystems

=item $basedir            I?     Optional base directory for filesystem

=item --------                      mounts. (defaults to '/')

=back

=item B<Return Values:>

=over

=item \% hash of filesystems (key=device name; value=oneSIS::file_elem

=over

=item object)

=back

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::transform_path($basedir, $pathname, $config, $last_config);>

B<Description:>  Finds the valid transformation of a directory path containing possible .default directories, or (optionally) all possible transformations of the pathname, including valid CLASS/NODE/PROPERTY LINKBACK targets

=over

=item B<Parameters:>

=over

=item $basedir        I      base pathname

=item $pathname       I      relative pathname to find transformation of

=item $config         I?     optional oneSIS::config object

=item $last_config    I?     optional second oneSIS::config object only

=item ------------              used to check if a previous config had

=item ------------              hidden elements (requires option #3)

=back

=item B<Return Values:>

=over

=item If Input #3 is not present: $ full pathname possibly transformed

=over

=item with .default directories or '' if path doesn't exist

=back

=item If Input #3 is present: \@ of all existing transformations of the

=over

=item pathname including valid CLASS or NODE LINKBACK targets

=back

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::file_globs($path, $basedir, $?linkbacks);>

B<Description:>  Takes a path with (or without) wildcard globbing and returns all matches for the glob.  Probable LINKBACK targets and .default files are filtered out of the glob results.

=over

=item B<Parameters:>

=over

=item $path         I      full pathname possibly containing wildcard

=item -----                   glob syntax

=item $basedir      I      base directory

=item $?linkbacks   I      hash of linkback paths to ignore

=item -----------             (key=pathname, value=1)

=back

=item B<Return Values:>

=over

=item \@ array of pathnames of all files matching the glob

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::check_disks( );>

B<Description:>  Checks for available hard-drive devices.

=over

=item B<Return Values:>

=over

=item \% hash of device names (key=device number; value=device name)

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::get_disk_size($device);>

B<Description:>  Return safely usable disk size of given device There's really gotta be a better way of doing this. I don't know how to determine the exact number of usable blocks

=over

=item B<Parameters:>

=over

=item $device   I      Device name (ie: hda, sda)

=back

=item B<Return Values:>

=over

=item $ size of disk device

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::mk_path($path, $basedir);>

B<Description:>  Recursively create a directory

=over

=item B<Parameters:>

=over

=item $path       I      directory

=item $basedir    I      base directory

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::differs($src, $dest);>

B<Description:>  Check if file or directory tree differs

=over

=item B<Parameters:>

=over

=item $src     I      src file or dir

=item $dest    I      destination file or dir

=back

=item B<Return Values:>

=over

=item 1: files or dirs differ

=item 0: files or dirs do not differ

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::final_target($file, $quiet);>

B<Description:>  Follow a symbolic link to determine the absolute path of its final target

=over

=item B<Parameters:>

=over

=item $file     I      absolute path of link to follow

=item $quiet    I      quiet -- don't print warnings

=back

=item B<Return Values:>

=over

=item $ absolute path of final link target

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::copy_file($src, $dest, $do_check);>

B<Description:>  Copy file if it differs, following links if necessary

=over

=item B<Parameters:>

=over

=item $src         I      src file

=item $dest        I      destination file (not dir)

=item $do_check    I?     Optional: check if files differ first

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::copy_dir($src, $dest, $dryrun, $quiet);>

B<Description:>  # Copy a directory tree

=over

=item B<Parameters:>

=over

=item $src       I      src dir

=item $dest      I      destination dir

=item $dryrun    I?     dryrun

=item $quiet     I?     quiet

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::set_props($file_elem, $basedir);>

B<Description:>  Sets file permissions, owner, and group of a ramdisk element.

=over

=item B<Parameters:>

=over

=item $file_elem   I      file_elem class

=item $basedir     I?     Optional base directory (defaults to '/')

=back

=item B<Return Values:>

=over

=item Nothing

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::mirror_props($path, $image, $basedir);>

B<Description:>  Sets file permissions, owner, and group of a pqth element to be the same as the corresponding file in the rootFS image

=over

=item B<Parameters:>

=over

=item $path       I      pathname of filesystem element (relative to

=item -----                 $basedir)

=item $image      I      Master image location

=item $basedir    I      Base directory of pathname to operate on

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::class object methods

=head1 ============================================================================

B<oneSIS::class-E<gt>new($name);>

B<Description:>  class object constructor

=over

=item B<Parameters:>

=over

=item $name   I      class name

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::class-E<gt>name($name);>

B<Description:>  Gets or sets class name

=over

=item B<Parameters:>

=over

=item $name   I?     Optional class name. The data is set to the value of

=item -----             the argument, if given.

=back

=item B<Return Values:>

=over

=item $ class name

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::class-E<gt>add_subclass($name);>

B<Description:>  Adds a subclass to the current class

=over

=item B<Parameters:>

=over

=item $name   I      subclass name

=back

=item B<Return Values:>

=over

=item $ oneSIS::class object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::class-E<gt>get_subclass($name);>

B<Description:>  Retreive a subclass of the current class

=over

=item B<Parameters:>

=over

=item $name   I      subclass name

=back

=item B<Return Values:>

=over

=item $ oneSIS::class object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::class-E<gt>parent( );>

B<Description:>  Retreive the parent class of the current subclass

=over

=item B<Return Values:>

=over

=item $ oneSIS::class object

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::classdef object methods

=head1 ============================================================================

B<oneSIS::classdef-E<gt>new($name, $desc, $type);>

B<Description:>  classdef object constructor

=over

=item B<Parameters:>

=over

=item $name    I      class name

=item $desc    I      description -- can be regexp string, range spec,

=item -----              or hostname

=item $type    I      type -- can be one of 'REGEXP', 'MAP', or 'RANGE'

=back

=item B<Return Values:>

=over

=item $ blessed object, populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::classdef-E<gt>name($name);>

B<Description:>  Gets or sets class name

=over

=item B<Parameters:>

=over

=item $name   I?     Optional class name. The data is set to the value of

=item -----             the argument, if given.

=back

=item B<Return Values:>

=over

=item $ class name

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::classdef-E<gt>desc($desc);>

B<Description:>  Gets or sets class description

=over

=item B<Parameters:>

=over

=item $desc   I?     Optional description -- regexp, range spec, or

=item -----             hostname. The data is set to the value of the

=item -----             argument, if given.

=back

=item B<Return Values:>

=over

=item \@ descriptions of this class

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::classdef-E<gt>type($type);>

B<Description:>  Gets or sets class type

=over

=item B<Parameters:>

=over

=item $type   I?     Optional type -- can be one of 'REGEXP', 'MAP', or

=item -----             'RANGE'. The data is set to the value of the

=item -----             argument, if given.

=back

=item B<Return Values:>

=over

=item $ class type

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::modifier object methods

=head1 ============================================================================

B<oneSIS::modifier-E<gt>new( );>

B<Description:>  modifier object constructor

=over

=item B<Return Values:>

=over

=item $ blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::modifier-E<gt>classes($classes);>

B<Description:>  Adds a class or returns all classes in the object

=over

=item B<Parameters:>

=over

=item $classes   I?     Optional class name. The data is set to the value

=item --------             of the argument, if given.

=back

=item B<Return Values:>

=over

=item \@ all classes in the object

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::modifier-E<gt>nodes($nodes);>

B<Description:>  Adds a node or returns all nodes in the object

=over

=item B<Parameters:>

=over

=item $nodes   I?     Optional node name. The data is set to the value of

=item ------             the argument, if given.

=back

=item B<Return Values:>

=over

=item \@ all nodes in the object

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::modifier-E<gt>properties($properties);>

B<Description:>  Adds a property or returns all properties in the object

=over

=item B<Parameters:>

=over

=item $properties   I?     Optional property name. The data is set to the

=item -----------             value of the argument, if given.

=back

=item B<Return Values:>

=over

=item \@ all properties in the object

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::modifier-E<gt>ranges($ranges);>

B<Description:>  Adds a range or returns all ranges in the object

=over

=item B<Parameters:>

=over

=item $ranges   I?     Optional range. The data is set to the value of

=item -------             the argument, if given.

=back

=item B<Return Values:>

=over

=item \@ all ranges in the object

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::modifier-E<gt>regexps($regexps);>

B<Description:>  Adds a regexp or returns all regexps in the object

=over

=item B<Parameters:>

=over

=item $regexps   I?     Optional regexp. The data is set to the value of

=item --------             the argument, if given.

=back

=item B<Return Values:>

=over

=item \@ all regexps in the object

=back

=back

=head1 ============================================================================

=head1 oneSIS::property object methods

=head1 ============================================================================

B<oneSIS::property-E<gt>new($property);>

B<Description:>  property object constructor

=over

=item B<Parameters:>

=over

=item $property   I      property

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::property-E<gt>property($property);>

B<Description:>  Gets or sets property

=over

=item B<Parameters:>

=over

=item $property   I?     Optional property. The data is set to the value

=item ---------             of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ property

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::property-E<gt>applies_to($config, $hostname);>

B<Description:>  Checks if property applies to a given class, host

=over

=item B<Parameters:>

=over

=item $config      I      oneSIS::config object

=item $hostname    I      hostname

=back

=item B<Return Values:>

=over

=item $ 1: if property applies to the given hostname

=item 0: otherwise

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::property-E<gt>modifier( );>

B<Description:>  Returns the modifier object contained in this object

=over

=item B<Return Values:>

=over

=item $ oneSIS::modifier object

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::file_elem object methods

=head1 ============================================================================

B<oneSIS::file_elem-E<gt>new($path);>

B<Description:>  file_elem object constructor

=over

=item B<Parameters:>

=over

=item $path   I      file_elem full pathname

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::file_elem-E<gt>path($path);>

B<Description:>  Gets or sets file_elem path

=over

=item B<Parameters:>

=over

=item $path   I?     Optional file_elem full pathname. The data is set

=item -----             to the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ path

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::file_elem-E<gt>mode($mode);>

B<Description:>  Gets or sets file_elem mode

=over

=item B<Parameters:>

=over

=item $mode   I?     Optional file_elem permissions mode. The data is set

=item -----             to the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ mode

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::file_elem-E<gt>user($user);>

B<Description:>  Gets or sets file_elem user

=over

=item B<Parameters:>

=over

=item $user   I?     Optional file_elem user name. The data is set to the

=item -----             value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ user

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::file_elem-E<gt>group($group);>

B<Description:>  Gets or sets file_elem group

=over

=item B<Parameters:>

=over

=item $group   I?     Optional file_elem group name. The data is set to

=item ------             the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ group

=back

=back

=head1 ============================================================================

=head1 oneSIS::service object methods

=head1 ============================================================================

B<oneSIS::service-E<gt>new($name);>

B<Description:>  service object constructor

=over

=item B<Parameters:>

=over

=item $name   I      service name

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::service-E<gt>name($name);>

B<Description:>  Gets or sets service name

=over

=item B<Parameters:>

=over

=item $name   I?     Optional service name. The data is set to the value

=item -----             of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ service name

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::service-E<gt>ramdisk_elem($ramdisk_elem);>

B<Description:>  Gets or sets the service ramdisk_elem

=over

=item B<Parameters:>

=over

=item $ramdisk_elem   I?     Optional service ramdisk_elem. The data is

=item -------------             set to the value of the argument, if

=item -------------             given.

=back

=item B<Return Values:>

=over

=item $ service ramdisk_elem

=back

=back

=head1 ============================================================================

=head1 oneSIS::ramdisk_elem object methods

=head1 ============================================================================

B<oneSIS::ramdisk_elem-E<gt>new($path, $type);>

B<Description:>  ramdisk_elem object constructor

=over

=item B<Parameters:>

=over

=item $path    I      ramdisk_elem full pathname

=item $type    I      type of directive  =~ RAM(FILE|DIR) or

=item -----              LINK(FILE|DIR|BACK)

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramdisk_elem-E<gt>file_elem( );>

B<Description:>  Returns the file_elem object contained in this object

=over

=item B<Return Values:>

=over

=item $ oneSIS::file_elem object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramdisk_elem-E<gt>type($type);>

B<Description:>  Gets or sets ramdisk_elem type

=over

=item B<Parameters:>

=over

=item $type   I?     Optional ramdisk_elem type. RAM(FILE|DIR) or

=item -----             LINK(FILE|DIR|BACK). The data is set to the

=item -----             value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ type

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramdisk_elem-E<gt>linkback($linkback);>

B<Description:>  Gets or sets ramdisk_elem linkback

=over

=item B<Parameters:>

=over

=item $linkback   I?     Optional ramdisk_elem linkback target. The data

=item ---------             is set to the value of the argument, if

=item ---------             given.

=back

=item B<Return Values:>

=over

=item $ linkback target

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramdisk_elem-E<gt>forced($status);>

B<Description:>  Gets or sets ramdisk_elem forced linkback flag

=over

=item B<Parameters:>

=over

=item $status   I?     Optional ramdisk_elem forced linkback flag (0,1).

=item -------             The data is set to the value of the argument,

=item -------             if given.

=back

=item B<Return Values:>

=over

=item $ forced linkback status

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramdisk_elem-E<gt>hidden($status);>

B<Description:>  Gets or sets ramdisk_elem hidden flag

=over

=item B<Parameters:>

=over

=item $status   I?     Optional ramdisk_elem hidden flag (0,1). The data

=item -------             is set to the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ hidden linkback status

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramdisk_elem-E<gt>duplicate($status);>

B<Description:>  Gets or sets ramdisk_elem duplicate flag used to indicate whether the path element should be duplicated (copied) into /ram

=over

=item B<Parameters:>

=over

=item $status   I?     Optional ramdisk_elem duplicate flag (0,1). The

=item -------             data is set to the value of the argument, if

=item -------             given.

=back

=item B<Return Values:>

=over

=item $ duplicate status

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramdisk_elem-E<gt>protected($status);>

B<Description:>  Gets or sets ramdisk_elem protected flag used to indicate whether the path element should be protected during updates to /ram

=over

=item B<Parameters:>

=over

=item $status   I?     Optional ramdisk_elem protected flag (0,1). The

=item -------             data is set to the value of the argument, if

=item -------             given.

=back

=item B<Return Values:>

=over

=item $ protected status

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramdisk_elem-E<gt>modifier( );>

B<Description:>  Returns the modifier object contained in this object

=over

=item B<Return Values:>

=over

=item $ oneSIS::modifier object

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::ramdisk object methods

=head1 ============================================================================

B<oneSIS::ramdisk-E<gt>new($size, $unit);>

B<Description:>  ramdisk object constructor

=over

=item B<Parameters:>

=over

=item $size    I      ramdisk size

=item $unit    I      unit of size (K, M, G) kilo, mega, or giga bytes

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramdisk-E<gt>size($size);>

B<Description:>  Gets or sets ramdisk size

=over

=item B<Parameters:>

=over

=item $size   I?     Optional ramdisk size. The data is set to the value

=item -----             of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ ramdisk size

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramdisk-E<gt>unit($unit);>

B<Description:>  Gets or sets ramdisk unit

=over

=item B<Parameters:>

=over

=item $unit   I?     Optional ramdisk unit (K, M, or G). The data is set

=item -----             to the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ ramdisk unit

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramdisk-E<gt>modifier( );>

B<Description:>  Returns the modifier object contained in this object

=over

=item B<Return Values:>

=over

=item $ oneSIS::modifier object

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::bootloader object methods

=head1 ============================================================================

B<oneSIS::bootloader-E<gt>new($bloader);>

B<Description:>  bootloader object constructor

=over

=item B<Parameters:>

=over

=item $bloader   I      bootloader name (grub|grub2|lilo)

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::bootloader-E<gt>bootloader($bloader);>

B<Description:>  Gets or sets bootloader name (grub|grub2|lilo)

=over

=item B<Parameters:>

=over

=item $bloader   I?     Optional bootloader name. The data is set to the

=item --------             value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ bootloader name

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::bootloader-E<gt>modifier( );>

B<Description:>  Returns the modifier object contained in this object

=over

=item B<Return Values:>

=over

=item $ oneSIS::modifier object

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::path object methods

=head1 ============================================================================

B<oneSIS::path-E<gt>new($path);>

B<Description:>  path object constructor

=over

=item B<Parameters:>

=over

=item $path   I      path

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::path-E<gt>path($path);>

B<Description:>  Gets or sets path

=over

=item B<Parameters:>

=over

=item $path   I?     Optional path. The data is set to the value of the

=item -----             argument, if given.

=back

=item B<Return Values:>

=over

=item $ path

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::path-E<gt>modifier( );>

B<Description:>  Returns the modifier object contained in this object

=over

=item B<Return Values:>

=over

=item $ oneSIS::modifier object

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::disk object methods

=head1 ============================================================================

B<oneSIS::disk-E<gt>new($identifier);>

B<Description:>  disk object constructor

=over

=item B<Parameters:>

=over

=item $identifier   I      disk identifier (number, device)

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::disk-E<gt>identifier($identifier);>

B<Description:>  Gets or sets disk identifier (number, device)

=over

=item B<Parameters:>

=over

=item $identifier   I?     Optional disk identifier (number, device). The

=item -----------             data is set to the value of the argument,

=item -----------             if given.

=back

=item B<Return Values:>

=over

=item $ disk identifier

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::disk-E<gt>device($device);>

B<Description:>  Gets or sets disk device name

=over

=item B<Parameters:>

=over

=item $device   I?     Optional device name (ie: hda, sda). The data is

=item -------             set to the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ disk's device name

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::disk-E<gt>size($size);>

B<Description:>  Gets or sets disk size (in blocks)

=over

=item B<Parameters:>

=over

=item $size   I?     Optional disk size (in blocks). The data is set to

=item -----             the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ size (in blocks)

=back

=back

=head1 ============================================================================

=head1 oneSIS::localdisk_elem object methods

=head1 ============================================================================

B<oneSIS::localdisk_elem-E<gt>new($disk, $type, $size, $mountpoint);>

B<Description:>  localdisk_elem object constructor

=over

=item B<Parameters:>

=over

=item $disk          I      oneSIS::disk object

=item $type          I      type of partition (SWAP,MOUNT)

=item $size          I      size of partition

=item $mountpoint    I      mount point of partition (for MOUNT type)

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::localdisk_elem-E<gt>disk( );>

B<Description:>  Gets the localdisk disk object

=over

=item B<Return Values:>

=over

=item $ oneSIS::disk object

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::localdisk_elem-E<gt>type($type);>

B<Description:>  Gets or sets localdisk type

=over

=item B<Parameters:>

=over

=item $type   I?     Optional localdisk partition type (SWAP or MOUNT).

=item -----             The data is set to the value of the argument, if

=item -----             given.

=back

=item B<Return Values:>

=over

=item $ type

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::localdisk_elem-E<gt>size($size);>

B<Description:>  Gets or sets localdisk size

=over

=item B<Parameters:>

=over

=item $size   I?     Optional localdisk partition size (percentage or

=item -----             number). The data is set to the value of the

=item -----             argument, if given.

=back

=item B<Return Values:>

=over

=item $ size (percentage or number)

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::localdisk_elem-E<gt>actualsize($actualsize);>

B<Description:>  Gets or sets the actual size of the localdisk (in blocks)

=over

=item B<Parameters:>

=over

=item $actualsize   I?     Optional localdisk partition actual size (in

=item -----------             blocks). The data is set to the value of

=item -----------             the argument, if given.

=back

=item B<Return Values:>

=over

=item $ size

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::localdisk_elem-E<gt>fstype($type);>

B<Description:>  Gets or sets the localdisk element's filesystem type

=over

=item B<Parameters:>

=over

=item $type   I?     Optional disk element's filesystem type. The data

=item -----             is set to the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ type

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::localdisk_elem-E<gt>raidlevel($type);>

B<Description:>  Gets or sets the localdisk element's RAID level

=over

=item B<Parameters:>

=over

=item $type   I?     Optional disk element's RAID level. The data

=item -----             is set to the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ type

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::localdisk_elem-E<gt>label($label);>

B<Description:>  Gets or sets the localdisk element's label

=over

=item B<Parameters:>

=over

=item $label   I?     Optional disk element's label. The data is set to

=item ------             the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ label

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::localdisk_elem-E<gt>fastmount($fastmount);>

B<Description:>  Gets or sets flag to fastmount a disk (skip partitioning/mkfs)

=over

=item B<Parameters:>

=over

=item $fastmount   I?     1: Require label The data is set to the value

=item ----------             of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ label

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::localdisk_elem-E<gt>file_elem( );>

B<Description:>  Returns the file_elem object contained in this object

=over

=item B<Return Values:>

=over

=item $ oneSIS::file_elem object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::localdisk_elem-E<gt>modifier( );>

B<Description:>  Returns the modifier object contained in this object

=over

=item B<Return Values:>

=over

=item $ oneSIS::modifier object

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::specformat object methods

=head1 ============================================================================

B<oneSIS::specformat-E<gt>new($format);>

B<Description:>  specformat object constructor

=over

=item B<Parameters:>

=over

=item $format   I      nodespec format (hostname,basic_range,ext_range

=item -------             etc.)

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::specformat-E<gt>format( );>

B<Description:>  Gets specformat format type

=over

=item B<Return Values:>

=over

=item $ specformat format type

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::specformat-E<gt>add_translation($translation, $type);>

B<Description:>  Gets or sets the specformat translation

=over

=item B<Parameters:>

=over

=item $translation   I      specformat translation (perl s///

=item ------------             expression)

=item $type          I      specformat translation type (HOST|IP|SPEC)

=back

=item B<Return Values:>

=over

=item $ specformat translation

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::specformat-E<gt>get_translations( );>

B<Description:>  Gets all translations defined for the specformat

=over

=item B<Return Values:>

=over

=item \% hash (key=translation type, value=specformat::translation

=over

=item object)

=back

=back

=back

=head1 ============================================================================

=head1 oneSIS::nodecmd object methods

=head1 ============================================================================

B<oneSIS::nodecmd-E<gt>new($name, $cmd);>

B<Description:>  nodecmd object constructor

=over

=item B<Parameters:>

=over

=item $name   I      nodecmd name

=item $cmd    I      command/arguments (any valid bash command(s))

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::nodecmd-E<gt>name($cmd, $, $);>

B<Description:>  Gets or sets nodecmd name Gets or sets nodecmd function Gets or sets nodecmd command

=over

=item B<Parameters:>

=over

=item $cmd   I?     Optional name The data is set to the value of the

=item ----             argument, if given.

=item $     I?     Optional function The data is set to the value of the

=item -               argument, if given.

=item $     I?     Optional command/arguments (any valid bash

=item -               command(s)). The data is set to the value of the

=item -               argument, if given.

=back

=item B<Return Values:>

=over

=item $ name

=item $ function

=item $ command string

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::nodecmd-E<gt>modifier( );>

B<Description:>  Returns the modifier object contained in this object

=over

=item B<Return Values:>

=over

=item $ oneSIS::modifier object

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::cmdbuilder object methods

=head1 ============================================================================

B<oneSIS::cmdbuilder-E<gt>new($config);>

B<Description:>  cmdbuilder object constructor

=over

=item B<Parameters:>

=over

=item $config   I      Populated oneSIS::config object

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>add_nodes(\@nodes);>

B<Description:>  Adds nodes to build commands for

=over

=item B<Parameters:>

=over

=item \@nodes   I      Array of hostnames

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>get_nodes( );>

B<Description:>  Returns all nodes (not ranges/regexps/classes/props) in the object

=over

=item B<Return Values:>

=over

=item \@  Array of hostnames

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>add_range($range);>

B<Description:>  Adds a range specification of nodes to build commands for

=over

=item B<Parameters:>

=over

=item $range   I      Range specification

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>get_ranges( );>

B<Description:>  Returns all ranges specification of nodes to build commands for

=over

=item B<Return Values:>

=over

=item \@  Array of range specifications

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>add_regexp($regexp);>

B<Description:>  Adds a regexp matching nodes to build commands for

=over

=item B<Parameters:>

=over

=item $regexp   I      Regexp

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>get_regexps( );>

B<Description:>  Returns all regexps of nodes to build commands for

=over

=item B<Return Values:>

=over

=item \@  Array of regexps

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>add_class($class);>

B<Description:>  Adds a class name of nodes to build commands for

=over

=item B<Parameters:>

=over

=item $class   I      Class name

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>get_classes( );>

B<Description:>  Returns all class names of nodes to build commands for

=over

=item B<Return Values:>

=over

=item \@  Array of class names

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>add_prop($prop);>

B<Description:>  Adds a property of nodes to build commands for

=over

=item B<Parameters:>

=over

=item $prop   I      Property name

=back

=item B<Return Values:>

=over

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>get_props( );>

B<Description:>  Returns all property names of nodes to build commands for

=over

=item B<Return Values:>

=over

=item \@  Array of property names

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>noderange($array);>

B<Description:>  Build a range of all nodes in the cmdbuilder object

=over

=item B<Parameters:>

=over

=item $array   I      1: Return an array instead of a string

=back

=item B<Return Values:>

=over

=item $ range string of all nodes in the cmdbuilder object \@  unsorted

=over

=item array of all nodes (if argument 1 is given)

=back

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>buildcmds($cmd_name, $?function);>

B<Description:>  This is the main engine for building commands based on node specs

=over

=item B<Parameters:>

=over

=item $cmd_name    I      Name of command (used with

=item ---------              oneSIS::config->add_nodecmd() )

=item $?function   I      Option function (sub-command) for given

=item ----------             command name

=back

=item B<Return Values:>

=over

=item \@ Array of commands to run

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>get_basic_range_specs(\@hosts, $?multi);>

B<Description:>  Builds a node specification for basic_range specformats The node spec is of the form: (prefix[n-m], where n<m)

=over

=item B<Parameters:>

=over

=item \@hosts   I      array of hostnames/translations

=item $?multi   I      multi-spec flag: 0 = one spec per line 1 =

=item -------             multiple specs per line

=back

=item B<Return Values:>

=over

=item \@ node specifications

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::cmdbuilder-E<gt>get_ext_range_specs(\@hosts, $?multi);>

B<Description:>  Builds a node specification for ext_range specformats The node spec is of the form: (prefix[n-m,l-k,...], where n<m and l<k)

=over

=item B<Parameters:>

=over

=item \@hosts   I      array of hostnames/translations

=item $?multi   I      multi-spec flag: 0 = one spec per line 1 =

=item -------             multiple specs per line

=back

=item B<Return Values:>

=over

=item \@ node specifications

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::powercmd object methods

=head1 ============================================================================

B<oneSIS::powercmd-E<gt>new($function, $cmd);>

B<Description:>  powercmd object constructor

=over

=item B<Parameters:>

=over

=item $function   I      function

=item ---------             (ON|OFF|CYCLE|STATUS|LED(ON|OFF|STATUS))

=item $cmd        I      command/arguments (any valid bash command(s))

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::powercmd-E<gt>function($function);>

B<Description:>  Gets or sets powercmd function

=over

=item B<Parameters:>

=over

=item $function   I?     Optional function

=item ---------             (ON|OFF|CYCLE|STATUS|LED(ON|OFF|STATUS)).

=item ---------             The data is set to the value of the

=item ---------             argument, if given.

=back

=item B<Return Values:>

=over

=item $ function

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::powercmd-E<gt>cmd($cmd);>

B<Description:>  Gets or sets powercmd command

=over

=item B<Parameters:>

=over

=item $cmd   I?     Optional command/arguments (any valid bash

=item ----             command(s)). The data is set to the value of the

=item ----             argument, if given.

=back

=item B<Return Values:>

=over

=item $ command string

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::powercmd-E<gt>modifier( );>

B<Description:>  Returns the modifier object contained in this object

=over

=item B<Return Values:>

=over

=item $ oneSIS::modifier object

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::consolecmd object methods

=head1 ============================================================================

B<oneSIS::consolecmd-E<gt>new($cmd);>

B<Description:>  consolecmd object constructor

=over

=item B<Parameters:>

=over

=item $cmd   I      command/arguments (any valid bash command(s))

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::consolecmd-E<gt>cmd($cmd);>

B<Description:>  Gets or sets consolecmd command

=over

=item B<Parameters:>

=over

=item $cmd   I?     Optional command/arguments (any valid bash

=item ----             command(s)). The data is set to the value of the

=item ----             argument, if given.

=back

=item B<Return Values:>

=over

=item $ command string

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::consolecmd-E<gt>modifier( );>

B<Description:>  Returns the modifier object contained in this object

=over

=item B<Return Values:>

=over

=item $ oneSIS::modifier object

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::config object methods

=head1 ============================================================================

B<oneSIS::config-E<gt>new( );>

B<Description:>  config object constructor

=over

=item B<Return Values:>

=over

=item $ blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>distro_name($distro_name);>

B<Description:>  Gets or sets the distribution name

=over

=item B<Parameters:>

=over

=item $distro_name   I?     Optional distro name

=item ------------             (RedHat,Debian,SuSe,Fedora, etc). The data

=item ------------             is set to the value of the argument, if

=item ------------             given.

=back

=item B<Return Values:>

=over

=item $ distro name

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>distro_version($distro_version);>

B<Description:>  Gets or sets the version of the distribution

=over

=item B<Parameters:>

=over

=item $distro_version   I?     Optional distro version (9.0, 8.2, EL-AS4,

=item ---------------             etc). The data is set to the value of

=item ---------------             the argument, if given.

=back

=item B<Return Values:>

=over

=item $ distro version

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>skippatch($skippatch);>

B<Description:>  Gets or sets the flag specifying whether to skip the distro patch

=over

=item B<Parameters:>

=over

=item $skippatch   I?     0: Use a distro patch

=item ----------          1: Skip applying a distro patch (in

=item ----------             mk-sysimage) The data is set to the value of

=item ----------             the argument, if given.

=back

=item B<Return Values:>

=over

=item $ usepatch flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>keepnet($keepnet);>

B<Description:>  Gets or sets the flag specifying whether to keep network config files when running mk-sysimage

=over

=item B<Parameters:>

=over

=item $keepnet   I?     0: Do no keep network configs

=item --------          1: Keep network configs when running mk-sysimage

=item --------             The data is set to the value of the argument,

=item --------             if given.

=back

=item B<Return Values:>

=over

=item $ usepatch flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_class($name, $desc, $type);>

B<Description:>  Adds a class to the configuration

=over

=item B<Parameters:>

=over

=item $name    I      class name

=item $desc    I      description -- can be regexp string, range spec,

=item -----              or hostname

=item $type    I      type -- can be one of 'REGEXP', 'MAP', or 'RANGE'

=back

=item B<Return Values:>

=over

=item $ oneSIS::classdef object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_class($name);>

B<Description:>  Gets class with the given name

=over

=item B<Parameters:>

=over

=item $name   I      class name

=back

=item B<Return Values:>

=over

=item $ oneSIS::class object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>class_exists($name);>

B<Description:>  Checks if given class exists in the configuration

=over

=item B<Parameters:>

=over

=item $name   I      class name

=back

=item B<Return Values:>

=over

=item 0: if class doesn't exists

=item 1: if class exists

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>parents_of($classname);>

B<Description:>  Return an array of the parents of a class

=over

=item B<Parameters:>

=over

=item $classname   I      full class name

=back

=item B<Return Values:>

=over

=item \@ parents of the class ordered from the top down

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_classdefs( );>

B<Description:>  Gets all defined classdefs in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of oneSIS::classdef objects in order of appearance

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_property($propname);>

B<Description:>  Adds a property to the configuration

=over

=item B<Parameters:>

=over

=item $propname   I      property name

=back

=item B<Return Values:>

=over

=item $ oneSIS::property object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_property($propname);>

B<Description:>  Gets property with the given name

=over

=item B<Parameters:>

=over

=item $propname   I      property name

=back

=item B<Return Values:>

=over

=item $ oneSIS::property object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_properties( );>

B<Description:>  Gets all defined properties in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of property names

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_service($name);>

B<Description:>  Adds a service to the configuration

=over

=item B<Parameters:>

=over

=item $name   I      service name

=back

=item B<Return Values:>

=over

=item $ oneSIS::service object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_services( );>

B<Description:>  Gets all defined services in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of service objects in order of appearance in the config

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>service_exists($service_name);>

B<Description:>  Checks if the given service exists in the configuration

=over

=item B<Parameters:>

=over

=item $service_name   I      service name

=back

=item B<Return Values:>

=over

=item 0: if the service does not exist in the configuration

=item 1: if the service does exist in the configuration

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>service_enabled($service_name, $hostname, $classname);>

B<Description:>  Checks if the given service exists in the configuration and is enabled for the given node/class

=over

=item B<Parameters:>

=over

=item $service_name   I      service name

=item $hostname       I      hostname of node

=item $classname      I      class of node

=back

=item B<Return Values:>

=over

=item 0: if the service is not enabled for the given node/class

=item 1: if the service is enabled for the given node/class

=item -1: if the service does not exist in the config

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_ramdisk_elem($path, $type);>

B<Description:>  Adds a ramdisk_elem to the configuration

=over

=item B<Parameters:>

=over

=item $path    I      ramdisk_elem full pathname

=item $type    I      type of directive  =~

=item -----              RAM(FILE|DIR)|LINK(FILE|DIR|BACK)

=back

=item B<Return Values:>

=over

=item $ oneSIS::ramdisk_elem object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_ramdisk_elems( );>

B<Description:>  Gets all defined ramdisk_elems in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of ramdisk_elem objects ordered by appearance in the

=over

=item config

=back

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>ramdisk_elem_exists($pathname, $basedir, $checklink, $hostname, $classname);>

B<Description:>  Checks if the given pathname exists in the configuration and optionally whether the path is a link to /ram

=over

=item B<Parameters:>

=over

=item $pathname     I      full pathname

=item $basedir      I      base directory

=item $checklink    I?     optional flag to check whether pathname is a

=item ----------              LINK*

=item $hostname     I?     optional hostname: check whether the pathname

=item ---------               element exists for the hostname.  Requires

=item ---------               option #5

=item $classname    I?     optional classname: check whether the

=item ----------              pathname element exists for the classname.

=item ----------              Requires option #5

=back

=item B<Return Values:>

=over

=item 0: if the config does not contain an element with the given

=over

=item pathname

=back

=item 1: if the config does contain an element with the given pathname

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_disk($identifier);>

B<Description:>  Adds a disk to the configuration

=over

=item B<Parameters:>

=over

=item $identifier   I      disk identifier (number, device)

=back

=item B<Return Values:>

=over

=item $ oneSIS::disk object

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_disks( );>

B<Description:>  Gets all defined disks in the configuration

=over

=item B<Return Values:>

=over

=item \% hash of oneSIS::disk objects

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_bootloader($bloader);>

B<Description:>  Adds a bootloader to the configuration

=over

=item B<Parameters:>

=over

=item $bloader   I      bootloader name

=back

=item B<Return Values:>

=over

=item $ oneSIS::bootloader object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_bootloaders( );>

B<Description:>  Gets all defined bootloaders in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of bootloader objects in order of appearance in the config

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_syncdir($syncdir);>

B<Description:>  Adds a syncdir to the configuration

=over

=item B<Parameters:>

=over

=item $syncdir   I      syncdir path

=back

=item B<Return Values:>

=over

=item $ oneSIS::path object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_syncdirs( );>

B<Description:>  Gets all defined syncdirs in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of oneSIS::path objects in order of appearance in config

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_excludesync($excludesync);>

B<Description:>  Adds an excludesync to the configuration

=over

=item B<Parameters:>

=over

=item $excludesync   I      excludesync path

=back

=item B<Return Values:>

=over

=item $ oneSIS::path object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_excludesyncs( );>

B<Description:>  Gets all defined excludesyncs in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of oneSIS::path objects in order of appearance in config

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_excludedeploy($excludedeploy);>

B<Description:>  Adds an excludedeploy to the configuration

=over

=item B<Parameters:>

=over

=item $excludedeploy   I      excludedeploy path

=back

=item B<Return Values:>

=over

=item $ oneSIS::path object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_excludedeploys( );>

B<Description:>  Gets all defined excludedeploys in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of oneSIS::path objects in order of appearance in config

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_localdisk_elem($disk, $type, $size, $mountpoint);>

B<Description:>  Adds a localdisk_elem to the configuration

=over

=item B<Parameters:>

=over

=item $disk          I      localdisk identifier (number, device)

=item $type          I      type of partition (SWAP,MOUNT)

=item $size          I      size of partition

=item $mountpoint    I      mount point of partition (only for MOUNT

=item -----------              type)

=back

=item B<Return Values:>

=over

=item $ oneSIS::localdisk_elem object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_localdisk_elems( );>

B<Description:>  Gets all defined localdisk_elems in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of localdisk_elem objects in order of appearance in the

=over

=item config

=back

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_deploydisk_elem($disk, $type, $size, $?mountpoint);>

B<Description:>  Adds a deploydisk_elem to the configuration

=over

=item B<Parameters:>

=over

=item $disk          I      deploydisk identifier (number, device)

=item $type          I      type of partition (SWAP,MOUNT)

=item $size          I      size of partition

=item $?mountpoint   I      mount point of partition (only for MOUNT

=item ------------             type)

=back

=item B<Return Values:>

=over

=item $ oneSIS::localdisk_elem object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_deploydisk_elems( );>

B<Description:>  Gets all defined deploydisk_elems in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of localdisk_elem objects in order of appearance in the

=over

=item config

=back

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_ramdisk($size, $unit);>

B<Description:>  Adds a ramdisk to the configuration

=over

=item B<Parameters:>

=over

=item $size    I      ramdisk size

=item $unit    I      unit of size (K, M, G) kilo, mega, or giga bytes

=back

=item B<Return Values:>

=over

=item $ oneSIS::ramdisk object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_ramdisks( );>

B<Description:>  Gets all defined ramdisks in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of ramdisk objects in order of appearance in the config

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_mac_addr($hostname, $mac);>

B<Description:>  Adds a MAC address mapping to the configuration

=over

=item B<Parameters:>

=over

=item $hostname   I      host name

=item $mac        I      MAC address

=back

=item B<Return Values:>

=over

=item 0: on success

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_mac_addrs( );>

B<Description:>  Gets all MAC addersses defined in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of mac addresses appearing in the config

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_hostname_from_mac_addr($mac);>

B<Description:>  Returns the a hostname associated with a MAC, if it exists

=over

=item B<Parameters:>

=over

=item $mac   I      MAC address

=back

=item B<Return Values:>

=over

=item $ host name

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_nodecmd($name, $cmd);>

B<Description:>  Adds a NODECMD function command description to the configuration

=over

=item B<Parameters:>

=over

=item $name   I      node command name

=item $cmd    I      command/arguments (can be full pathname if desired)

=back

=item B<Return Values:>

=over

=item $ oneSIS::nodecmd object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_nodecmds( );>

B<Description:>  Gets all NODECMD function command descriptions in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of oneSIS::nodecmd objects

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_specformat($spec_id, $format);>

B<Description:>  Adds a POWERCMD nodespec format

=over

=item B<Parameters:>

=over

=item $spec_id   I      specformat spec_id

=item $format    I      nodespec format (hostname,basic_range,ext_range,

=item -------              etc.)

=back

=item B<Return Values:>

=over

=item $ oneSIS::specformat object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_specformat($spec_id);>

B<Description:>  Gets a specified POWERCMD nodespec format

=over

=item B<Parameters:>

=over

=item $spec_id   I      specformat spec_id

=back

=item B<Return Values:>

=over

=item $ oneSIS::specformat object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_eth_preload($driver);>

B<Description:>  Adds a driver from an ETH_PRELOAD directive to the configuration

=over

=item B<Parameters:>

=over

=item $driver   I      ethnernet driver name

=back

=item B<Return Values:>

=over

=item $ undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_eth_preloads( );>

B<Description:>  Gets all drivers specified in ETH_PRELOAD directives in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of driver names

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>add_directive($directive);>

B<Description:>  Adds a configuration directive to the configuration

=over

=item B<Parameters:>

=over

=item $directive   I      directive text

=back

=item B<Return Values:>

=over

=item $  directive text

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>get_all_directives( );>

B<Description:>  Gets all valid directives in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of directives in order of appearance in the config

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::config-E<gt>using_directive($modifier, $hostname, $classname, $?noparents);>

B<Description:>  Checks the modifier object of a directive against a given hostname and classname to determine whether the directive should be used

=over

=item B<Parameters:>

=over

=item $modifier     I      oneSIS::modifier object

=item $hostname     I      hostname

=item $classname    I      classname

=item $?noparents   I      0: Check all parent classes of classname

=item -----------          1: Only check classname, not any parent

=item -----------             classes

=back

=item B<Return Values:>

=over

=item 0: if the directive should NOT be used

=item 1: if the directive should be used

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::ramfs_copy object methods

=head1 ============================================================================

B<oneSIS::ramfs_copy-E<gt>new($path);>

B<Description:>  path object constructor

=over

=item B<Parameters:>

=over

=item $path   I      path

=back

=item B<Return Values:>

=over

=item $ blessed object, partially populated

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_copy-E<gt>path($path);>

B<Description:>  Gets or sets path

=over

=item B<Parameters:>

=over

=item $path   I?     Optional path. The data is set to the value of the

=item -----             argument, if given.

=back

=item B<Return Values:>

=over

=item $ path

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_copy-E<gt>nodeplibs($nodeplibs);>

B<Description:>  Gets or sets the nodeplibs flag

=over

=item B<Parameters:>

=over

=item $nodeplibs   I?     Optional nodeplibs flag

=back

=item B<Return Values:>

=over

=item $ recurse flag

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_copy-E<gt>recurse($recurse);>

B<Description:>  Gets or sets the recurse flag

=over

=item B<Parameters:>

=over

=item $recurse   I?     Optional recurse flag

=back

=item B<Return Values:>

=over

=item $ recurse flag

=item undef: on error

=back

=back

=head1 ============================================================================

=head1 oneSIS::ramfs_config object methods

=head1 ============================================================================

B<oneSIS::ramfs_config-E<gt>new( );>

B<Description:>  ramfs_config object constructor

=over

=item B<Return Values:>

=over

=item $ blessed object, empty

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>ramdisk_root($ramdisk_root);>

B<Description:>  Gets or sets the ramdisk_root flag

=over

=item B<Parameters:>

=over

=item $ramdisk_root   I?     Optional path. The data is set to the value

=item -------------             of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ path

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>add_ramfs_copy($path);>

B<Description:>  Adds a path to copy to the ramfs

=over

=item B<Parameters:>

=over

=item $path   I      pathname

=back

=item B<Return Values:>

=over

=item $ oneSIS::ramfs_copy object

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>get_ramfs_copies( );>

B<Description:>  Gets all defined ramfs_copies in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of oneSIS::ramfs_copy objects in order of appearance in

=over

=item the config

=back

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>add_dhcp_interface($interface);>

B<Description:>  Adds a dhcp interface to use in the ramfs

=over

=item B<Parameters:>

=over

=item $interface   I      interface name (eg: eth0)

=back

=item B<Return Values:>

=over

=item $ interface name

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>get_dhcp_interfaces( );>

B<Description:>  Gets all defined dhcp interfaces in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of dhcp interface names in order of appearance in the

=over

=item config

=back

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>initrd($initrd);>

B<Description:>  Gets or sets the initrd flag

=over

=item B<Parameters:>

=over

=item $initrd   I?     Optional initrd flag The data is set to the value

=item -------             of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ initrd flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>nodhcp($nodhcp);>

B<Description:>  Gets or sets the nodhcp flag

=over

=item B<Parameters:>

=over

=item $nodhcp   I?     Optional nodhcp flag The data is set to the value

=item -------             of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ nodhcp flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>nonfs($nonfs);>

B<Description:>  Gets or sets the nonfs flag

=over

=item B<Parameters:>

=over

=item $nonfs   I?     Optional nonfs flag The data is set to the value of

=item ------             the argument, if given.

=back

=item B<Return Values:>

=over

=item $ nonfs flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>dhcp_retries($dhcp_retries);>

B<Description:>  Gets or sets the number of dhcp retries

=over

=item B<Parameters:>

=over

=item $dhcp_retries   I?     Number of dhcp retries The data is set to

=item -------------             the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ number of dhcp retries

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>nfs_retries($nfs_retries);>

B<Description:>  Gets or sets the number of nfs retries

=over

=item B<Parameters:>

=over

=item $nfs_retries   I?     Number of nfs retries The data is set to the

=item ------------             value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ number of nfs retries

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>bond_interfaces($bond_interfaces);>

B<Description:>  Gets or sets a bonded interface (only one bond allowed at the moment)

=over

=item B<Parameters:>

=over

=item $bond_interfaces   I?     Space-seperated list of interface names

=item ----------------             to bond (eg: 'eth0 eth1') The data is

=item ----------------             set to the value of the argument, if

=item ----------------             given.

=back

=item B<Return Values:>

=over

=item $ bonded interface names

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>network_check($network_check);>

B<Description:>  Gets or sets the network_check flag

=over

=item B<Parameters:>

=over

=item $network_check   I?     Optional network_check flag The data is set

=item --------------             to the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ network_check flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>automount($automount);>

B<Description:>  Gets or sets the automount flag

=over

=item B<Parameters:>

=over

=item $automount   I?     Optional automount flag The data is set to the

=item ----------             value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ mountlabels flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>swapon($swapon);>

B<Description:>  Gets or sets the swapon flag

=over

=item B<Parameters:>

=over

=item $swapon   I?     Optional swapon flag The data is set to the value

=item -------             of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ swapon flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>add_mount_rw_dir($dir);>

B<Description:>  Adds a directory to mount read-write in the ramfs

=over

=item B<Parameters:>

=over

=item $dir   I      directory

=back

=item B<Return Values:>

=over

=item $ directory

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>get_mount_rw_dirs( );>

B<Description:>  Gets all dirs configured to be mounted read-write in the ramfs

=over

=item B<Return Values:>

=over

=item \@ array of directory names

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>mount_all_rw($mount_all_rw);>

B<Description:>  Gets or sets the mount_all_rw flag

=over

=item B<Parameters:>

=over

=item $mount_all_rw   I?     Optional mount_all_rw flag The data is set

=item -------------             to the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ mount_all_rw flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>nomodprobe($nomodprobe);>

B<Description:>  Gets or sets the nomodprobe flag

=over

=item B<Parameters:>

=over

=item $nomodprobe   I?     Optional nomodprobe flag The data is set to

=item -----------             the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ nomodprobe flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>pcimods($pcimods);>

B<Description:>  Gets or sets the pcimods flag

=over

=item B<Parameters:>

=over

=item $pcimods   I?     Optional pcimods flag The data is set to the

=item ---------             value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ pcimods flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>scsimods($scsimods);>

B<Description:>  Gets or sets the scsimods flag

=over

=item B<Parameters:>

=over

=item $scsimods   I?     Optional scsimods flag The data is set to the

=item ---------             value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ scsimods flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>initrd_size($initrd_size);>

B<Description:>  Gets or sets the initrd size

=over

=item B<Parameters:>

=over

=item $initrd_size   I?     Optional initrd size The data is set to the

=item ------------             value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ initrd size

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>initrd_buffer($initrd_buffer);>

B<Description:>  Gets or sets the initrd buffer size

=over

=item B<Parameters:>

=over

=item $initrd_buffer   I?     Optional initrd buffer size The data is set

=item --------------             to the value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ initrd buffer size

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>setup_raid($setup_raid);>

B<Description:>  Gets or sets the setup_raid flag

=over

=item B<Parameters:>

=over

=item $setup_raid   I?     Optional setup_raid flag The data is set to the value

=item -------             of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ setup_raid flag

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>resume_from($resume_from);>

B<Description:>  Gets or sets the resume device

=over

=item B<Parameters:>

=over

=item $resume_from   I?     Optional resume device name (with or without

=item ------------             /dev) The data is set to the value of the

=item ------------             argument, if given.

=back

=item B<Return Values:>

=over

=item $ resume device name

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>template($template);>

B<Description:>  Gets or sets the template to use

=over

=item B<Parameters:>

=over

=item $template   I?     Optional template path The data is set to the

=item ---------             value of the argument, if given.

=back

=item B<Return Values:>

=over

=item $ template path

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>add_module($module);>

B<Description:>  Adds a module (and its dependencies) to the ramfs

=over

=item B<Parameters:>

=over

=item $module   I      module name

=back

=item B<Return Values:>

=over

=item $ module name

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>get_modules( );>

B<Description:>  Gets all defined modules in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of module names

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>add_preload($preload);>

B<Description:>  Adds a module (and its dependencies) to be preloaded (before scsi modules) in the ramfs

=over

=item B<Parameters:>

=over

=item $preload   I      preload name

=back

=item B<Return Values:>

=over

=item $ preload name

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>get_preloads( );>

B<Description:>  Gets all defined module preloads in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of preload names

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>add_overlay($overlay);>

B<Description:>  Adds an overlay to the ramfs

=over

=item B<Parameters:>

=over

=item $overlay   I      overlay path

=back

=item B<Return Values:>

=over

=item $ overlay path

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>get_overlays( );>

B<Description:>  Gets all defined overlays in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of overlay names

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>ram_overlay( );>

B<Description:>  Gets or sets a ram overlay size

=over

=item B<Parameters:>

=over

=item $ram_overlay      I?     Optional ram overlay maximum size

=item ------------             The data is set to the value of the

=item ------------             argument, if given.

=back

=item B<Return Values:>

=over

=item $ ram overlay size

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>add_directive($directive);>

B<Description:>  Adds a configuration directive to the configuration

=over

=item B<Parameters:>

=over

=item $directive   I      directive text

=back

=item B<Return Values:>

=over

=item $  directive text

=item undef: on error

=back

=back

B<--------------------------------------------------------------------->

B<oneSIS::ramfs_config-E<gt>get_directives( );>

B<Description:>  Gets all valid directives in the configuration

=over

=item B<Return Values:>

=over

=item \@ array of directives in order of appearance in the config

=back

=back



=head1

=head1

=head1

=head1

=head1 SEE ALSO

Local documentation should be accessible in /usr/share/oneSIS/doc.

Submit any questions/requests/gripes to the oneSIS-users mailing list:
	onesis-users@lists.sourceforge.net

Updated software and documentation may be found at the oneSIS web site:
	http://onesis.org

=head1 AUTHOR

Josh England E<lt>jjengla@gmail.comE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (2004-2007) Josh England, Sandia Corporation.

Copyright (2008-2017) Josh England

Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
the U.S. Government retains certain rights in this software

oneSIS is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
any later version.

oneSIS is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with oneSIS; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

=cut
